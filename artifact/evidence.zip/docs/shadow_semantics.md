# Shadow의 의미와 독립 reference 계산

이 문서는 2026-09-22 semantic coverage 단계의 정의입니다. 기존 graph-digest 차이와 독립적인 가능한 trajectory의 누락을 구분합니다. 결과는 [semantic coverage report](semantic_coverage_report.md)에 있습니다.

## 1. 검증할 대상

Hidden object state를 `x=(lane, q, v, π)`로 둡니다. `q`는 traffic direction을 따라 증가하는 longitudinal front position, `v≥0`, `π`는 허용 lane transition을 따르는 path입니다. 이번 finite fixture의 footprint는 `[q−3,q]`이며 lateral motion과 알려진 obstacle은 없습니다. D05에서는 같은 longitudinal abstraction과 stationary truck record를 사용하고, world-coordinate footprint/known-truck clearance를 별도로 검사합니다.

Observation history `h={(t_i,Z_i,O_i)}` 아래 가능한 상태는 다음 existential set입니다.

\[
S_h(t)=\{x(t):x(0)\in X_0,\ \dot q=v,\ \dot v=a,\ 0\le v\le15,\ -8\le a\le4,
\ \pi\text{ follows the lane graph},\ \Phi(x(t_i))\cap Z_i=\varnothing,
\ \Phi(x(\tau))\cap O(\tau)=\varnothing\}.
\]

속도 bound에서 acceleration/deceleration의 비대칭을 유지합니다. Visibility는 지정한 observation time의 제약입니다. Synthetic analytic witness에는 piecewise-constant FOV extension도 지정할 수 있습니다. 실제 CARLA frame 사이의 3D visibility까지 검증한 것으로 해석하지 않습니다. `S_h`는 해당 prediction/observation model의 가능한 상태이며 물리 세계의 완전한 ground truth와 같다고 가정하지 않습니다.

RSS 원문은 footprint, hidden reach-avoid set, danger zone을 정의하고, 구현에서는 occluded region의 길이와 observation history로 velocity bound를 근사한다고 설명합니다. Prediction의 nominal Octomap FOV와 실행의 sensor update는 구분됩니다. 이 formal framework나 conservative reachability 자체가 이번 기여는 아닙니다. [RSS 2021, §III–VI](https://www.roboticsproceedings.org/rss17/p066.pdf)

## 2. 원 코드와 의미의 대응

Pinned source는 `2b6b06637850b406cfbeab926a3dedc01edad91e`입니다. [공식 source](https://github.com/SafeRoboticsLab/Safe_Occlusion_Aware_Planning/blob/2b6b06637850b406cfbeab926a3dedc01edad91e/risk_analysis/shadow_utils.py)를 local source와 대조했습니다.

| 표현/함수 | 제약 또는 역할 |
|---|---|
| `InBound.ds_in, t_in` | 과거에 확인한 upstream boundary와 그 시각입니다. Position support뿐 아니라 later speed bound에 관여합니다. |
| `OutBound.ds_out, t_out` | 현재 downstream boundary와 propagation 기준 시각입니다. `extent_outbound`의 elapsed time을 바꿉니다. |
| `InOutBound` | 한 lane에 닫힌 inbound/outbound interval입니다. 이번 최소 반례의 핵심 closed form입니다. |
| `child_node`, `leaf_list`, `leaf_depth` | Branch path와 boundary까지의 길이를 표현합니다. 서로 다른 leaf는 대안적인 path를 뜻합니다. |
| `ds_in_hist`, `t_in_hist` | Branch마다 historical boundary offset/time을 보존합니다. 한 history 안에서는 bound의 minimum, 대안적인 history 사이에서는 maximum을 취합니다. |
| `calc_V_max` | 길이·elapsed time·historical inbound로 speed cap을 계산하는 구현상의 approximation입니다. 독립 reference의 transition에는 호출하지 않습니다. |
| `predict_shadow` | Boundary velocity bound로 downstream extent를 전파합니다. Length < 3 m이면 moving vehicle의 extent를 늘리지 않습니다. |
| `bwd_shadow_FRS` | Native checker가 소비하는 position–speed envelope입니다. Position-only graph 검사와 별개로 zero-horizon 및 future envelope를 검사합니다. |
| `leaf_depth=None` | 검색을 잘라낸 implicit tail입니다. 일반 graph에서 그 전체 physical-state denotation이 명세되어 있다고 가정하지 않습니다. |

Flat shadow의 position interval만 같아도 의미가 같지 않습니다. 동일 interval과 `dis=9`, query time 3에서 `t_in=0`인 history의 native bound는 **8.485281 m/s**, `t_in=3`이면 **15 m/s**입니다. 원 mature-shadow 비교는 이 차이를 검사하지 않습니다. 이는 constructed unit control이며 두 history가 동일 sensor episode에서 생겼다는 주장은 아닙니다.

특히 generic graph의 `S_impl`을 단순히 `calc_V_max`의 한 scalar나 root interval 하나로 정의하지 않습니다. Explicit forest의 모든 node/branch를 합치고, query에 소비되는 FRS를 함께 검사합니다. D05의 implicit tails 때문에 생기는 global interpretation의 불확실성은 별도로 남깁니다. 반면 closed two-lane fixture의 t=4 original output은 **전체 forest가 empty**이므로 이 ambiguity 없이 누락을 증명할 수 있습니다.

## 3. 서로 다른 세 reduction

| 위치 | 원 predicate | 이번 처리 |
|---|---|---|
| Generated backward work item의 admission | `(root.id, root.ds_out)`가 이미 searched인지 | 본 반례의 직접 개입 지점입니다. |
| Pop 시 visited-lane skip | Lane ID가 fully visited인지 | 별도 ablation으로 분리했습니다. 이것만 끄면 반례는 남습니다. |
| Mature output의 duplicate 검사 | Outbound가 같고 retained leaf/depth가 candidate 목록에 있는지 | History를 검사하지 않습니다. 이것만 바꿔도 본 admission 반례는 남습니다. |

`bwd_searched_begin`은 현재 시각의 **입력을 처리하기 시작했다**는 기록이지, 그 입력의 가능한 상태가 최종 output에 모두 보존됐다는 certificate가 아닙니다. Split child가 아직 pending일 수 있습니다. 실제로 processed input의 interval containment를 admission 근거로 사용한 첫 수정안도 실패했습니다. 이 실패 run은 `semantic_small_graph_v1`에 보존했습니다.

원 구현의 최소 반례에서는 key를 차지한 short job 자체가 visibility filtering 후 `mature=None`을 반환했습니다. 검색을 마쳤다는 key만으로 나중의 long job을 제거하면 surviving coverage가 전혀 없는 경우도 배제하지 못합니다. Candidate/retained input의 interval이 nested인 경우에도 이 문제가 발생합니다.

검사한 최소 수정은 **같은 시각에 이미 확정된 mature output**의 coverage를 사용합니다. 후보 work item 역시 dynamics를 그 시각까지 전파한 상태입니다. 이전 시각의 input과 현재 output을 같은 집합처럼 비교하지 않습니다. Visibility filtering 전 후보를 current mature output이 통째로 포함하는지를 요구하므로, 포함 여부가 불분명하면 처리합니다.

Committed mature coverage는 이번 guard의 제한된 보존 조건이며, 모든 올바른 deduplication의 필수조건으로 주장하지 않습니다. Coverage가 보장되도록 관리되는 pending work 등 다른 설계는 배제하지 않았습니다.

현재 guard가 제거를 허용하는 제한된 경우는 flat backward `InOutBound`, 동일 lane/parent/inbound/time, 동일한 빈 historical arrays, 동일 outbound epoch, retained interval의 candidate interval 포함입니다. Branching 또는 복잡한 history는 보존합니다. History가 같아야 interval 포함을 같은 position–speed constraint의 포함으로 해석할 수 있습니다. General set inclusion 원리 자체를 새 theorem으로 제시하지 않습니다.

`admission_only`는 admission predicate만 바꿉니다. `all_guarded`는 추가로 lane-only skip을 끄고 mature duplicate에도 위 제한된 guard를 적용합니다. 전자는 핵심 반례의 최소 수정이고, 후자는 보조 control입니다. Generic cyclic graph의 termination과 global soundness는 증명하지 않았습니다.

## 4. Reference의 정확성과 한계

구현은 [reference.py](../analysis/semantic_coverage/reference.py)입니다. RSS의 shadow update, queue reduction, velocity-bound 함수 또는 patched output을 참조하지 않습니다.

- 두 lane은 traffic coordinate로 `[-20,0]`, `[0,10]`에 연결됩니다. 첫 lane에서 `q=-ds`, 둘째에서 `q=10-ds`입니다.
- Initial finite hypothesis는 `q=-12…-4`의 0.25 m grid, `v=0…15`의 1 m/s grid에서 footprint visibility를 통과한 496개 state입니다. 원 initial shadow가 이 state들을 모두 포함함을 확인했습니다. Implementation의 initial abstraction은 이보다 큰 continuous set도 포함하므로, reference보다 적은 초기 가능성을 주어 만든 반례가 아닙니다.
- `dt=0.5 s`, control alphabet은 `{-8,-4,0,4}`입니다. Speed saturation까지 rational arithmetic으로 정확히 적분합니다. Grid 밖으로 나간 값을 rounding해서 재투영하지 않습니다.
- 각 observation에서 전체 3 m longitudinal footprint가 visible cell과 겹치는지 검사합니다. Visibility cell은 같은 waypoint query의 nearest-sample partition으로 고정합니다.
- 모든 finite predecessor와 control을 탐색하므로 이 **명시한 finite initial/control model**에는 exact합니다. Continuous initial/control space 전체에는 underapproximation입니다.
- 따라서 `x*∈S_ref`의 feasible trajectory는 positive evidence지만, finite reference에서 누락을 못 찾았다고 continuous preservation을 증명하지 않습니다. Patched FRS가 reference보다 크다고 불필요한 보수성이라고 단정하지도 않습니다.

Primary witness는 grid search에만 의존하지 않습니다. `front_ds(t)=8, v(t)=0, a(t)=0`으로 두면 footprint `[8,11]`가 0…4 s 내내 hidden이며, visibility-cell 경계와의 최소 거리는 3.75 m입니다. 연속적인 위치 perturbation에도 여유가 있습니다. t=4 original forest가 empty이므로 이 trajectory는 어느 다른 shadow에도 포함되지 않습니다.

Native checker 비교에서는 exact finite reachable points를 `MultiPoint`로 전달합니다. Convex hull이나 conservative polygon을 만들어 reference rejection을 유도하지 않습니다. Native checker의 source와 danger-zone construction은 그대로 두고 geometry interface의 coordinate maxima만 제공합니다. Reference point가 원 danger zone에 들어간다는 뜻이지, 모든 evasive policy의 실패나 실제 collision을 증명하는 것은 아닙니다.

## 5. 한-query 대조군의 proposition과 proof

**Proposition — 현재 1D observation model의 의미적 동등성.** 객체의 front 위치가 `q`, footprint가 닫힌 구간 `Φ(q)=[q−3,q]`이고, visible set `Z`와 접촉도 detection으로 처리한다고 하겠습니다. t=2.5에만 다음 hidden set을 사용하는 두 sequence는 동일한 initial set·dynamics·다른 observation을 사용하면 같은 feasible trajectory 집합을 정의합니다.

```text
H_base = (−14.75, −3.25) ∪ (−2.25, −1.75)
H_fill = (−14.75, −3.25)
허용 front 위치: (−11.75, −3.25)  — 두 조건 동일
```

**Proof.** `reference.field_intervals`는 nearest-waypoint cell을 만들고 인접 visible cell을 합칩니다. `hidden`은 `max(q−3,a) <= min(q,b)`인 visible interval `[a,b]`가 하나라도 있으면 거절합니다. 따라서 visible boundary와 접촉하는 객체도 거절되며 hidden component와 허용 front interval은 열린 구간입니다. 실제 code에서 산출된 `Z_base`는 `[−20,−14.75] ∪ [−3.25,−2.25] ∪ [−1.75,10]`, `Z_fill`은 `[−20,−14.75] ∪ [−3.25,10]`입니다.

연결된 footprint `[q−3,q]`가 hidden union에 포함되려면 한 component 안에 완전히 들어가야 합니다. 열린 component `(a,b)`가 허용하는 front는 `(a+3,b)`이며 `b−a≤3`이면 empty입니다. 두 field의 차이는 길이 0.5 m인 hidden component 하나뿐입니다. **0.5 m의 작은 숨은 구간에 3 m footprint가 들어갈 수 없으므로**, 두 observation operator가 허용하는 front는 모두 `(−11.75,−3.25)`입니다. Speed·lane/history에 대한 다른 조건도 같으므로 hidden state 집합이 같습니다. 모든 지정 observation 시각의 제약이 같고 initial set과 dynamics도 같으므로, 그 제약들을 만족하는 전체 continuous feasible trajectory 집합도 같습니다. □

그런데 Original pipeline은 base에서 t=4의 feasible position hypotheses 293개를 누락하고 fill에서는 해당 position omission이 없습니다. 따라서 **가능한 hidden hypothesis를 바꾸지 않는 관측 표현의 차이가 worklist 처리와 feasible hypothesis 보존을 바꿉니다.** 이것은 finite grid의 equality를 단순히 continuous equality로 확대한 추정이 아니라 위 interval argument에 의존합니다.

[CPU interval/boundary audit](../runs/semantic_manuscript_audit_v1/observation_equivalence.json)은 실제 query/cell 및 endpoint exclusion을 확인합니다. 이 proposition은 현재 lane domain·3 m footprint·지정 observation 시각에 한정됩니다. 일반 3D sensing, 다른 길이, 임의 visibility perturbation의 invariance는 주장하지 않습니다.

## 6. Velocity-envelope audit: 별도 native bound discrepancy

**판정은 현재 1D model에서 native bound/footprint 처리의 별도 discrepancy입니다.** Pure decoder/coordinate shift 또는 polygon sampling 부족만으로 설명되지 않습니다. Bound와 `−3`은 수정하지 않았습니다.

| 표현 / 호출 | 위치 의미와 변환 |
|---|---|
| Reference `q` | 객체의 front; center는 `q−1.5`, rear는 `q−3`, 모두 같은 longitudinal speed를 가집니다. |
| `ds_in=15`, `ds_out=3`, depth=12 | 객체의 center가 아니라 visibility region의 upstream/downstream boundary입니다. Lane 1의 traffic coordinate는 `q=−ds`입니다. |
| `depth−3=9` | `depth<3`이면 vehicle에 너무 짧다는 source branch와 연결된 length correction입니다. Length-12 region에 length-3 object가 들어갈 때 marker가 이동할 수 있는 span은 9입니다. Observation cell boundary의 0.25 m offset과는 다른 보정입니다. |
| `bwd_shadow_FRS` | Outbound를 원점으로 하는 longitudinal position–speed envelope입니다. `dis−depth`로 inbound 측을 두고 downstream FRS boundary를 이어 붙입니다. 하나의 front/rear state 표기라고 명시돼 있지는 않으며, checker에서는 occupancy/boundary envelope로 소비됩니다. |
| `_check_intersection_bwd` | `p_rel=delta_s_from_end(shadow_ds)+processed_ds`, 이후 `translate_polygon(FRS,−p_rel)`입니다. Body center를 가리키는 알려진 object의 FRS는 `bbox.ext_x`로 확장하지만 hidden-shadow 경로에는 별도 center 보정이 없습니다. |

Lane 1에서 physical marker `q_m`의 local coordinate는 `x=q_m+ds_out`이고 checker coordinate는 `x−(ds_out+processed_ds)=q_m−processed_ds`입니다. Reference placeholder는 `ds_out=0`에 absolute traffic `q`를 넣으므로 같은 front point가 같은 checker coordinate로 갑니다. Translation은 speed를 바꾸지 않습니다. Source: [native FRS](../repos/rss_occlusion/risk_analysis/shadow_utils.py), [checker](../repos/rss_occlusion/risk_analysis/state_checker.py), [translation](../repos/rss_occlusion/risk_analysis/reachable_set.py).

Feasible trajectory는 `q(t)=−11.5+6t+2t²`, `v(t)=6+4t`, `0≤t≤1`입니다. t=0, 0.5, 1에서 `(-11.5,6) → (-8,8) → (-3.5,10)`이고 각 footprint는 prescribed hidden field에 들어갑니다. Travel 8 m는 native region의 length correction 후 span 9 m보다 작습니다. 실제 visibility-cell 경계로 계산한 admissible front span은 8.5 m이며 witness는 그 안에서도 양립합니다. 따라서 waypoint/cell 경계의 0.25 m offset으로 만든 반례도 아닙니다. Stationary witness와는 별개입니다.

Native 계산은 다음과 같습니다.

```text
delta_s = depth−3 = 9, delta_t = 1
V_in = (9 − 0.5×8×1²) / 1 = 5
V_out = sqrt(5² + 2×4×9) = sqrt(97) = 9.848857801796104
```

`t_sense=t_predict=1`이면 downstream FRS의 최대 속도도 이 cap이며, sampled inbound curve도 이를 넘지 않습니다. 실제 CPU 계산에서 n=20, 200, 2000 모두 **polygon 전체의 최고 속도**가 동일했습니다. Front local x=−0.5, center x=−2, rear x=−3.5에서 모두 v=10이 제외됐고 native horizontal translation 뒤에도 동일했습니다. Rear 위치의 낮은 bound에는 sampling 차이가 조금 있지만, 전체 cap이 10보다 낮다는 결론에는 영향이 없습니다. 따라서 front/rear/center offset으로 이 witness를 되살릴 수 없습니다.

이 판정은 코드가 사용한 parameters와 명시한 initial/observation/dynamics model에 대한 것입니다. 원문의 일반 theorem이나 원 map의 safety violation을 주장하지 않으며, undocumented policy constraint의 의도를 역추정하지 않습니다. 별도 bound derivation/수정은 후속 연구로 남깁니다. [원시 audit](../runs/semantic_manuscript_audit_v1/velocity_audit.json).

## 7. 지표의 범위

- **Position coverage:** finite `(q,v)` hypothesis의 `q`가 전체 explicit position envelope에 있는지 검사합니다. Count는 고유한 q 위치 개수가 아닙니다.
- **Position–speed coverage:** 같은 hypothesis를 native zero-horizon FRS와 대조합니다. Numeric membership tolerance는 1e−9이며 continuous soundness를 뜻하지 않습니다.
- 핵심 pipeline의 single admission/guard는 **지정 epochs t=2, 2.5, 3, 3.5, 4의 finite position–speed omission을 제거**했습니다. t=1에는 별도 velocity discrepancy가 있습니다.
- 정상 중복 control의 **t=4 position omission 0**은 전체 시간 full-state soundness가 아닙니다. 해당 control의 t=1 native shadow가 핵심 fixture와 같음을 확인했고 moving witness도 cap 밖입니다.
- 여러 시각의 count 합계는 state–time incidences입니다. 기존 summary의 993은 `371+329+293`이며 고유 상태·trajectory·독립 scene 수가 아닙니다.

Stationary witness는 native FRS에 t=2.5까지 포함되다가 Original의 t=3부터 누락됩니다. Guard에서는 모든 검사 시각 t=0,0.5,…,4에 포함됩니다. 이 사실과 moving-witness prefix discrepancy를 분리합니다.
