# Semantic coverage — 중심 발견과 원고 범위

중심 연구 질문은 **“동일한 feasible hidden hypothesis를 뜻하는 observation 조건에서도 shadow worklist reduction이 상태 보존과 허용 행동을 바꿀 수 있는가?”**입니다.

확정한 중심 contribution은 **특정 visibility split과 lane transition에서 처리 기록에 기반한 중복 제거가 feasible hidden hypothesis를 누락하는 메커니즘을 제시하고, 의미적으로 동등한 observation 조건에서도 이 누락이 달라질 수 있음을 보이는 것**입니다. 독립 reference와 국소 개입으로 누락이 native checker의 허용 행동에 영향을 주는 경우와 주지 않는 경우를 구분합니다. **C1이 중심 발견이며, 제한된 guard(C2)와 reference audit(C3)은 이를 뒷받침합니다.** 일반적인 set inclusion이나 reachability verification 자체를 새 이론으로 주장하지 않습니다.

## 1. Evidence의 출처

| 구분 | 이번 원고에 사용하는 근거 |
|---|---|
| 기존 simulator/discovery | [Mechanism findings](mechanism_findings.md)의 pair 4/18/4/4 또는 4/17/4/4, 한 admission으로 18→4, full D05 timeout, sensor-history/time alignment. 549/566은 중복입니다. |
| 기존 semantic discovery | Closed two-lane pipeline, independent rational reference, stationary/moving witnesses, order/redundancy/geometry controls, native checker fixture. Raw run은 보존했습니다. |
| 사용자님이 전달한 별도 리뷰 | 원본 함수 추출에 의한 fixture CPU 재계산과 저장 geometry 검토입니다. CARLA 전체 환경이나 full checker harness의 독립 재현이 아닙니다. [전달받은 결과와 provenance](../notes/semantic_external_review.md). |
| 이번 새 local audit | Observation interval와 boundary 확인, native FRS의 front/center/rear 및 translation audit, near/far 저장 geometry 대조. [실행 코드](../analysis/semantic_coverage/audit_manuscript.py), [manifest](../runs/semantic_manuscript_audit_v1/manifest.json). |
| 이번 결과 재생성 | 명시한 [input bundle](../configs/semantic_report_inputs.json)의 JSON을 읽어 표·figure·수치를 생성했습니다. 새로운 algorithm evaluation이나 scene으로 세지 않습니다. |

이번 작업에서 simulator rollout, task recovery, parameter sweep, UNISafe/RFM 확장을 추가하지 않았습니다. A-star node merge와 shadow worklist는 다른 개입 지점이며, 기존 bounded H가 target branch를 보존하지 못했다는 사실도 유지합니다.

## 2. 전체 표현에서 무엇이 누락됐는가?

[State semantics](shadow_semantics.md)는 hidden object를 lane, front position q, speed, path/history 및 footprint로 정의합니다. Reference는 shadow queue reduction을 호출하지 않습니다.

Closed two-lane fixture는 초기 OutBound와 visibility를 원 `_update_shadow`/`predict_shadow`에 순차 적용합니다. 수작업으로 short/long shadow 두 개만 만든 반례가 아닙니다. Visibility split과 successor transition으로 long job의 queue 재진입이 지연됩니다. Short job `[ds_out,ds_in]=[2,2.5]`가 `(lane=1,ds_out=2)` key를 등록하고 **mature=None**을 반환합니다. 이후 long job `[2,15]`가 같은 searched key 때문에 거절됩니다. [순서가 보존된 raw event](../runs/semantic_minimal_trace_v2/events.json).

Stationary witness는 `front ds(t)=8, v(t)=a(t)=0`, footprint `[8,11]`입니다. t=0…4의 지정 visibility에 양립하고, visibility boundary에서 최소 3.75 m 떨어집니다. Native 표현에는 Original에서 t=2.5까지 포함되고 t=3부터 누락됩니다. t=4 Original의 **전체 forest 크기는 0**이므로 다른 lane/shadow가 대신 포함한다는 설명도 배제됩니다. Guard에는 검사 시각 t=0,0.5,…,4 모두 포함됩니다. [Witness](../runs/semantic_small_graph_v2/witness.json), [native membership 재검사](../runs/semantic_manuscript_audit_v1/velocity_audit.json).

Independent finite reference의 t=3,3.5,4 state 수는 371,329,293이고 Original은 각각 모두 누락합니다. 이는 같은 fixture의 시각별 `(q,v)` hypothesis cardinality입니다. 합계 993은 state–time incidences이며 고유 상태 수나 독립 sample 수가 아닙니다. 반례는 검사한 ablation에 따라 줄였으며 수학적으로 최소인 모든 graph를 탐색했다는 뜻은 아닙니다.

## 3. 한-query 대조군: continuous 의미적 동등성

**Proposition.** 현재 1D model에서 footprint `[q−3,q]`가 visible set과 접촉하면 detection으로 처리할 때, t=2.5의 다음 두 hidden set은 같은 hidden state와 feasible trajectory 집합을 정의합니다. Initial conditions, dynamics, 나머지 observation은 고정합니다.

```text
H_base = (−14.75,−3.25) ∪ (−2.25,−1.75)
H_fill = (−14.75,−3.25)
허용 front 위치 = (−11.75,−3.25)  (두 조건 동일)
```

**Proof.** Observation operator는 전체 footprint와 visible set의 교차를 검사합니다. Footprint는 연결된 길이-3 구간이므로 한 hidden component 안에 완전히 들어가야 합니다. 두 field는 길이 0.5 m인 작은 hidden component만 다릅니다. **0.5 m의 작은 숨은 구간에 3 m footprint가 들어갈 수 없습니다.** 따라서 두 field가 허용하는 front 위치·hidden state가 같습니다. 다른 시각의 observation, initial set, dynamics도 같으므로 그 제약을 만족하는 trajectory 집합도 같습니다. □

Nearest-waypoint cell 생성 및 boundary 포함 규칙을 [상세 proof](shadow_semantics.md)와 [CPU audit](../runs/semantic_manuscript_audit_v1/observation_equivalence.json)에 연결했습니다. 그런데 Original의 t=4 position omission은 base 293, fill 0으로 다릅니다. 즉 **가능한 hidden hypothesis를 바꾸지 않는 관측 표현의 차이가 worklist 처리와 hypothesis 보존을 바꿉니다.** Finite equality만으로 continuous equality를 추측한 주장이 아닙니다. 현재의 1D lane, 3 m footprint, 지정 observation model 밖으로 확장하지 않습니다.

## 4. 동일 candidate와 checker 아래의 판단 변화

Two-lane 결과를 저장된 D05 intersection checker context에 삽입한 CPU fixture입니다. 모든 candidate, checker parameter, object record는 같으며 A-star search/cost를 변경하지 않았습니다. 별도 simulator task rollout은 아닙니다.

<!-- BEGIN GENERATED SEMANTIC RESULTS -->
| Variant | t=4 position omission | t=4 position–speed omission | Allowed action IDs (0-based) |
|---|---:|---:|---|
| original | 293 | 293 | [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17] |
| single_admission | 0 | 0 | [1, 6, 7, 12] |
| reference | reference | reference | [1, 6, 7, 12] |
| mature_coverage_guard | 0 | 0 | [1, 6, 7, 12] |
| structural_key | 0 | not_measured | [1, 6, 7, 12] |

Reference t=4 states: 293; t=4.5 reachable points: 451. Original: 18/18 allowed; reference: 4/18. Reference 대비 추가 허용은 14개입니다. Position/position–speed 값은 t=4의 finite hypothesis에 한정하며 not_measured는 미측정입니다.
<!-- END GENERATED SEMANTIC RESULTS -->

Finite reference의 4→4.5 s reachable point를 hull 없이 MultiPoint로 전달했습니다. Native geometry intersection 연산을 유지하고 coordinate 조회 인터페이스만 추가했습니다. 저장된 32개 MultiPoint는 각각 같은 451 point의 translation이며 CPU geometry audit도 일치했습니다. 두 danger-zone moving witness는 initial state와 control sequence를 역추적했고 t≤4의 observation과 양립합니다. t=4 이후에는 native FRS와 동일하게 추가 observation을 적용하지 않습니다.

예시 action `(173,−0.25,15)`의 stop slack은 −7.3525 m입니다. Single admission/guard의 두 native overlap area는 54.1469253840 / 37.8084298614 m²/s입니다. Reference point set의 area는 0이지만 실제 reachable point가 danger zone에 포함됩니다. 면적 0을 disjoint로 읽지 않습니다. [Action별 수치](../results/semantic_coverage/actions.csv), [위험 구간 trajectory](../runs/semantic_controls_v1/summary.json).

Far control에서는 background lane-135 shadow를 모든 variant에서 공통 제거했습니다. Near에서 해당 background는 관련 32개 검사 모두 danger zone과 disjoint였으며 재계산도 일치했습니다. 추가 component를 같은 checker coordinate에서 100 m upstream으로 옮기면 저장된 far geometry와 일치하고 intersection이 사라집니다. 따라서 이 fixture의 near/far 교차 차이를 background 제거 때문으로 설명할 근거는 없습니다. Reference와 Original 등 모든 variant가 far에서 18개를 허용합니다. 이것은 **omission 발생과 현재 action 영향의 분리**입니다. [Geometry audit](../runs/semantic_manuscript_audit_v1/geometry_audit.json).

직접 입증한 것은 feasible hypothesis omission과 native checker의 추가 허용 행동입니다. Actual collision/unavoidable failure, task completion, 사용자 목표 보존은 다른 claim이며 입증하지 않았습니다.

## 5. 지표·대조군·제한된 guard

<!-- BEGIN GENERATED SEMANTIC CONTROLS -->
<!-- Generated by build_report.py; source counts are not authored in this table. -->
| Condition | Reference states at t=4 | Original position omissions | Guard position omissions |
|---|---:|---:|---:|
| Two-lane split + transition | 293 | 293 | 0 |
| Reversed queue order | 293 | 0 | 0 |
| Successor removed | 293 | 0 | 0 |
| One hidden cell filled | 293 | 0 | 0 |
| Normal redundant copy | 293 | 0 | 0 |
| Different lane lengths | 124 | 124 | 0 |

All omissions above count finite (q,v) hypotheses whose q is outside the position envelope at t=4. They do not assert position–speed coverage at every time.
<!-- END GENERATED SEMANTIC CONTROLS -->

표의 모든 0은 **t=4 finite hypothesis의 position projection**에 대한 결과입니다. 전체 시각의 position–speed soundness가 아닙니다. [시각별 분리 CSV](../results/semantic_coverage/coverage_by_epoch.csv)는 position과 native zero-horizon position–speed omission을 별도 column으로 기록합니다. Structural-key의 미측정 full-state 값을 0으로 채우지 않았습니다.

원 queue 순서와 reversed queue, 동일 history를 가진 redundant cover에서 coverage를 비교했습니다. 임의의 disjoint partition invariance를 증명한 것은 아닙니다. Admission-only guard는 핵심 omission을 제거했지만 visited-only/mature-only는 t=4 position hypotheses 293개를 계속 누락했습니다. Single admission/guard는 지정 epochs t=2,2.5,3,3.5,4에서 finite position–speed omission이 없습니다. 정상 중복 control에도 t=1 moving-witness velocity discrepancy가 존재합니다.

현재 guard는 같은 시각의 committed mature output이 flat/history-identical candidate를 포함하는 제한된 경우에만 제거합니다. Processed input을 certificate로 삼았던 첫 guard는 실패했고 그 run을 보존했습니다. **Committed mature coverage는 이 guard가 사용하는 제한된 보존 조건이지 모든 올바른 deduplication의 필수조건이 아닙니다.** 올바르게 관리되는 pending work 등 다른 설계를 배제하지 않습니다. General cyclic graph termination/continuous soundness는 미증명입니다.

## 6. Velocity audit의 판정

**현재 1D model에서 native bound/footprint 처리의 별도 discrepancy로 분류합니다.** Reference front `q=-3.5,v=10`의 trajectory는 `q(t)=−11.5+6t+2t²`로 만들 수 있고, native shadow의 `ds_in=15, ds_out=3, depth=12`에 대응합니다. `depth−3=9`는 vehicle length를 고려한 span이며 이를 임의 제거하지 않았습니다.

Native `calc_V_max`는 t=1에서 `V_in=(9−4)/1=5`, `V_out=√(25+72)=√97=9.848857801796104`를 반환합니다. n=20,200,2000에서 FRS 전체 maximum speed가 같습니다. Front/center/rear를 각각 대입해도 v=10은 제외되며, checker의 horizontal translation은 speed와 membership 결과를 바꾸지 않습니다. 따라서 pure coordinate decoding이나 polygon sampling으로 설명되지 않습니다. [전체 호출 경로·의미·원시 수치](shadow_semantics.md).

Shadow boundary는 object center가 아니라 visibility geometry입니다. Native FRS는 longitudinal occupancy/boundary envelope로 소비되며 하나의 명시적 front/rear state specification은 없습니다. 그 문서상 한계에도 불구하고 **어느 물리 marker도 global speed cap을 넘을 수 없다는 사실**로 이번 witness의 불일치를 분리할 수 있습니다. 별도 bound 수정은 수행하지 않았습니다. Stationary witness는 이 prefix 문제 없이 포함되다가 queue에서 소실되므로 C1의 원인을 혼동하지 않습니다.

## 7. 주장–근거–반증 조건

| 주장 | 직접 근거 | 반증·축소 조건 | 최종 범위 |
|---|---|---|---|
| **C1 중심 발견** | Empty whole forest와 continuous stationary witness; 동일 observation operator의 base/fill 차이; 18→4 및 동일 allowed IDs | Witness feasibility, footprint observation equality 또는 전체 forest absence가 틀리면 수정/철회 | 특정 visibility split/lane transition/searched-key mechanism, 그리고 checker permission 영향 |
| **C2 보조 적용 조건** | Admission-site ablation, 제한된 history-aware guard, order/redundancy controls | 필요한 history를 잃거나 지정 target epoch에서 feasible state를 누락하면 축소 | 검사한 queue-induced omission의 제거. 보편적 필수조건/전체 soundness 아님 |
| **C3 보조 검증 방법** | Independent reference가 omission을 검출; t=4 정상 position control과 far no-impact를 구분; 별도 prefix full-state discrepancy도 노출 | 초기조건·coordinate mismatch로만 경고하거나 정상 입력에 false omission이면 수정 | 구체적 mechanism의 audit case study. 도구 제작 자체나 일반 검증 정리 아님 |

원문의 hidden reach-avoid/danger-zone framework, history-dependent bounds는 출발점입니다. Belief compression/dominance는 [RRBT, ICRA 2011](https://groups.csail.mit.edu/rrg/papers/abry_icra11.pdf), conservative set prediction은 [SPOT, ICRA 2017](https://archive.air.in.tum.de/2018/Main/Publications/Koschi2017a.pdf) 등 선행연구와 구분합니다. 새 주장은 pinned implementation의 concrete mechanism과 semantics-preserving observation control입니다. [RSS 원문](https://www.roboticsproceedings.org/rss17/p066.pdf), [공식 code](https://github.com/SafeRoboticsLab/Safe_Occlusion_Aware_Planning).

## 8. D05 및 남은 작업

기존 actual prefix 41 observations와 nominal future prediction에 대한 stationary witness compatibility는 유지합니다. D05의 implicit tails 때문에 unrestricted global hidden-state denotation까지 확정하지 않았습니다. C1의 직접 state-set 증거는 closed two-lane fixture입니다. 현재 map은 reconstructed Town01이며 원 map 재현이 아닙니다.

Original/structural-key full D05 모두 timeout이었습니다. 이번 omission이 late waiting/timeout을 일으켰다는 인과 주장은 하지 않습니다. 동일 terminal progress를 equal objective로 보지 않습니다. RFM 연결은 안전 보조 시스템이 대안을 안전하고 가능하다고 판단하는 신뢰성 수준이며, RFM efficacy/사용자 목표 보존/UNISafe 공통 mechanism은 별도 evidence가 필요합니다.

현재 범위의 결과 문단을 작성하기 위해 추가로 필수인 simulator/parameter 실험은 없습니다. 제출용 full manuscript에는 target workshop의 분량·template·scope 적합성에 맞춘 편집, related-work novelty claim의 최종 대조, artifact path/figure caption/citation 점검이 필요합니다. 이 보고서를 full submission 완성으로 부르지 않습니다.

후속 연구로 넘길 것은 native velocity-bound derivation과 수정, implicit-tail의 global semantics, pending-work 방식 등 일반 reduction 설계, 독립 scene의 사전 정의된 평가 및 D05 late waiting입니다. Task recovery나 RFM 확장은 이번 핵심 contribution의 전제로 요구하지 않습니다.

[Workshop 결과 문단·proposition·caption](workshop_results_draft.md), [figure PDF](../results/semantic_coverage/mechanism_and_controls.pdf), [재현 상세와 새/기존 실행 구분](reproducibility.md).
