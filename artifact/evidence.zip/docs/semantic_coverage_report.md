# Controlled coverage and checker evidence

## 1. 전체 표현에서 무엇이 누락됐는가?

[State semantics](shadow_semantics.md)는 hidden object를 lane, front position q, speed, path/history 및 footprint로 정의합니다. Reference는 shadow queue reduction을 호출하지 않습니다.

Closed two-lane fixture는 초기 OutBound와 visibility를 원 `_update_shadow`/`predict_shadow`에 순차 적용합니다. 수작업으로 short/long shadow 두 개만 만든 반례가 아닙니다. Visibility split과 successor transition으로 long job의 queue 재진입이 지연됩니다. Short job `[ds_out,ds_in]=[2,2.5]`가 `(lane=1,ds_out=2)` key를 등록하고 **mature=None**을 반환합니다. 이후 long job `[2,15]`가 같은 searched key 때문에 거절됩니다. [순서가 보존된 raw event](../runs/semantic_minimal_trace_v2/events.json).

Stationary witness는 `front ds(t)=8, v(t)=a(t)=0`, footprint `[8,11]`입니다. t=0…4의 지정 visibility에 양립하고, visibility boundary에서 최소 3.75 m 떨어집니다. Native 표현에는 Original에서 t=2.5까지 포함되고 t=3부터 누락됩니다. t=4 Original의 **전체 forest 크기는 0**이므로 다른 lane/shadow가 대신 포함한다는 설명도 배제됩니다. Guard에는 검사 시각 t=0,0.5,…,4 모두 포함됩니다. [Witness](../runs/semantic_small_graph_v2/witness.json), [native epoch outputs](../runs/semantic_small_graph_v2/pipeline_two_lanes__original.json).

Independent finite reference의 t=3,3.5,4 state 수는 371,329,293이고 Original은 각각 모두 누락합니다. 이는 같은 fixture의 시각별 `(q,v)` hypothesis cardinality입니다. 합계 993은 state–time incidences이며 고유 상태 수나 독립 sample 수가 아닙니다. 반례는 검사한 ablation에 따라 줄였으며 수학적으로 최소인 모든 graph를 탐색했다는 뜻은 아닙니다.

## 2. 한-query 대조군: continuous 의미적 동등성

**Proposition.** 현재 1D model에서 footprint `[q−3,q]`가 visible set과 접촉하면 detection으로 처리할 때, t=2.5의 다음 두 hidden set은 같은 hidden state와 feasible trajectory 집합을 정의합니다. Initial conditions, dynamics, 나머지 observation은 고정합니다.

```text
H_base = (−14.75,−3.25) ∪ (−2.25,−1.75)
H_fill = (−14.75,−3.25)
허용 front 위치 = (−11.75,−3.25)  (두 조건 동일)
```

**Proof.** Observation operator는 전체 footprint와 visible set의 교차를 검사합니다. Footprint는 연결된 길이-3 구간이므로 한 hidden component 안에 완전히 들어가야 합니다. 두 field는 길이 0.5 m인 작은 hidden component만 다릅니다. **0.5 m의 작은 숨은 구간에 3 m footprint가 들어갈 수 없습니다.** 따라서 두 field가 허용하는 front 위치·hidden state가 같습니다. 다른 시각의 observation, initial set, dynamics도 같으므로 그 제약을 만족하는 trajectory 집합도 같습니다. □

Nearest-waypoint cell 생성 및 boundary 포함 규칙을 [상세 proof](shadow_semantics.md)와 [CPU audit](../runs/semantic_manuscript_audit_v1/observation_equivalence.json)에 연결했습니다. 그런데 Original의 t=4 position omission은 base 293, fill 0으로 다릅니다. 즉 **가능한 hidden hypothesis를 바꾸지 않는 관측 표현의 차이가 worklist 처리와 hypothesis 보존을 바꿉니다.** Finite equality만으로 continuous equality를 추측한 주장이 아닙니다. 현재의 1D lane, 3 m footprint, 지정 observation model 밖으로 확장하지 않습니다.

## 3. 동일 candidate와 checker 아래의 판단 변화

Two-lane 결과를 저장된 D05 intersection checker context에 삽입한 CPU fixture입니다. 모든 candidate, checker parameter, object record는 같으며 A-star search/cost를 변경하지 않았습니다. 별도 simulator task rollout은 아닙니다.

| Variant | t=4 position omission | t=4 position–speed omission | Allowed action IDs (0-based) |
|---|---:|---:|---|
| original | 293 | 293 | [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17] |
| single_admission | 0 | 0 | [1, 6, 7, 12] |
| reference | reference | reference | [1, 6, 7, 12] |
| mature_coverage_guard | 0 | 0 | [1, 6, 7, 12] |
| structural_key | 0 | not_measured | [1, 6, 7, 12] |

Reference t=4 states: 293; t=4.5 reachable points: 451. Original: 18/18 allowed; reference: 4/18. Reference 대비 추가 허용은 14개입니다. Position/position–speed 값은 t=4의 finite hypothesis에 한정하며 not_measured는 미측정입니다.

Finite reference의 4→4.5 s reachable point를 hull 없이 MultiPoint로 전달했습니다. Native geometry intersection 연산을 유지하고 coordinate 조회 인터페이스만 추가했습니다. 저장된 32개 MultiPoint는 각각 같은 451 point의 translation이며 CPU geometry audit도 일치했습니다. 두 danger-zone moving witness는 initial state와 control sequence를 역추적했고 t≤4의 observation과 양립합니다. t=4 이후에는 native FRS와 동일하게 추가 observation을 적용하지 않습니다.

예시 action `(173,−0.25,15)`의 stop slack은 −7.3525 m입니다. Single admission/guard의 두 native overlap area는 54.1469253840 / 37.8084298614 m²/s입니다. Reference point set의 area는 0이지만 실제 reachable point가 danger zone에 포함됩니다. 면적 0을 disjoint로 읽지 않습니다. [Action별 수치](../runs/semantic_action_check_serialization_v3/results.json), [위험 구간 trajectory](../runs/semantic_controls_v1/summary.json).

Far control에서는 background lane-135 shadow를 모든 variant에서 공통 제거했습니다. Near에서 해당 background는 관련 32개 검사 모두 danger zone과 disjoint였으며 재계산도 일치했습니다. 추가 component를 같은 checker coordinate에서 100 m upstream으로 옮기면 저장된 far geometry와 일치하고 intersection이 사라집니다. 따라서 이 fixture의 near/far 교차 차이를 background 제거 때문으로 설명할 근거는 없습니다. Reference와 Original 등 모든 variant가 far에서 18개를 허용합니다. 이것은 **omission 발생과 현재 action 영향의 분리**입니다. [Geometry audit](../runs/semantic_manuscript_audit_v1/geometry_audit.json).

직접 입증한 것은 feasible hypothesis omission과 native checker의 추가 허용 행동입니다. Actual collision/unavoidable failure, task completion, 사용자 목표 보존은 다른 claim이며 입증하지 않았습니다.

## 4. 지표·대조군·제한된 guard

| Condition | Reference states at t=4 | Original position omissions | Guard position omissions |
|---|---:|---:|---:|
| Two-lane split + transition | 293 | 293 | 0 |
| Reversed queue order | 293 | 0 | 0 |
| Successor removed | 293 | 0 | 0 |
| One hidden cell filled | 293 | 0 | 0 |
| Normal redundant copy | 293 | 0 | 0 |
| Different lane lengths | 124 | 124 | 0 |

All omissions above count finite (q,v) hypotheses whose q is outside the position envelope at t=4. They do not assert position–speed coverage at every time.

표의 모든 0은 **t=4 finite hypothesis의 position projection**에 대한 결과입니다. 전체 시각의 position–speed soundness가 아닙니다. 시각별 position 및 native position–speed 기록는 position과 native zero-horizon position–speed omission을 별도 column으로 기록합니다. Structural-key의 미측정 full-state 값을 0으로 채우지 않았습니다.

원 queue 순서와 reversed queue, 동일 history를 가진 redundant cover에서 coverage를 비교했습니다. 임의의 disjoint partition invariance를 증명한 것은 아닙니다. Admission-only guard는 핵심 omission을 제거했지만 visited-only/mature-only는 t=4 position hypotheses 293개를 계속 누락했습니다. Single admission/guard는 지정 epochs t=2,2.5,3,3.5,4에서 finite position–speed omission이 없습니다. Full-state coverage의 별도 auxiliary audit는 공개 저장소 ancillary/README.md에 구분되어 있습니다.

현재 guard는 같은 시각의 committed mature output이 flat/history-identical candidate를 포함하는 제한된 경우에만 제거합니다. Processed input을 certificate로 삼았던 첫 guard는 실패했고 그 run을 보존했습니다. **Committed mature coverage는 이 guard가 사용하는 제한된 보존 조건이지 모든 올바른 deduplication의 필수조건이 아닙니다.** 올바르게 관리되는 pending work 등 다른 설계를 배제하지 않습니다. General cyclic graph termination/continuous soundness는 미증명입니다.

