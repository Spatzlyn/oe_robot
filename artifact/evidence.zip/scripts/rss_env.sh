#!/usr/bin/env bash
# Source from Bash; this does not modify the caller's base Python environment.
SPAIS_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
export SPAIS_ROOT
export CUDA_VISIBLE_DEVICES=6
export CARLA_ROOT="${CARLA_ROOT:-$SPAIS_ROOT/assets/carla-0.9.11}"
export PYTHONPATH="$CARLA_ROOT/PythonAPI/carla/dist/carla-0.9.11-py3.7-linux-x86_64.egg:$CARLA_ROOT/PythonAPI/carla:$SPAIS_ROOT/repos/rss_occlusion:$SPAIS_ROOT/scripts${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
export MPLBACKEND=Agg
export PYGLET_HEADLESS=true
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export SDL_AUDIODRIVER=dummy
export SPAIS_RSS_PYTHON="$SPAIS_ROOT/envs/rss/bin/python"
