# D1의 native 생성 가능성: bounded 감사 결과

Native initialization 형태에서 시작한 update가 **retained leaf subset 때문에 더 큰 candidate를 거절하는 관계 자체는 만들었습니다.** 그러나 기존 D1에서 중요했던, 가능한 branch witness를 포함하는 candidate가 제거되어 whole forest에서 그 witness가 사라지는 연결은 이번 범위에서 재현하지 못했습니다. 두 결과를 구분해야 합니다.

별도로 같은 탐색에서 관찰한 stationary witness 누락 중 대표 하나는 **visited-lane reduction**에 귀속됐습니다. 이는 D1의 mature predicate 누락이 아니며, 다른 34개 조건의 원인을 함께 확정하지 않았습니다. 추가 sweep은 하지 않았습니다.

## 실행 전 조건과 denominator

`development_protocol.json`을 실행 전에 고정했습니다. Native source revision은 `2b6b06637850b406cfbeab926a3dedc01edad91e`입니다. 원본 source는 변경하지 않았습니다.

초기 forest를 직접 만들지 않고 native `create_shadow(100,18,None,0,'in',None)` 하나로 시작했습니다. 이는 `update_visibility` 초기화가 사용하는 forward constructor 형태이지만, 이 값이 실제 wrapper offset을 통해 만들어지는지는 처음 256개 실행에서 검증하지 않았습니다. 이후 native cross/merge 생성 경로, `predict_shadow`, `_update_shadow`, split·filter·mature predicate를 실행했습니다. Road network는 ego lane 100→101, 두 lane에서 risk lane 1을 cross 대상으로 두며, risk lane 1의 predecessors는 branch 2·3인 synthetic topology입니다. Native update에 전달한 visibility는 지정 field입니다. **CARLA map·실제 camera·DepthVisibility·client wrapper 전체를 재현한 실험은 아닙니다.** 별도 sensor 실험과 합쳐 하나의 실행으로 해석하지 않습니다. 아래 별도 2-case control에서 actual wrapper의 합법적인 초기화를 추가 확인했습니다.

각 branch의 stationary front ds=8, footprint [8,11], v=a=0을 고정했습니다. 모든 observation에서 footprint 주변의 waypoint [7.5,11.5]까지 hidden인지 확인했고, nearest-waypoint cell의 경계를 고려해도 footprint가 visible cell과 만나지 않습니다. Position–speed 전역 reference를 새로 만든 것은 아닙니다.

| 분모 | 값 | 의미 |
| --- | ---: | --- |
| 사전 지정 development schedule | 256 | 16 deterministic templates + seed 240925의 240 bounded schedules |
| 각 schedule의 observation epoch | 5 | t=0,0.25,0.5,0.75,1 s |
| Primary native update | 1,280 | 256×5; 독립 physical episode가 아님 |
| Completed / invalid / incomplete | 256 / 0 / 0 | 5 s / 1,000 queue-pop administrative cap 미도달 |
| Native strict-subset rejection이 나타난 조건 | 41 | 나머지 215개도 보존 |
| 그 rejection event | 132 | 조건별 반복 event이며 독립 반례 수가 아님 |
| 별도 uninstrumented parity replay | 41 cases, 205 updates | 해당 41개 조건의 전체 epoch forest 일치 |
| Same-input mature-only OFF | 46 epoch updates | subset event가 있었던 epoch별 제한 개입 |
| Harmful native D1의 stationary witness 회복 | 0 | 미발견; 원칙적 불가능성이나 모든 상태에 대한 soundness 아님 |
| 별도 legal-wrapper initialization | 2 cases, 10 updates | 초기 inbound 17.5에서 시작한 actual wrapper output을 기존 두 case에 대조 |

모든 256개 조건에서 두 stationary witnesses는 genesis update 직후 전체 output에 포함됐습니다. Input generation이 처음부터 이 witness를 다루지 않은 사례를 뒤늦은 loss로 세지 않았습니다. Queue·primitive·생성·prediction·mature candidate·retained 및 pending·최종 forest를 `development/*.json`에 보존했습니다. Source SHA256 불변 확인과 분모는 `verification.json`, 조건별 표는 `development_matrix.csv`에 있습니다. CPU만 사용했습니다.

## Native에 생성된 관계와 기존 D1의 차이

| 항목 | 기존 hand-built D1 | 이번 native-generated subset relation |
| --- | --- | --- |
| Initial uncertainty forest | 수작업으로 {2}, {2,3} 구성 | Single native forward genesis부터 생성 |
| Candidate의 branch terminal inbound | ds_in=15 | 132개 event 모두 branch 2·3의 ds_in=0 |
| Candidate가 branch stationary [8,11] witness를 포함하는가 | 포함 | 포함하지 않음: branch의 명시적 구간이 downstream endpoint에서 끝남 |
| 추가 branch identity가 존재하는가 | 존재 | 존재; 따라서 leaf ID만 보면 같은 관계처럼 보임 |
| Whole output의 해당 witness 누락 | 기존 D1에서 확인 | 이 mature-subset event를 이유로 확인하지 못함 |
| Mature-only OFF의 해당 witness recovery | 기존 D1에서 확인 | 46개 same-input epoch replay에서 0 |

예를 들어 `D_template_012`, t=0.75에서 retained의 leaf signature {(2,4.5)}가 candidate {(2,4.5),(3,4.5)}에 포함되어 native predicate가 candidate를 거절합니다. Candidate root는 lane 1의 ds_out=15.5이고 두 branch leaf는 ds_in=0입니다. 이 candidate는 branch 3의 ds=8 위치를 담당하지 않습니다. 최종 forest의 다른 branch representation이 두 stationary witnesses를 보존합니다.

전체 132개 subset event 중 125개에서는 최종 forest에 두 stationary witnesses가 모두 있습니다. 나머지 7개 event는 `D_seeded_021`의 t=0.75와 `D_seeded_110`의 t=1.0에 있으며 branch 2 absence가 함께 발생합니다. 그러나 이들 candidate도 ds_in=0으로 해당 witness를 포함하지 않고, same-input mature-only OFF 역시 absence를 회복하지 않습니다. 따라서 “132개 모두 harmless임을 증명했다”거나 “7개가 harmful D1이다”라고 판정하지 않습니다. 이 두 조건은 원인이 아직 분리되지 않은 34개 absence 조건에 포함됩니다.

따라서 이번 결과는 “D1을 native pipeline에서 재현했다”보다 좁습니다. **형태상 subset relation은 native reachable하지만, 기존 D1의 의미 있는 추가 coverage와 whole-forest loss까지 이어지는 입력은 확보되지 않았습니다.** Branch ID 차이만 검사하면 이번 사례를 harmful omission으로 잘못 분류했을 것입니다. 관측 이력·bound·전체 union을 함께 검사해야 하는 이유를 보여 주는 negative control입니다.

Moving witness, junction을 가로지르는 footprint, velocity/history의 차이는 이번 stationary oracle의 범위 밖입니다. Candidate가 두 stationary witnesses를 포함하지 않는다는 사실을 candidate 전체가 의미상 불필요하다는 증명으로 사용하지 않습니다. 동일한 position projection에서도 history-dependent 속도 제약이 다를 수 있습니다.

## Source로 확인한 생성 조건과 아직 없는 impossibility proof

Native `_update_bwd_shadow`는 현재 node에 child가 없을 때 road graph의 predecessors를 확장하고, 이미 child가 있으면 기존 child를 순회합니다. `_split_bwd_shadow`는 해당 subtree나 inbound history를 이어받고, `_check_fully_processed`는 기존 inbound에 도달하면 해당 branch 탐색을 멈춥니다. 따라서 fork topology가 있다는 사실만으로 서로 다른 live branch coverage를 가진 중첩 forest가 항상 생기지는 않습니다. 서로 다른 generation·split·history 경로가 필요할 수 있습니다.

이번 trace에서는 native branch splits와 prediction으로 단일 branch 표현 및 공통 root가 생성됐고, 끝점 ds_in=0을 갖는 subset relation이 생겼습니다. 이것은 실제 executable 경로에 대한 근거입니다. 반대로 이번 search는 1개 topology와 지정된 observation·horizon 범위이므로 “ds_in=15인 D1 forest는 native에서 생성 불가능하다”는 invariant를 입증하지 않습니다. 검색에 사용한 schedule을 모두 development로 두었고, harmful D1이 미확보여서 그 주장에 대한 held-out confirmation은 실행하지 않았습니다.


## Actual wrapper의 합법적인 초기화: 두 대표의 추가 control

최종 source review에서 initial ds=18의 범위를 좁혀야 한다는 점을 발견했습니다. Native `update_visibility`는 positive lane에서 `ds_start = ego_waypoint.s - lane_section.s_start - 2.5`를 사용합니다. 길이 20 lane 안의 합법적 ego coordinate만 허용하면 ds_start=18은 ego local ds=20.5를 요구하므로 처음 constructor call 자체를 actual wrapper initialization이라고 부르면 안 됩니다.

이 불확실성만 해소하기 위해 `wrapper_initialization_check/protocol.json`을 먼저 고정하고 `D_template_000`과 `D_template_012`의 두 대표를 재검사했습니다. Synthetic map interface가 합법적인 ego local ds=20을 반환하게 했고, **실제 native `update_visibility`가 ds_start=17.5를 계산하고 모든 후속 predict/update를 호출**했습니다. Native sensor interface는 기존 prescribed visibility stub이며 실제 depth images가 아닙니다.

두 case 모두 t=0의 filtered output부터 5개 epoch의 전체 forest가 기존 ds=18 constructor형 실행과 정확히 같았습니다. 초기 visible 구간을 처리한 뒤 inbound는 같은 ds=15가 됐다는 실제 결과입니다. Native constructor input 17.5와 합법적인 waypoint 여부를 raw에 기록했습니다. 이로써 visited 대표와 native subset 대표의 생성 경로를 해당 두 조건에서 합법적인 wrapper initialization에 연결했습니다. 나머지 254개 schedule의 wrapper parity를 실행한 것은 아니며, 실제 CARLA map extraction·sensor frontend의 재현도 아닙니다. 추가 2 sequences / 10 native updates는 모두 completed, invalid 0입니다. 이 control은 posthoc compatibility 확인이지 held-out scientific validation이 아닙니다.

## 별도로 발견된 visited-lane 경로: 대표 1개만 원인 확인

Primary search 전체에서 35개 조건, 104 witness–time incidences의 stationary position absence가 있었습니다. 이 숫자는 모두 D1 반례가 아닙니다. 첫 ordered case인 `D_template_000`을 선택하고 `representative_attribution_protocol.json`을 새 실행 전에 작성해 원인을 좁혔습니다.

Native 생성 과정은 다음과 같습니다.

1. t=0에서 single forward initialization이 cross lane 1의 backward work를 만들고, 두 branch의 hidden interval은 별도 flat shadows로 유지됩니다. 전체 forest에 두 witnesses가 있습니다.
2. t=0.25 native prediction은 branch 2·3의 flat shadows를 lane 1을 root로 하는 backward jobs로 이동시킵니다. 각각의 child `InBound(ds_in=15)`는 해당 stationary witness를 여전히 포함합니다.
3. 먼저 처리되는 기존 lane-1 root의 ds_out은 0입니다. 이 표현의 branch children은 ds_in=0이라 stationary branch witnesses를 포함하지 않습니다.
4. 이 root를 처리하며 native `visited_lanes`에 lane 1이 등록됩니다.
5. 뒤의 native-predicted lane-1 jobs가 lane-only visited check에서 생략됩니다. 해당 job은 mature predicate에 도달하지 않습니다.
6. 최종 전체 forest에 branch 2·3의 ds=8을 포함하는 다른 output이 없습니다.

같은 prefix와 t=0.25 predicted input에 다음 개입을 각각 적용했습니다. Epoch 0 forest 및 target predicted input은 모든 비교에서 archived Original과 정확히 일치합니다. 새 logging만 붙인 Original의 전체 5-epoch output도 기존과 일치했습니다.

| Target epoch 개입 | Branch 2 stationary witness | Branch 3 stationary witness |
| --- | --- | --- |
| Original + 추가 decision logging | 누락 | 누락 |
| Admission-only OFF | 누락 | 누락 |
| Mature-only OFF | 누락 | 누락 |
| Visited-only OFF | 포함 | 포함 |

이 대표에서는 visited-lane 생략이 해당 위치 누락의 직접적 원인이라는 국소 개입 근거가 생겼습니다. Admission gate나 D1의 mature-output predicate가 직접 원인이라는 설명은 이 대표의 개입 결과와 맞지 않습니다. Native genesis부터 생성됐지만 prescribed visibility를 사용하는 synthetic pipeline 결과이며, 실제 sensor 장면 발생률·same-checker permission·collision·task completion은 측정하지 않았습니다.

다른 34개 조건의 원인은 아직 분리하지 않았습니다. 나머지를 모두 visited-lane 결함으로 라벨링하거나 104개를 독립적인 오류 수로 보고하지 않습니다. `development_missing_witness_inventory.json`에 모두 남겼습니다. 이 대표의 추가 4개 실행은 posthoc development attribution이며 held-out validation이 아닙니다.

## 기존 실험 방식이 드러내지 못했던 것

기존 D1은 mature predicate의 집합 포함 방향과 가능한 witness loss를 명확하게 분리했지만, 해당 forest의 생성 경로를 관찰하지 않았습니다. Native genesis부터 추적하자 비슷한 branch signature를 가진 candidate도 실제 bounds가 달라 기존 witness를 담당하지 않을 수 있다는 점을 확인했습니다. Output만 비교하거나 branch identity만 보는 oracle로는 이 차이를 놓칩니다.

또한 이번 native-generated stationary absence는 mature predicate 이전의 visited gate에서 발생했습니다. Final omission 하나만 보고 D1으로 분류했다면 다른 reduction stage를 혼동했을 것입니다. 모든 기존 repair를 다시 대규모 비교하는 대신, 대표 조건에서 stage별 단일 OFF를 적용해 직접 원인을 분리했습니다.

검증한 결과의 범위는 다음과 같습니다.

- Native update가 subset relation을 생성할 수 있다는 executable 근거와, 그것만으로 기존 harmful D1의 발생을 입증하지 않는다는 경계.
- 동일한 branch identity라도 bound/history·whole output coverage를 확인해야 한다는 평가 요구.
- 별도 native-generated 대표에서 visited-lane 기록이 witness-bearing 작업을 차단하는 국소 메커니즘과 해당 gate만 끈 회복.

Harmful D1의 sensor-realized 발생, moving/history state의 전역 보존, 실제 failure 빈도와 일반 termination은 미검증입니다. Hand-built D1과 native-generated 결과의 범위는 별개입니다.

## Artifact와 재현 범위

공개 재현 명령은 repository root의 reproduce/README.md를 참조하십시오. Aggregate 수치는 aggregate_checks.json에 있습니다.

- `development_protocol.json`, `development_schedule.json`: 사전 고정 범위와 전체 schedule.
- `run_native_search.py`, `development/*.json`: native genesis부터 최종 union까지 raw trace. `__plain.json`은 별도 instrumentation parity replay입니다.
- `development_matrix.csv`, `verification.json`: 모든 조건·분모와 source 불변 검사.
- `native_subset_event_index.json`: 132개 subset event 및 관련 coverage에 대한 index.
- `representative_attribution_protocol.json`, `audit_representative.py`, `representative_attribution/`: 대표 visited-stage 원인 비교.
- `native_source/`: 감사 시점의 pinned 원본 복사본. 실행에서는 project 원본을 읽었고 파일을 수정하지 않았습니다.
- `wrapper_initialization_check/`: 합법적인 native wrapper initialization을 검사한 사전 protocol, 두 case raw, parity 결과.

```bash
bash environment/run_native.sh reproduce/run.py native-search --output outputs/native_search
bash environment/run_native.sh reproduce/run.py native-attribution --output outputs/native_attribution
```

Script는 기존 output directory에 새 실행을 덮어쓰지 않도록 `exist_ok=False`를 사용합니다. 재실행은 별도 output 경로와 명시한 ROOT에서 수행해야 합니다. 기존 raw와 생성 함수, source hash를 그대로 보존했습니다.
