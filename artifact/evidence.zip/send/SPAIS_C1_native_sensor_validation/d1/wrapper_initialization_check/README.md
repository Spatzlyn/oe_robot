# Legal native wrapper initialization control

기존 256개 development는 native constructor에 initial ds=18을 직접 전달했습니다. Positive lane length20과 native -2.5 offset 아래에서는 이 값이 actual wrapper에서 발생 가능한지 보장하지 못했습니다. 이 제한을 발견한 뒤 protocol을 고정하고 두 대표만 재검사했습니다.

Actual `ShadowUtils.update_visibility`에 합법적인 ego local ds=20인 synthetic map waypoint를 주면 native initial inbound는17.5입니다. Prescribed visibility stub은 기존과 같으며 actual DepthVisibility/image frontend는 사용하지 않습니다.

D_template_000과 D_template_012의 전체5epoch output은 각각 기존 constructor-ds18 raw와 exact numeric/object-value equality가 성립했습니다. 2sequences/10nativeupdates, completed2, invalid0입니다. Native constructor calls, repeated predicate events, 모든 post-update forest를 저장했습니다. 나머지254조건의 wrapper parity, real map/sensor 생성, harmfulD1의 발생을 검증한 것으로 확대하지 않습니다.
