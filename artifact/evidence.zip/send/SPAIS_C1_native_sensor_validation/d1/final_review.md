# 종합 보고서의 D1 범위·분모 독립 검토

새 native 실행 없이 root `report.md`와 `c1/report.md`를 읽고 D1 raw JSON을 다시 집계했습니다. C1의 34 native sequences / 306 updates / pre-native invalid 1은 root analysis summary와 대조했으며, sensor implementation의 독립 검증은 이 검토의 범위가 아닙니다.

D1 primary 256 conditions / 1,280 updates, subset event 조건 41 / event 132, plain replay 41 / 205 updates, same-input mature-only OFF 46 updates, visited attribution 4 variants / 20 updates가 보고서와 일치했습니다. Stationary absence는 35 conditions / 104 witness–time incidences이며 대표 1개만 원인을 확인한 분리가 유지됩니다. 132개 subset event 중 125개는 최종 output이 두 witnesses를 보존하지만, 7개 event(D_seeded_021의 t=0.75 및 D_seeded_110의 t=1.0)에는 branch 2 absence가 함께 발생했습니다. 해당 candidate 자체는 지정 stationary witness를 포함하지 않고 mature-only OFF도 이를 회복하지 않았으므로 동시 발생을 D1 원인으로 귀속할 수 없습니다. Root §3의 일괄 보존 표현은 이 구분으로 수정해야 합니다. Harmful D1의 native realization을 아직 확보하지 못했다는 판정과 moving/history 의미 미검증도 명확합니다.

Native constructor와 full frontend, prescribed observation과 C1 sensor renderer, 같은 prefix의 local intervention과 전체 외생 sequence의 method comparison, 기존 checker evidence와 새 sensor evidence, 실제 RFM 결과와 적용 함의를 구분한 점은 현재 근거와 맞습니다. D1 denominator는 맞지만 위 7개 coabsence를 모두 보존됐다고 서술한 부분은 수정이 필요합니다. Harmful D1을 아직 확보하지 못했다는 판정은 유지됩니다.

수정 권고는 두 가지입니다.

1. Root §1의 “None은 충분한 사례 조건”은 None만으로 omission이 충분해지는 뜻으로 읽힐 수 있습니다. “None은 기존 C1에서 관찰된 조건이며 모든 admission omission의 필요조건은 아님”이 정확합니다. 후속 required work와 key collision, 대체 coverage의 부재가 별도로 필요합니다.
2. 분모 표의 “harmful-D1 positive0”에는 “지정 stationary-position oracle에서”를 붙이면 moving/history state까지 전수 검사한 0으로 읽히지 않습니다.

Raw `d1/development/`는 변경하지 않았습니다. 검토한 문서의 당시 hash와 재집계 숫자는 `final_review.json`에 기록했습니다.

추가로 initial constructor의 ds=18이 positive length-20 lane의 실제 wrapper offset과 양립하는지는 별도 검증이 필요하다는 source issue를 확인했습니다. `wrapper_initialization_check/`의 별도 2-case control에서 합법적인 ego ds=20과 wrapper 생성 ds=17.5를 검사하며, 결과를 보기 전 기존 256조건을 full wrapper realization으로 부르지 않습니다.

위 initialization follow-up은 두 case 모두 completed이며 initial17.5 actual wrapper의 전체5epoch output이 기존 initial18 constructor형 raw와 같았습니다. 이 결과는 해당 두 대표의 wrapper 생성 가능성만 보완하며 나머지254조건이나 actual sensor/frontend로 확대하지 않습니다.
