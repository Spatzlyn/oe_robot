# SPAIS C1 재감사 종합: 결과, 인과관계, 논문 기여와 후속 방향

작성일: 2026-09-24  
대상 자료: Google Drive의 SPAIS/strengthening/0924/SPAIS_reaudit  
문서 성격: 업로드된 실험·원자료·코드·문헌 감사와 대화에서의 종합 판단을 연결한 연구 의사결정 문서  
기준: 2026-09-24 재감사 묶음의 최종 보고서와 업로드 완료 기록. 이 문서를 작성하면서 새로운 simulator/RFM 실험을 실행하지 않았습니다.

## 1. 핵심 판단과 이 문서의 목적

이번 재감사는 C1 중심 논문의 실험적 근거를 보강했습니다. 기존 C1을 해결하는 간단한 수정의 효과와 비용을 확인했고, 그 수정이 다른 reduction 단계에서는 충분하지 않을 수 있다는 별도의 구성 사례와, candidate가 제거돼도 실제 누락은 생기지 않는 대조 조건을 확보했습니다. 따라서 논문은 구체적 결함의 발견에서 출발해 원인, 판단 영향, 기존 수정의 충분성과 경계, 독자가 적용할 평가 항목까지 연결할 수 있습니다.

동시에 새롭고 복잡한 reduction 알고리즘이 필요하다는 결론은 나오지 않았습니다. 기존 guard와 backward reduction을 끄는 방법은 검사한 명시적 사례에서 필요한 witness를 보존했습니다. 작은 C1에서 추가 비용도 작았습니다. 이 결과를 있는 그대로 채택해야 하며, 새 방법이 반드시 필요하도록 문제를 재정의해서는 안 됩니다.

현재 가장 중요한 공백은 실제 적용 환경과의 연결입니다. C1의 관측은 지정한 모델 안에서 구성한 visibility이고, 새 D1의 초기 uncertainty forest도 직접 만들었습니다. 실제 센서·초기화·상태 갱신 경로가 해당 구조를 만드는지는 아직 검증되지 않았습니다. 코드 수준의 원인 분석과 실제 환경에서의 발생 가능성은 서로 다른 질문입니다.

이 문서의 목적은 다음 네 질문에 답하는 것입니다.

1. 무엇이 이미 알려져 있으며, 우리 자료가 구체적으로 무엇을 더 보여 주는가?
2. 그 사실이 실제 안전 시스템의 설계·평가에 왜 중요한가?
3. 어떤 실행 원인과 조건에서 문제가 발생하고, 어떤 조건에서는 발생하지 않는가?
4. 향후 안전 모듈을 만들거나 평가할 때 무엇을 확인해야 하며, 현재 논문을 강화할 다음 작업은 무엇인가?

여기서 ‘확인’은 원자료·코드·검사한 모델과 입력 범위 안에서의 확인을 뜻합니다. 별도 표시한 ‘해석’과 ‘후속 제안’은 실험 결과 자체가 아닙니다.

## 2. 자료의 범위와 이번 검토가 수행한 일

### 2.1 사용한 자료

주요 근거는 최종 연구 보고서, sufficiency 원자료, branch development/validation 기록, native 코드와 개입 코드, 실험 방법 감사, 문헌 감사, 보존 요구사항, 논문 개요입니다. 원자료 링크는 문서 끝의 출처 목록에 모았습니다.

직전 분석에서는 폴더 전체 파일 목록을 확인하고, 비용 측정 원자료 715개 기록을 재집계했습니다. 55개 방법–조건 조합의 시간 집계와 실행 분모를 대조했으며, decoder 수정 전후 D1의 입력·최종 출력·실행 사건 기록이 동일함을 확인했습니다. Boundary 기록 36개가 모두 completed이고 각 기록의 instrumentation parity가 참인 것도 재집계했습니다. 핵심 텍스트 파일 일부의 해시를 manifest와 대조했지만, 모든 파일의 해시를 제가 독립적으로 전수 검증했다고 주장하지는 않습니다.

업로드 측에서는 scientific payload 322개(manifest 포함)의 완료 검증 기록이 올라왔습니다. 검증 로그에는 당시 임시 receipt를 포함한 323개 파일 일치, 차이 0이 기록돼 있습니다. 이는 전달 완전성에 대한 기록이며 연구 결과의 과학적 타당성 검사와는 별개입니다.

이 문서 작성 시에는 최종 보고서, 논문 개요, 보존 요구사항, 방법 감사, 문헌 감사를 다시 읽어 최신 본문과 종합 내용을 대조했습니다. 새 native 실행이나 CPU benchmark 재실행은 하지 않았습니다.

### 2.2 숫자의 분모를 구분해야 하는 이유

| 숫자 | 실제 의미 | 의미하지 않는 것 |
|---|---|---|
| 7개 기존 조건 | 기존 C1 pipeline 및 관련 control 조건 | 7개 독립 자연 장면 |
| 1/4/16/64 copy | 같은 의미의 worklist 중복 규모 | 서로 다른 실제 환경 |
| 55개 조합 | 11개 조건 × 5개 방법 | 55개 독립 안전 사건 |
| 715개 기록 | 조합마다 timing 11회, instrumentation 1회, memory 1회 | 715개 robot episode |
| 36개 boundary trace | 구 decoder development 5 + 새 decoder development 5 + validation 25 + mature-only 개입 1 | 36개 독립 구조 또는 장면 |
| 72회 boundary update | trace 36회와 별도 parity 확인 36회 | 72개 새로운 반례 |
| 293 | 원 C1 t=4에서 누락된 finite reference 항목 수 | 293개 collision 또는 실험 episode |
| 14 | 고정된 18개 candidate에서의 permission 차이 | 14개 충돌, 위험 확률 또는 task failure |

반복 측정의 수가 많다는 사실과 구조·환경의 다양성이 넓다는 사실을 구분해야 합니다. 논문의 설득력은 큰 분모보다 비교 조건과 독립 witness가 무엇을 배제하는지에 달려 있습니다.

## 3. 왜 C1 중심으로 정리하는가

연구의 원래 관심은 안전 판단의 신뢰성이었습니다. 실제로 가능한 위험을 놓치는 문제와, 안전 모듈의 내부 처리 때문에 행동 판단이 달라지는 문제를 근거로 설명하고자 했습니다. 이후 RFM fit을 강화하려는 통합·개입 연구도 진행했지만, 현재 그 결과는 diagnosis에 따른 repair 선택의 이득이나 completion 개선을 입증하지 못했습니다.

이는 C1의 인과적 증거를 반박하는 결과가 아닙니다. 질문과 검증 단위가 다르기 때문입니다. C1은 정렬된 입력, 가능한 hidden-object witness, 구체적 실행 순서, 국소 개입, 고정된 checker를 연결합니다. RFM 작업은 adapter 정합성, 실제 intervention 적용, episode 단위 outcome, 평가 비용의 완전성 등 추가 조건을 필요로 했습니다. 이 조건들이 충족되지 않거나 선택 이득이 확인되지 않은 상황에서 두 연구를 하나의 성공 주장으로 묶을 수는 없습니다.

따라서 현 시점의 선택은 다음과 같습니다.

- 주된 증거 사슬은 C1의 uncertainty representation 보존과 permission 변화에 둡니다.
- 이번 추가 실험은 기존 수정의 충분성, 비용, reduction 단계별 경계를 설명하는 데 사용합니다.
- RFM 통합·recovery 및 SafeVLA terminal audit는 각각의 별도 질문으로 보존합니다. 특히 이전 집계가 후속 audit에서 수정된 RFM 숫자를 이 문서에서 다시 가져와 확정 결과로 쓰지 않습니다.
- 새로운 방법을 넣는 것보다, 알려진 원칙이 실제 안전 구현에서 어떻게 위반되고 평가에 어떤 차이를 만드는지 명확히 설명하는 것을 우선합니다.

이 정리는 연구를 성공 사례만 남기는 방향으로 축소하려는 것이 아닙니다. 서로 다른 질문의 결과를 혼합하지 않고, 현재 가장 강하게 뒷받침되는 contribution을 중심에 두려는 선택입니다.

## 4. 해석에 필요한 개념과 증거 수준

### 4.1 보존하려는 것은 데이터 구조 자체가 아니라 가능한 상태입니다

관측 이력을 h, 시점을 t, 그 관측·동역학 조건과 양립하는 상태 집합을 S_h(t), 구현이 반환한 전체 표현을 R_t, 표현의 의미를 Γ_t(R_t)라고 두면 원하는 조건은 다음과 같습니다.

S_h(t) ⊆ Γ_t(R_t)

표현의 노드 수, graph 형태, candidate 순서가 달라져도 필요한 상태가 보존되면 이 조건과 양립할 수 있습니다. 따라서 Original과 수정 방법의 출력이 다르다는 사실만으로 버그라고 판정할 수 없습니다.

반대로 observation·dynamics와 양립하는 witness 하나가 전체 출력의 의미에서 빠졌다면, 그 witness가 속한 모델·시점·입력 범위에서는 보존 조건에 대한 반례가 됩니다. 한 개의 유효한 반례와 여러 개의 통과 사례는 논리적 역할이 비대칭입니다.

### 4.2 현재 자료에서 구분하는 증거

| 증거 | 말할 수 있는 내용 | 넘어서면 안 되는 해석 |
|---|---|---|
| Continuous stationary witness | 지정한 모델에서 연속적으로 가능한 hidden object가 출력에서 소실됨 | 실제 센서 장면에서의 발생이나 충돌 |
| Finite reference 검사 | 검사한 유한 상태들에 대한 누락 유무 | 전체 continuous state space의 soundness |
| Position presence | 검사한 위치가 출력에서 표현됨 | 속도·history까지 모두 올바르게 보존됨 |
| Whole-forest absence | 검사한 witness를 어느 최종 출력도 보존하지 않음 | primitive와 모델의 모든 가정이 현실적으로 완전함 |
| Reduction OFF 비교 | 해당 optimization을 제거했을 때 결과가 어떻게 달라짐 | OFF 출력을 무조건 완전한 물리 oracle로 취급 |
| Same-checker permission 비교 | 같은 후보와 checker에서 표현 차이가 판단에 미치는 영향 | 실제 실행, collision, task completion의 변화 |
| Completed | 정해진 실행 범위에서 함수가 반환됨 | 모든 입력에서 termination, real-time deadline 만족 |
| Unresolved | 현재 evaluator로 해당 의미를 판정하지 못함 | omission 0, unsafe, method 미완료 중 어느 하나 |

### 4.3 ‘입력이 가능하다’는 말도 두 수준으로 나눠야 합니다

첫째, 구성한 uncertainty forest 안의 hidden-object witness가 지정한 관측·동역학과 양립하는가를 묻습니다. D1은 이 수준의 독립 stationary witness를 갖습니다.

둘째, 실제 시스템의 허용된 초기화와 센서·update 경로가 그 uncertainty forest 자체를 생성할 수 있는가를 묻습니다. 현재 D1에서는 이 수준이 미검증입니다. 첫째를 충족했다고 둘째가 자동으로 충족되는 것은 아닙니다. 이 구분이 다음 실용성 검증의 핵심입니다.

## 5. 기존 C1의 인과관계: 무엇이 실제로 연결돼 있는가

### 5.1 관측 동등성이 필요한 이유

C1에서는 t=2.5의 길이 0.5 m hidden component를 제거하는 관측 변환을 비교합니다. 지정된 관측 모델에서 hidden object는 길이 3 m의 연결된 footprint를 갖습니다. 이 작은 component에는 그 footprint가 들어갈 수 없다는 분석을 통해 두 관측 조건의 feasible trajectory set이 같다는 근거를 제공합니다.

이 조건이 중요한 이유는 출력 차이를 ‘더 많은 정보를 얻었기 때문’이라는 설명과 구분하기 위해서입니다. 실제 가능한 hidden trajectories가 같다면, permission 증가를 곧바로 정보 획득이나 더 정확한 위험 배제로 설명할 수 없습니다. 단, 이 동등성은 지정한 footprint·관측 연산자·geometry에 한정되며 임의의 sensor visibility 변환에 적용되는 명제는 아닙니다.

### 5.2 실행 사건의 순서

검사한 C1의 직접 원인은 한 update 호출 안에서 다음 순서로 나타납니다.

1. 짧은 작업(short job, 구간 [2, 2.5])이 먼저 처리됩니다.
2. Backward processing key (1, 2)가 등록됩니다.
3. Native primitive가 해당 작업에서 최종적으로 남길 표현을 만들지 못해 mature=None을 반환합니다.
4. 그런데 앞서 등록한 key는 그대로 남습니다.
5. 더 긴 구간 [2, 15]을 처리해야 하는 후속 long re-entry가 같은 key를 만납니다.
6. Admission reduction이 이를 이미 처리한 것으로 취급해 진입을 거절합니다.
7. 필요한 coverage를 대신하는 다른 최종 출력도 없습니다.
8. 계속 가능한 stationary hidden-object witness가 전체 출력에서 소실됩니다.

여기서 ‘stale record’는 다음 epoch까지 영구 cache가 남았다는 뜻이 아닙니다. Native searched/visited 자료구조는 update 호출마다 초기화됩니다. 확인한 문제는 같은 update 안에서 처리 흔적의 존속과 살아 있는 coverage가 분리된 것입니다.

초기 독립 리뷰에는 key 등록 순서에 관한 이견이 있었으나, backward branch 원문을 다시 확인한 뒤 철회됐습니다. Forward branch와 혼동했던 것이며, 최종 보고서의 ‘key 등록 → primitive → mature=None’ 순서가 코드와 맞습니다.

### 5.3 왜 국소 개입이 원인 근거인가

해당 admission을 허용하거나 admission 기준을 바꾸면 long job이 실제로 처리되고 목표 누락이 회복됩니다. 기존 C1에서 visited-only나 mature-only 변경은 핵심 admission rule을 유지하므로 회복하지 못했습니다.

이 비교는 어떤 stage의 개입이 검사한 누락을 바꾸는지 분리합니다. 다만 admission 변경이 모든 planner failure의 유일한 원인이라는 뜻은 아닙니다. 이후 action selection과 execution에는 추가 요인이 있고, 다른 reduction 단계에도 별도 문제가 있을 수 있습니다.

### 5.4 표현 누락이 판단으로 이어지는 근거

같은 18개 candidate action과 같은 native checker를 사용할 때 Original은 18개를 허용했고, reference 및 해당 국소 개입은 4개를 허용했습니다. 허용 ID는 [1, 6, 7, 12]로 일치했습니다.

이 결과는 representation의 누락이 실제 안전 판단 입력으로 사용되며, 허용 집합을 바꿀 수 있음을 보여 줍니다. 특정 구현에서 더 많은 행동을 허용한 이유를 평가하려면 그 근거가 되는 hazard hypotheses가 제대로 유지됐는지를 함께 봐야 한다는 application 의미가 생깁니다.

Far control에서는 내부 omission 차이가 남아도 모든 방법이 18개를 허용했습니다. 따라서 내부 누락은 해당 checker query에 항상 영향을 주는 것은 아닙니다. 위험 표현과 action의 geometry 관계가 있어야 판단 영향으로 이어질 수 있습니다. 이 control은 omission과 permission effect를 동일한 개념으로 취급하는 것을 막습니다.

### 5.5 기존 control이 좁혀 준 설명

| 대조 조건 | 관찰 | 인과적 의미 |
|---|---|---|
| Queue 순서 변경 | Original의 목표 누락이 사라지는 조건이 있음 | 지정 순서가 C1 trigger의 일부임 |
| Lane re-entry/successor 조건 제거 | 목표 누락이 사라지는 조건이 있음 | 후속 작업이 같은 key를 다시 만나는 경로가 중요함 |
| Redundant equal copy | 기존 C1 누락이 유지됨 | 단순 중복 추가가 언제나 누락을 막지는 않음 |
| Contained cover와 순서 반전 | 검사한 목표 누락 없음 | 대체 coverage와 입력 관계를 별도로 봐야 함 |
| Visibility island 없는 normal duplicate | 검사한 목표 누락 없음 | Duplicate 존재 자체가 충분한 원인은 아님 |
| Far action placement | 내부 omission 차이에도 permission 동일 | Downstream 영향에는 추가 geometry 조건이 필요함 |

이 조건들은 independent natural-scene 성공률로 집계하지 않습니다. 서로 다른 control을 모두 ‘duplicate는 정상’ 같은 한 행으로 합치면 원인 해석이 흐려집니다.

## 6. 기존 수정의 충분성과 비용: 새 실험이 답한 것

### 6.1 비교 방법과 실행 단위

기존 7개 조건과 1/4/16/64-copy stress를 합쳐 11개 조건을 구성하고, 각 조건에 5개 방법을 적용했습니다. 조합마다 timing 11회, queue/work instrumentation 1회, memory 측정 1회를 분리했습니다. 총 715개 기록은 모두 completed이며 invalid와 timeout은 0입니다. 별도 warmup 5개 기록도 있습니다.

55개 조합에서 timing/instrumentation/memory 실행의 output parity가 확인됐습니다. Original·structural key·현재 guard의 기존 21개 조건–방법 결과는 저장된 9-epoch snapshot과도 일치했습니다. 반복 순서의 shuffle seed는 시간 측정 순서를 위한 것이며 물리적 episode의 독립성을 의미하지 않습니다.

### 6.2 방법 이름보다 실제 변경 지점이 중요합니다

| 이름 | 개입 범위의 해석 |
|---|---|
| Original | 검사한 native reduction을 그대로 사용 |
| Structural key | 해당 admission의 identity 기준을 구조적으로 구분 |
| Admission OFF | 해당 backward admission 생략을 해제하되 다른 단계는 유지 |
| Current mature guard | 여러 backward 제거 지점을 보수적으로 다루는 현재 구성; mature-only 변경과 다름 |
| All backward reductions OFF | Backward admission·visited·mature reduction을 해제; 전체 planner의 모든 optimization을 끈 것은 아님 |
| Mature-only OFF | D1 원인 분리를 위한 별도 단일 predicate 개입; 5개 비용 비교 방법과 구분 |

‘Guard가 성공했다’만 쓰면 어느 stage의 수정이 결과를 만들었는지 알 수 없습니다. 여러 지점을 바꾼 configuration의 전체 성능과 단일 지점 개입의 인과적 증거를 나누어 제시해야 합니다.

### 6.3 원 C1의 결과

| 방법 | t=4 위치 / 위치·속도 누락 | 9회 update 합 중앙값 [최소, 관측 최대], ms | Worklist pop / peak | 추가 Python peak, B |
|---|---:|---:|---:|---:|
| Original | 293 / 293 | 1.373 [1.349, 1.624] | 19 / 2 | 4,380 |
| Structural key | 0 / 0 | 2.779 [2.738, 3.363] | 24 / 3 | 8,968 |
| Current mature guard | 0 / 0 | 1.819 [1.785, 2.169] | 24 / 3 | 4,436 |
| Admission OFF | 0 / 0 | 1.813 [1.759, 2.163] | 24 / 3 | 4,380 |
| All backward OFF | 0 / 0 | 1.843 [1.766, 2.109] | 24 / 3 | 4,380 |

네 수정 모두 기존 7개 조건의 t=4 finite position 및 position–speed 목표 누락을 제거했습니다. 원 C1의 Original은 t=3, 3.5, 4에서 각각 371, 329, 293개 finite 항목을 누락했고, 검사한 수정들은 이 후반부 목표 누락을 제거했습니다. 따라서 t=4 한 장면만 복구됐다기보다 지정된 후반 epoch들에서 목표 문제가 사라졌다는 범위까지 자료가 있습니다.

그러나 t=1에서는 모든 방법에 별도 native velocity-envelope discrepancy 1개가 남았습니다. 이는 해당 reduction 문제를 고쳐도 primitive 전체의 보존이 입증되지는 않는다는 근거입니다. ‘C1 목표 누락 회복’과 ‘planner 전체 soundness 확보’를 분리해야 합니다.

### 6.4 시간과 메모리의 측정 범위

시간은 update 함수 전체를 측정하며 방법의 lookup과 native primitive 처리를 포함합니다. Prediction, 입력 구성, 초기 queue 구성, offline reference/coverage 검사는 timer 밖입니다. Queue 계측과 Python memory 측정은 시간 측정과 별도 실행으로 분리했습니다.

추가 Python peak는 tracemalloc이 관측하는 allocation이며 전체 RSS나 모든 native allocation의 합이 아닙니다. 관측 최대는 11회 측정 중 최대이고 WCET 보장이 아닙니다. 다른 server process가 계속 동작한 상태였으며, 30초 cap은 행정적 상한이지 실제 deployment deadline이 아닙니다.

따라서 ‘이 작은 fixture에서 기존 수정의 추가 update 비용은 작았다’는 결론은 타당합니다. ‘실제 시스템이 real-time 조건을 만족한다’ 또는 ‘비용 문제는 전혀 없다’는 결론은 아직 타당하지 않습니다.

### 6.5 왜 이 결과를 긍정적으로 받아들여야 하는가

간단한 수정이 충분하다는 결과는 새로운 algorithm의 필요성을 약화하지만, implementation audit의 실용성은 보강합니다. 독자는 문제를 재현하고, 목표 누락을 없애는 변경과 측정된 비용을 확인할 수 있습니다. 연구의 가치는 어려운 해법을 새로 만드는 데만 있지 않으며, 어떤 평가가 결함을 놓치고 어떤 수정이 충분한지를 근거로 보여 주는 데도 있습니다.

다만 이것만으로 논문의 중요성이 자동으로 입증되는 것은 아닙니다. 실제 input 생성 가능성과 safety decision에 미치는 구체적 영향이 함께 설명돼야 합니다. 그래서 C1의 same-checker 실험을 중심에 유지하고, 다음 우선순위를 실제 생성 경로에 둡니다.

## 7. 중복 입력 stress: 관찰된 비용 차이와 아직 모르는 것

### 7.1 실험이 바꾼 것

Input union, history, epoch, visibility를 유지하면서 동일 worklist를 1/4/16/64번 복제했습니다. 이는 표현상 중복 증가의 비용을 보기 위한 stress입니다. 새로운 geometry, 독립 scene, 장기간의 closed-loop history 분포를 생성한 실험은 아닙니다.

64-copy, t=3 조건에서의 결과는 다음과 같습니다.

| 방법 | Update 중앙값 / 관측 최대, ms | 위치 / 위치·속도 누락 | 최종 출력 수 |
|---|---:|---:|---:|
| Original | 13.409 / 18.843 | 371 / 371 | 2 |
| Structural key | 40.321 / 44.210 | 0 / 0 | 3 |
| Current mature guard | 39.065 / 127.029 | 0 / 0 | 129 |
| Admission OFF | 20.185 / 23.752 | 0 / 0 | 3 |
| All backward OFF | 19.956 / 37.670 | 0 / 0 | 192 |

현재 guard는 26,719회의 pair check를 수행했습니다. 지원하지 않는 history/구조에 대해 제거를 정당화하지 못하면 그대로 처리하므로 비교 비용과 출력 수가 증가할 수 있습니다. 이는 conservative fallback이 실제로 적용된 비용이며, 그 자체를 safety failure로 분류해서는 안 됩니다.

### 7.2 가능한 해석

첫째, 더 정교한 비교를 수행하는 guard가 단순히 더 처리하는 OFF보다 항상 빠르지는 않았습니다. ‘Pruning을 추가했으니 효율이 좋아질 것’이라는 가정 대신, 비교 자체의 비용을 측정해야 합니다.

둘째, Original의 짧은 시간은 필요한 작업까지 누락한 결과를 포함합니다. Coverage를 보존한 방법과 안전 의미를 맞추지 않은 채 속도만으로 우열을 매기면 안 됩니다.

셋째, 빠른 admission OFF도 D1은 해결하지 못합니다. 한 workload에서 비용과 coverage가 좋았다는 사실이 다른 reduction 단계의 정당성까지 보증하지 않습니다.

넷째, all-backward OFF는 이 update에서는 guard보다 빠르지만 출력 192개를 남겼습니다. 다음 prediction과 이후 epoch에 들어갈 비용은 이번 timer에 포함되지 않습니다. 따라서 all-backward OFF를 전체 pipeline의 최적 방법으로 선정할 근거도 아직 없습니다.

### 7.3 현재 하지 않는 결론

- 실제 deadline을 넘었다는 결론은 없습니다.
- Guard가 복잡한 history를 처리하지 못한다는 결론은 없습니다. 비교가 unsupported이면 생략하지 않고 처리했습니다.
- 중복 규모가 실제 센서 workload에서 얼마나 자주 나타나는지는 모릅니다.
- 관측한 scaling만으로 일반적 시간복잡도 theorem이나 필연적 exponential blow-up을 주장하지 않습니다.
- 이 결과만으로 새 pending-aware algorithm 또는 online certificate checker가 필수라고 결론 내리지 않습니다.

## 8. 새 D1: admission을 고쳐도 남는 별도 mature-output 누락

### 8.1 입력과 witness

D1은 native update와 visibility traversal을 사용하지만 initial uncertainty forest는 수작업으로 구성했습니다. 먼저 처리되는 표현은 branch {2}를 포함하고, 뒤의 candidate는 {2,3}을 포함합니다. 각 branch에는 front ds=8, footprint [8,11], v=a=0인 stationary witness가 있습니다. 지정된 관측 모델에서 footprint는 visible boundary 14.75보다 3.75 m 떨어져 있고 [0,1] 동안 hidden입니다. 실제 update 판정은 t=0에서 수행했습니다.

위 설정은 독립적으로 가능한 witness가 있다는 근거를 제공합니다. 실제 sensor history가 이 forest를 만들어 냈다는 증거는 아직 아닙니다.

### 8.2 누락이 생기는 실행 원인

Native mature predicate는 이미 retained된 표현의 leaf signatures가 candidate의 leaf signatures에 모두 포함되면 candidate를 중복으로 판단할 수 있습니다. 이 조건은 retained가 candidate보다 좁은 경우에도 참이 될 수 있습니다.

D1에서는 retained가 {2}, candidate가 {2,3}이므로 predicate가 참이 되어 더 넓은 candidate를 버립니다. 다른 출력이 branch 3을 보존하지 않으므로 해당 stationary witness가 전체 명시적 forest에서 빠집니다.

따라서 문제는 단순한 output digest 차이가 아닙니다. Candidate가 담당하던 필요한 상태를 retained union이 대신하는지 확인해야 하는데, 실제 predicate는 검사한 입력에서 반대 방향의 부분집합 관계로 생략을 허용합니다. 다만 leaf signature의 단순 포함 관계를 뒤집는 것만으로 모든 history·graph의 semantic subsumption이 해결된다고 주장하지 않습니다.

### 8.3 방법별 결과와 단일 원인 개입

| 조건 | Original | Structural key | Admission OFF | Current guard | All backward OFF |
|---|---|---|---|---|---|
| D1 subset-fork | Witness 1/2 누락 | 1/2 누락 | 1/2 누락 | 2개 유지 | 2개 유지 |
| V1 shared-trunk fork | 1/2 누락 | 1/2 누락 | 1/2 누락 | 2개 유지 | 2개 유지 |
| V2 nonnested overlap | 3개 유지 | 3개 유지 | 3개 유지 | 3개 유지 | 3개 유지 |
| V3 alternate owner | 2개 유지, rejection 1 | 동일 | 동일 | 2개 유지 | 2개 유지 |
| V4 superset-first | 2개 유지 | 2개 유지 | 2개 유지 | 2개 유지 | 2개 유지 |
| V5 implicit truncation | Unresolved | Unresolved | Unresolved | Unresolved | Unresolved |

별도 D1 개입에서는 mature-output predicate 하나만 OFF로 하고 admission과 visited는 native 상태로 유지했습니다. 이 변경으로 witness가 회복됐습니다. 따라서 여러 지점을 바꾼 guard의 성공만으로 원인을 추정한 것이 아니라, 해당 mature predicate를 겨냥한 국소 증거도 있습니다.

C1에서는 mature-only 개입이 회복시키지 못했고 D1에서는 회복시켰습니다. Admission OFF는 C1을 회복시키지만 D1을 회복시키지 못합니다. 이 차이는 ‘어느 단계의 생략인가’에 따라 수정의 충분성이 달라짐을 보여 줍니다. 이를 실제 RFM task repair selector의 유용성이나 prospective learned diagnosis 성능으로 바꾸어 쓰지는 않습니다.

### 8.4 비발생 조건이 논문에 기여하는 이유

V3에서는 {2,3} candidate가 제거되더라도 다른 retained output이 branch 3을 이미 보존합니다. 따라서 candidate rejection은 있지만 전체 output의 witness 누락은 없습니다.

이 결과는 원인 분석의 단위를 명확히 해 줍니다. 개별 representative의 소멸이나 candidate rejection만을 경보 기준으로 사용하면 필요한 상태가 이미 다른 곳에 보존되는 경우까지 실패로 분류할 수 있습니다. Whole retained union을 확인해야 harmful omission과 harmless representation change를 구분할 수 있습니다.

V2는 단순 branch overlap이 항상 실패를 만들지는 않음을, V4는 동일 구조에서도 처리 순서가 결과에 중요함을 보여 줍니다. V4는 새 topology 일반화가 아니라 order control입니다. V5는 성공·실패 control이라기보다 의미 판정 범위의 경계입니다.

### 8.5 새 결과를 논문의 어디에 두는가

C1의 관측 동등성, 인과적 실행 사슬, action permission 효과를 main evidence로 유지합니다. D1과 V3는 ‘기존 수정의 적용 범위’와 ‘누락 판정의 기준’을 설명하는 결과로 배치하는 것이 적절합니다.

D1을 C1과 같은 stale-key 현상이 다른 자연 환경에서도 반복된 증거로 쓰면 원인을 혼합하게 됩니다. 반대로 별개의 버그 목록으로만 나열하면 공동의 메시지가 약해집니다. 공동의 메시지는 ‘각 생략 단계가 필요한 의미를 어떤 살아 있는 표현에 맡기는지 확인해야 한다’는 평가 의무이고, 구체적인 결함 원인은 별도로 설명해야 합니다.

## 9. Decoder 보완과 사전 예측: 결과를 바꾼 것과 판정을 보완한 것

### 9.1 처음 unresolved였던 이유

기존 generic decoder는 한쪽 경계만 있는 terminal InBound를 implicit tail로 분류했습니다. 그러나 native 코드에서는 finite leaf_depth를 가진 명시적인 bounded InBound와, stop-length truncation 때문에 leaf_depth=None이 된 tail이 구분됩니다.

첫 D1 다섯 실행은 이 decoder 제한으로 모두 unresolved였습니다. 이후 명시적 tree와 finite leaf에 한정해 판정할 수 있도록 decoder를 보완했습니다. 동일한 입력과 방법으로 다시 확인했으며, 이전·이후의 initial forest, final forest, 실행 사건은 동일했습니다. 바뀐 것은 native 결과가 아니라 그 결과에 대한 semantic 판정 가능 범위입니다.

이런 계측 보완 자체가 부적절한 것은 아닙니다. 다만 원 결과를 없애고 처음부터 확정 판정이 있었던 것처럼 기록하면 안 됩니다. 이번 자료에는 구 harness, 구 raw 결과, 변경 이유, 새 harness와 실행 기록이 보존돼 있습니다.

### 9.2 보완 후에도 남긴 경계

실제 truncation이 있는 V5는 다섯 방법 모두 completed였지만 unresolved였습니다. 반환된 출력 수가 Original 1개, guard 2개로 달라도 그 차이만으로 witness 누락을 판정하지 않았습니다.

이 때문에 D1의 position-absence 반례와 V5의 미판정은 다르게 해석해야 합니다. Explicit forest 전체에서 해당 branch가 없다는 것은 구성한 stationary witness의 누락 근거가 됩니다. 반면 implicit tail의 의미를 decoder가 판정하지 못하면 branch가 명시적으로 보이지 않는다는 사실만으로 absence를 결론 내릴 수 없습니다.

### 9.3 사전 예측의 강도와 한계

V1–V5의 예측은 첫 D1 실행 전 기록됐습니다. D1 이후에는 measurement decoder만 보완했고, 정해진 예측·방법·입력은 바꾸지 않았습니다. Validation의 resolved 20개 방법–조건 조합이 예측과 일치했고, V5 다섯 조합도 예상대로 unresolved였습니다.

이 결과는 code-informed mechanism에 기반한 사전 예측이 설계한 구조에서 확인됐다는 근거입니다. 소스 분석으로 만든 소수의 deterministic 조건이므로 독립 자연 장면에 대한 예측 정확도, learned selector의 성능, 통계적 일반화로 보고하지 않습니다. 특히 unresolved 예측 일치를 unsafe/safe 분류의 정답으로 합산하면 안 됩니다.

Mature-only OFF는 D1 원인을 더 좁히기 위한 후속 development 개입입니다. 이미 고정한 validation에 독립 held-out 사례 하나를 추가한 것으로 계산하지 않습니다.

### 9.4 기록 정합성과 과학적 유효성은 별도입니다

Output parity, hash, pre/post 계측 정합성은 실험이 의도한 코드와 비교 조건을 지켰는지 확인합니다. 이러한 검사가 통과해도 witness 모델의 현실성, 전체 semantic completeness, deployment relevance까지 자동으로 검증되지는 않습니다. 논문에서는 정합성 검사를 신뢰할 수 있는 실행의 근거로 두고, 실제 claim은 별도의 witness·개입·control에 연결해야 합니다.

## 10. 과거 실패와 null result에서 얻은 지식

### 10.1 실패한 processed-input guard의 의미

과거 guard는 처리한 입력의 containment를 저장하고 이를 후속 admission 판단에 사용했습니다. 이 버전은 C1을 해결하지 못했을 뿐 아니라, Original이 t=4에서 누락하지 않았던 reversed-queue와 no-successor 조건에서도 293개 누락을 만들었습니다.

과거 input이 다른 input을 포함한다는 사실이 후속 processing을 거친 살아 있는 output의 coverage까지 보증하지는 않습니다. 입력이 filtering·split·소멸을 거칠 수 있고, 아직 처리하지 않은 child의 책임도 남을 수 있기 때문입니다. 이 실패는 현재 mature guard와 혼동하지 말아야 하며, 현재 방법을 단순한 ‘guard v2가 더 좋음’으로 설명하는 것보다 어떤 증거를 생략 근거로 사용할 수 있는지 보여 주는 자료로 활용하는 편이 낫습니다.

모든 processed-input 기반 알고리즘이 불가능하다는 결론은 아닙니다. 적절한 invariant와 pending work의 이행 보장이 있다면 processed 또는 pending 표현을 안전하게 활용할 수 있습니다. 현재 반례는 그런 보장 없이 과거 containment를 사용한 구체적 구현을 대상으로 합니다.

### 10.2 기존 null의 종류를 구별해야 하는 이유

| 기존 관찰 | 실제로 답한 질문 | 답하지 않은 질문 |
|---|---|---|
| C1 visited-only/mature-only 무효 | 해당 단일 변경은 C1의 admission 누락을 회복하지 못함 | 다른 구조에서 그 단계가 무해한가 |
| Far control의 동일 permission | 내부 차이가 해당 후보 geometry에서는 판단을 바꾸지 않음 | 내부 coverage가 보존됐는가 |
| E0의 내부 변화·동일 verdict/path | 검사한 조건과 horizon에서 downstream 차이가 없음 | 모든 조건의 semantic equivalence |
| D05의 execution 변화·양쪽 timeout | 적용한 수정만으로 해당 task completion은 회복되지 않음 | 해당 결함이 아무 영향이 없는가, completion이 불가능한가 |
| H pilot의 target 미적용 | 의도한 target을 보존하는 개입이 실현되지 않음 | 그 target을 실제로 보존하면 효과가 없는가 |
| RFM repair 선택 이득 미확립 | 현재 자료로 diagnosis의 선택 가치를 주장할 수 없음 | C1의 표현 누락과 permission 효과가 잘못됐는가 |

서로 다른 null을 ‘모든 시도가 실패했다’로 묶으면 원인을 구별하는 정보가 사라집니다. 반대로 null을 해석만으로 새로운 성공 주장으로 바꿔서도 안 됩니다. 현재 자료가 보여 준 stage·target·effect 범위까지 정확히 정리하는 것이 연구의 자산입니다.

## 11. 선행연구와 신규성: 알려진 원칙을 인정한 뒤 남는 기여

문헌 감사는 CAV/TACAS/PLDI/ICRA/RSS의 직접 관련 원문을 중심으로 기존 지식과 우리 증거를 구분했습니다. 이 검토는 모든 선행연구의 부재를 증명하는 systematic review가 아닙니다.

| 선행연구 | 이미 다루는 내용 | 우리 논문에서 남는 구체적 질문 |
|---|---|---|
| CPA, CAV 2007 | Semantic stop, reached/waitlist, representative 변경과 후속 처리 | 관측 갱신 전후의 구체적 의미가 다른데도 processing key가 살아 있는 coverage를 대신하는가 |
| Verified Certification, TACAS 2020 | Initial coverage, successor closure, subsumption, 독립 certificate 검사 | 해당 native 표현·history·primitive의 의미 아래 어떤 witness가 실제로 소실되는가 |
| Alive2, PLDI 2021 | 개별 변환의 의미 검사, bounded validation와 unsupported 범위 | 출력 차이 중 안전 hazard support의 실제 누락을 어떻게 판정하는가 |
| Antichains, CAV 2006 | 목적에 맞는 semantic order를 이용한 reduction | 구현의 포함 방향과 처리 stage가 그 의미를 지키는가 |
| EMI, PLDI 2014 | 의미를 유지하는 변환을 이용한 차이 검사 | 관측 동등성 아래 달라진 출력이 harmless한가, feasible witness를 누락하는가 |
| RRBT, ICRA 2011 | 같은 physical state에서도 path-dependent belief/history가 중요함 | 위치나 key의 동일성이 safety-relevant history 의미를 대신할 수 있는가 |
| Safe POMDP Online Planning via Shielding, ICRA 2024 | Belief support approximation이 unsafe state를 놓칠 수 있는 한계 | Sampling이 아닌 deterministic worklist admission에서 지원 상태가 사라지는 구체적 원인은 무엇인가 |
| Zhang–Fisac, RSS 2021 | Occlusion-aware hidden-state와 안전 판단의 대상 framework | 추상적 guarantee의 전제를 공개 구현의 update가 어떻게 유지하는가 |

CPA는 pending과 processed를 전혀 구별하지 않는 방법이 아닙니다. Reached와 waitlist를 관리하고 대표가 바뀌면 후속 처리를 갱신합니다. 따라서 ‘기존 verification은 pending을 고려하지 않는다’는 서술은 피해야 합니다. 또한 mature output만이 유효한 대체 표현이라는 필요조건도 주장하지 않습니다. 올바른 pending responsibility와 closure가 있으면 아직 처리하지 않은 표현도 역할을 할 수 있습니다.

TACAS 2020의 abstract correctness theorem은 §2.1이고 checker는 §2.2입니다. 앞선 제안 문서의 §3 안내는 위치가 잘못돼 수정됐습니다. 이 수정은 기존 연구의 내용을 바꾸는 것이 아니라 정확한 인용 위치를 바로잡는 것입니다.

신규성의 중심은 다음의 연결된 증거입니다.

1. Feasible trajectories가 같다는 관측 동등성의 분석.
2. Native 실행에서 필요한 작업이 사라지는 구체적 순서.
3. 별도의 가능한 hidden-object witness와 전체 출력의 부재.
4. 원인을 겨냥한 국소 개입.
5. 같은 candidate·checker에서의 permission 차이와 no-effect control.
6. 기존 수정의 충분성·비용·단계별 적용 경계.

이 각각의 일반 원리가 처음이라는 주장은 필요하지 않습니다. 다만 한 구현에서 이 증거들을 연결한 것이 독자에게 어떤 판단 오류를 막아 주는지 본문에서 분명히 보여 줘야 합니다. 공개 구현의 결함으로 원 논문의 추상적 safety theorem 전체를 반박했다고 표현해서도 안 됩니다.

## 12. 논문의 중심 주장과 바뀌어야 할 부분

### 12.1 권장 중심 문장

공개 occlusion-aware 안전 구현에서, feasible trajectory set을 바꾸지 않는 관측 표현의 차이가 작업 생략을 바꾸어 가능한 hidden-object witness와 동일 checker의 행동 허용 집합을 달리할 수 있음을 보입니다. 실행 trace와 국소 개입으로 원인을 분리하고, 기존 보수적 수정의 효과·비용·적용 경계 및 실제 누락이 발생하지 않는 조건을 평가합니다.

### 12.2 기여를 세 부분으로 정리하는 이유

첫째, C1의 구체적인 원인과 safety decision 효과를 설명합니다. 관측 동등성과 feasible witness가 없으면 단순 implementation 차이로 읽힐 수 있고, checker 결과가 없으면 safety 판단과의 연결이 약해집니다. 이 두 연결을 함께 유지합니다.

둘째, 간단한 수정이 검사한 C1에 충분함을 비용과 함께 보고합니다. 이는 공학적으로 적용 가능한 결과이며, 새로운 알고리즘의 필요성을 과장하지 않도록 합니다.

셋째, D1과 alternate-owner control로 수정과 진단의 적용 경계를 설명합니다. Stage가 다르면 필요한 수정이 달라질 수 있고, candidate rejection 자체로는 harmful omission을 판정할 수 없음을 보여 줍니다.

### 12.3 주장별 채택 여부

| 주장 후보 | 현재 판단 | 이유 |
|---|---|---|
| C1에서 계속 가능한 hidden object가 내부 생략 때문에 누락된다 | 채택 | 독립 witness, whole-forest absence, trace, 국소 개입 연결 |
| 추가 정보 없이 action permission이 달라질 수 있다 | 지정 모델·후보 범위에서 채택 | 관측 동등성 및 동일 checker 비교 |
| Structural key 또는 admission 수정으로 전체 안전 모듈이 고쳐졌다 | 채택하지 않음 | D1의 별도 mature 누락, t=1 primitive discrepancy |
| 간단한 보수적 수정이 검사한 C1에 충분하다 | 채택 | 기존 7개 조건 목표 누락 제거와 bounded 완료 |
| 간단한 수정은 실용적으로 너무 비싸다 | 채택하지 않음 | 실제 deadline/전체 workload 근거 없음 |
| 새 알고리즘이 반드시 필요하다 | 채택하지 않음 | 기존 guard/OFF의 검사 범위 충분성 |
| Candidate 제거는 곧 unsafe omission이다 | 채택하지 않음 | V3 alternate owner |
| 각 제거 단계와 retained union을 구분해 검증해야 한다 | 기존 원리에 대한 구체적 평가 교훈으로 채택 | C1·D1·V3의 서로 다른 결과 |
| 모든 continuous state·history·graph를 보존한다 | 채택하지 않음 | Finite 검사와 제한된 decoder 범위 |
| RFM diagnosis가 repair 선택 또는 completion을 개선한다 | 채택하지 않음 | 해당 선택 이득 미확립 |
| 이 결함이 실제 환경에 널리 발생한다 | 채택하지 않음 | Sensor/native 생성 경로 및 빈도 미검증 |

### 12.4 기존 문서들 사이의 시점을 맞춰야 합니다

문헌 감사 문서의 일부 표는 추가 실행 전의 evidence 상태를 기록합니다. 예를 들어 structural key의 position–speed 항목은 이전 자료에서는 미측정이었지만 이번 sufficiency 실행에서 target 시점에 측정됐습니다. 이전 표를 그대로 본문에 복사하면 최종 결과와 모순처럼 보일 수 있습니다.

기존 파일을 지워 과거 기록을 없애기보다, 최종 manuscript의 표에서 ‘이전 분석’, ‘이번 추가 측정’, ‘여전히 미판정’을 구분해야 합니다. 이 종합 문서는 최종 보고서와 새 측정을 기준으로 합니다.

## 13. 실용적 교훈: 다음 안전 모듈에서 무엇을 확인해야 하는가

이 요구사항은 uncertainty set, belief support, reachable tube 등 가능한 상태의 표현을 안전 판단의 근거로 사용하는 모듈을 대상으로 합니다. 모든 neural classifier나 RFM 내부에 같은 자료구조·결함이 있다는 주장은 아닙니다.

### 13.1 제거를 정당화하는 근거

작업을 생략하려면 해당 작업이 담당하는 필요한 상태가 같은 의미 기준에서 유지된다는 근거가 있어야 합니다. 가능한 형태는 다음과 같습니다.

- 이미 반환 가능한 output의 합집합이 보존합니다.
- Pending work가 책임을 이어받고, 이후 transfer/filter/split과 종료까지 그 책임이 이행됨을 정당화할 수 있습니다.
- 실제 관측·동역학상 해당 feasible 집합이 empty라는 근거가 있습니다.

Processing key가 있었다는 사실만으로는 이 중 어느 것도 자동으로 충족되지 않습니다. 과거 input의 containment도 마찬가지입니다. 반대로 representative 하나가 사라졌다는 사실만으로 위 근거가 모두 사라졌다고 결론 내려서는 안 됩니다.

### 13.2 실제 평가 항목

| 확인 항목 | 필요한 기록 또는 비교 | 필요한 이유 |
|---|---|---|
| 제거 stage | Admission, visited, mature를 구분한 event | 서로 다른 원인과 수정을 혼합하지 않기 위함 |
| 표현 의미 | Epoch, processing stage, history, 모델 가정 | 같은 key/위치가 같은 hazard 의미라는 보장이 없기 때문 |
| 대체 coverage | 전체 retained union, 필요한 pending successor | V3 같은 harmless rejection을 구별하기 위함 |
| 가능한 반례 | Observation·dynamics와 양립하는 독립 witness | 단순 output difference와 실제 누락을 구별하기 위함 |
| Downstream 영향 | 고정 candidate/checker, near/far 조건 | 내부 누락과 판단 변화를 분리하기 위함 |
| 미판정 범위 | Unsupported semantics, 실제 truncation | Unknown을 안전 또는 실패로 오집계하지 않기 위함 |
| 보수적 대안 | Admission OFF, 현재 guard, backward OFF | 새 방법의 필요성과 기존 수정의 충분성을 공정하게 판단하기 위함 |
| 전체 비용 | Update와 prediction·후속 workload를 구분 | Output 증가가 다음 단계에 주는 비용을 놓치지 않기 위함 |

이 표는 새로운 완성된 online checker의 제안이 아닙니다. 현재 원자료에서 정당화되는 설계·평가 의무를 독자가 적용할 수 있게 정리한 것입니다.

## 14. Reviewer 관점의 가치와 남은 공격 지점

### 14.1 이번에 보강된 부분

- 원인 설명에 국소 개입과 비발생 조건이 연결됐습니다.
- ‘그냥 보수적으로 처리하면 되는가?’라는 질문에 효과와 비용으로 답할 수 있습니다.
- 한 수정의 성공을 전체 pipeline의 정당성으로 확대하지 않고 실제 적용 경계를 보여 줍니다.
- 계측의 지원 범위와 method failure를 구분했고, decoder 변경 전 기록도 보존했습니다.
- Novelty를 기존 원리의 재발견으로 주장하지 않고 구체적인 안전 구현의 evidence-linked audit로 설정할 수 있습니다.

### 14.2 여전히 실질적인 공백

| 질문 | 현재 답 | 판단에 미치는 영향 |
|---|---|---|
| 실제 시스템이 D1 입력을 만들 수 있는가? | 미검증 | 구성한 내부 상태에만 해당한다는 비판이 가능 |
| C1 visibility는 실제 sensor geometry로 생성되는가? | 미검증 | Application 현실성과 노출 가능성의 핵심 공백 |
| D1의 누락도 action permission을 바꾸는가? | 미측정 | D1의 downstream 효과를 C1 수치로 대신할 수 없음 |
| 수정된 전체 planner가 sound한가? | 입증하지 않음 | t=1 native bound와 implicit tail 범위를 명시해야 함 |
| 실제 workload에서도 비용이 충분한가? | 미검증 | Update microbenchmark로 deployment claim 불가 |
| RFM 시스템에서 동일 mechanism이 확인됐는가? | 확인되지 않음 | SPAIS fit을 직접 실험으로 해결한 것은 아님 |

이 공백을 모두 해결해야만 어떤 논문도 쓸 수 있다는 뜻은 아닙니다. 다만 어느 공백이 현재 contribution의 중요성을 가장 크게 제한하는지 순위를 매겨야 합니다. 이번에는 새로운 알고리즘의 부재보다 input reachability와 sensor realization이 실용성 주장에 더 직접적입니다.

### 14.3 Acceptance에 대한 판단

현재 자료로 C1 중심의 짧은 implementation audit 원고를 정리하는 것은 타당합니다. 이전보다 원인, 영향, 수정, 경계가 연결돼 있습니다. 그러나 ‘안전하게 accept된다’거나 ‘strong accept 수준’이라고 단정할 근거는 없습니다.

좋은 워크숍 논문으로 평가받으려면 reader가 이 결과 때문에 어떤 평가를 추가하거나 어떤 해석을 바꾸어야 하는지가 선명해야 합니다. 현재 가장 설득력 있는 메시지는 more permission을 성능 향상으로 읽기 전에 feasible hazard hypotheses의 보존을 함께 확인해야 한다는 점입니다. 그 일반 원리는 알려져 있으므로 실제 구현의 반례와 비교 설계가 중요합니다.

## 15. 다음 작업의 우선순위와 판정 기준

아래는 앞으로 수행할 제안입니다. 이번에 완료한 비용 benchmark, 기존 C1 재현, 동일 branch validation을 단순히 반복하라는 제안이 아닙니다. 각 단계는 현재 남은 별도의 질문을 해결하도록 설계했습니다.

### 15.1 우선순위 1: D1의 native 입력 생성 가능성 확인

질문: 공개 구현의 허용된 초기화·분기·predict/update 경로가 D1과 같은 retained/candidate 관계를 만들 수 있는가?

먼저 source 수준에서 root, parent, leaf, history와 forest 중복 관계에 관한 invariant를 확인해야 합니다. Tree 형식이 맞고 함수가 입력을 받았다는 사실과, 정상적인 상위 pipeline에서 도달 가능하다는 사실은 다릅니다.

필요한 확인 자료는 다음과 같습니다.

1. 허용된 초기 상태와 이를 생성하는 코드 경로.
2. 두 shadow가 공존하고 처리 순서가 정해지는 경로.
3. {2}와 {2,3} 관계 또는 동일 누락 원인을 가진 동등 구조의 생성 trace.
4. 해당 경로에서 여전히 가능한 독립 witness.
5. Mature rejection 직전과 최종 output의 snapshot.

Native 생성 경로가 확인되면 ‘수작업 unit input에서만 확인’이라는 범위를 한 단계 넓힐 수 있습니다. 확인에 실패한 경우에는 실패 원인을 나누어야 합니다. 탐색 예산 안에서 찾지 못한 것은 불가능성 증명이 아닙니다. 반면 유지되는 invariant가 입력을 배제한다는 근거를 얻으면 D1을 실제 pipeline vulnerability로 주장하지 않고 제한된 boundary 사례로 남겨야 합니다.

이 작업을 먼저 권하는 이유는 full simulator를 많이 돌리기 전에 가장 직접적인 reviewer 질문을 비교적 작은 분석으로 구별할 수 있기 때문입니다.

### 15.2 우선순위 2: C1의 sensor-generated 재현

질문: 고정된 geometry, occluder, ego motion, sensor model에서 얻은 관측이 기존 C1의 처리 메커니즘과 feasible witness 소실을 함께 만들 수 있는가?

실행 전 고정할 것은 geometry와 footprint, sensor/ray 판정, timestamp와 pose 정합성, 입력 생성 경로, intervention 지점, witness feasibility 기준입니다. 다음 항목을 별도로 기록해야 합니다.

- Sensor가 실제 생성한 visibility와 native 입력.
- Short 처리, key 등록, mature=None, long re-entry rejection의 사건 순서.
- 해당 관측 전체와 양립하는 witness.
- 대체 retained output의 부재.
- 동일 prefix에서의 국소 개입 결과.
- 필요할 경우 고정 checker의 permission 변화.

두 조건을 비교할 때 geometry를 바꿨다면 실제 feasible trajectory set도 바뀔 수 있습니다. 이전의 observation-equivalence 증명을 자동으로 재사용하면 안 됩니다. Sensor-generated 한 조건에서 C1 메커니즘을 재현하는 성과와, 두 물리 관측 조건의 동등성까지 입증하는 성과를 구분해야 합니다.

이 작업의 목표는 처음부터 발생률을 추정하는 것이 아닙니다. 정당한 실제 생성 경로 하나를 확보해 application relevance를 보강하는 것입니다. 확인된 후에만 geometry·관측 조건을 사전 지정해 범위를 넓힐지 판단합니다. 이미 증거가 충분한 기존 동일 fixture 반복을 추가하지 않습니다.

### 15.3 우선순위 3: 필요한 경우 D1의 downstream 연결

D1의 native 생성 가능성이 확인되고 논문에서 D1에도 safety-decision 효과를 주장하려는 경우에만 진행합니다. 같은 prefix, 같은 candidate, 같은 checker를 유지하고 mature-only 개입 전후를 비교합니다. 누락 branch가 danger zone과 관련된 조건과 관련 없는 조건을 미리 분리하면 representation loss와 permission effect를 구별할 수 있습니다.

Permission 변화가 없으면 D1의 누락이 부정되는 것은 아닙니다. 해당 query/horizon에서 downstream 효과가 확인되지 않은 것으로 남깁니다. 반대로 permission 변화가 있더라도 실제 collision이나 task completion 개선을 입증한 것으로 바꾸지 않습니다.

현재 C1에 이미 same-checker 증거가 있으므로, 이 단계는 원고의 핵심을 위해 무조건 필요한 추가 실행은 아닙니다. D1에서 주장하려는 범위가 무엇인지에 따라 결정합니다.

### 15.4 조건부 작업: 실제 workload의 전체 비용

실시간 운용 가능성이나 guard의 비용 한계를 주장하려는 경우에만 필요합니다. 먼저 실제 호출 주기, hardware, 입력 크기·history 분포, 동시에 수행되는 planning, prediction과 후속 update의 비용을 고정합니다. 같은 input semantics를 유지하고 기존 guard, admission OFF, backward OFF 등 강한 단순 baseline과 비교합니다.

현재 결과만으로 임의의 deadline을 만들거나 더 큰 adversarial duplicate 수를 계속 늘려 ‘실패’를 만드는 방향은 권하지 않습니다. 실제 요구에서 문제가 나타나야 새 optimization의 필요성을 논의할 수 있습니다.

### 15.5 현 시점에서 우선하지 않을 작업

- 기존 sufficiency 715회와 같은 질문의 반복 실행.
- 동일한 C1 fixture에 seed만 추가해 scene 일반화처럼 보고하는 작업.
- 실제 필요성이 확인되기 전의 새 pending-aware algorithm 또는 generic certificate checker 개발.
- Completion 성공을 찾기 위한 RFM parameter sweep.
- C1을 고쳤다는 이유만으로 별도 native velocity 문제와 모든 implicit-tail 의미를 한 논문에서 전부 해결하려는 확장.

이 보류는 해당 연구가 중요하지 않다는 뜻이 아닙니다. 현재 논문의 남은 주요 질문과 연결되는 정보가 먼저 필요하다는 판단입니다.

### 15.6 중단·축소·강화 기준

| 후속 결과 | 다음 판단 |
|---|---|
| D1이 native 정상 경로에서 생성됨 | 입력 생성 가능성을 새로운 증거로 추가 |
| D1이 유지되는 invariant로 배제됨 | 실운용 vulnerability 범위를 철회·축소하고 unit boundary로 남김 |
| 제한된 탐색에서 D1 생성 경로 미발견 | Unresolved로 보고; 불가능이라고 단정하지 않음 |
| Sensor-generated C1과 feasible witness가 함께 확인됨 | Application relevance를 강화하고 생성 조건을 정확히 보고 |
| Sensor 생성은 되나 이전 관측 동등성은 깨짐 | 메커니즘 재현과 동등성 claim을 분리 |
| Permission 차이는 없지만 witness 누락은 확인됨 | Representation claim 유지, 해당 downstream claim 미채택 |
| 현실적인 workload에서 단순 수정도 충분함 | 단순 해결책을 채택하고 새 algorithm 필요성 주장을 줄임 |
| 전체 workload에서 단순 수정이 실제 요구를 넘음 | 그때 optimization 질문과 강한 baseline을 새로 설계 |
| 현재 witness/모델/decoder 가정에 오류가 발견됨 | 해당 반례 및 연결된 claim을 수정·철회하고 기록 보존 |

## 16. 원고 구성과 SPAIS fit

### 16.1 권장 구성

C1을 main causal case로 두고, 새 cost와 D1/V3를 sufficiency-and-scope 결과로 짧게 연결하는 구성이 적절합니다.

| 부분 | 담을 내용 | 그 순서가 필요한 이유 |
|---|---|---|
| 문제와 관련 연구 | Safety permission 해석, 기존 semantic preservation 원칙 | 일반 원리를 새로 발견했다는 오해를 막고 application 질문 제시 |
| 모델과 판정 근거 | Footprint, observation equivalence, witness, finite/continuous 구분 | 이후 omission 판정의 정당성을 먼저 설명 |
| C1 메커니즘과 판단 영향 | Trace, 국소 개입, 18 대 4, far control | 원인과 safety decision의 연결을 본문 중심에 배치 |
| 수정의 충분성과 범위 | 간단한 비용 표, D1, V3, unresolved tail | 수정은 제시하되 전체 해결로 확대하지 않음 |
| 실용적 요구와 한계 | Stage/history/union, 생성 가능성, primitive/RFM 범위 | 독자가 적용할 교훈과 증거 경계 정리 |

본문은 핵심 사슬과 표에 집중하고, 715개 측정·전체 trace·프로토콜·변경 기록은 artifact 또는 appendix에서 추적 가능하게 연결합니다. 완료된 실험을 모두 본문에 넣는 것이 목적은 아닙니다.

기존 개요의 제목 후보는 “When Processing Records Outlive Hazard Coverage: An Audit of Occlusion-Aware Safety Reasoning”입니다. 이 제목은 C1의 원인을 중심에 둡니다. D1은 다른 원인이므로 제목의 processing-record 결함으로 동일하게 설명하지 말고 적용 경계로 배치해야 합니다. 제목 변경보다 본문의 claim–evidence 정렬이 먼저입니다.

### 16.2 RFM fit에 관한 정확한 판단

2026-09-24 확인한 SPAIS 공식 CFP는 RFM의 interpretability, alignment, control, evaluation을 중심으로 하며 rigorous negative results, replications, open-source tooling도 명시적으로 환영합니다. Control 주제에는 classical reachability/safety filter/constrained-control 보장을 learned policy로 확장하는 문제가 포함됩니다. 본문은 references를 제외한 최대 4쪽이고 non-archival입니다.

따라서 새로운 algorithm이 없다는 사실 자체가 형식상 부적합을 뜻하지는 않습니다. 그러나 C1은 현재 classical safety implementation을 대상으로 한 증거입니다. Learned policy를 보호하는 safety module의 표현 보존 의무라는 연결을 설명할 수 있지만, 실제 RFM에서 동일 결함이나 recovery 효과를 검증한 것으로 쓸 수는 없습니다.

이번 재감사가 강화한 것은 기술적 인과관계, 수정의 실용적 정보, 평가의 경계입니다. 직접적인 RFM empirical fit의 공백은 별도로 남습니다. 일반적인 safety audit로서의 논문 가치와 특정 RFM workshop의 채택 가능성을 같은 판단으로 취급하지 않아야 합니다.

## 17. 후속 구현자에게 전달할 작업 원칙과 산출물

다음 작업의 목적은 새로운 성공률을 만드는 것이 아니라 현재 남은 생성 가능성과 application 의미를 판정하는 것입니다. 이미 완료한 C1/cost/branch 실험은 근거로 재사용하고, 새 질문을 답하는 데 필요한 경우에만 추가 실행합니다.

우선 native 초기화·분기·history 갱신 invariant를 문서화하고 D1 생성 가능성을 확인합니다. 그 뒤 C1 sensor-generated 재현의 입력, witness, intervention, 판정 기준을 실행 전에 기록합니다. 다른 process와 기존 결과를 보존하며, GPU 실행이 필요한 경우 기존에 정한 GPU6 제한을 유지합니다. 이 문서 자체는 실행 또는 프로세스 변경을 수행한 기록이 아닙니다.

필요한 산출물은 다음과 같습니다.

1. Native input validity/reachability 분석: 허용 입력, invariant, 생성 경로 또는 배제 근거.
2. Sensor realization protocol: 고정할 조건, 모델, 동등성 가정, witness 기준, 실행 분모.
3. Event trace와 whole-output snapshot: 각 reduction 단계와 대체 coverage를 연결.
4. Result matrix: completed/invalid/unresolved, witness 보존, permission, 비용을 별도 열로 구분.
5. Claim update: 어떤 새 결과 때문에 어떤 문장을 강화·유지·축소했는지 근거 링크와 함께 기록.
6. 실패·미발견 기록: 탐색 예산, 의도한 target 적용 여부, failure와 판정 불가의 구분.

Source 또는 계측 변경이 필요하면 변경 이유와 실행 전후 output parity를 보존합니다. Native 입력 자체나 sensor 조건이 바뀐 경우에는 단순 계측 보완으로 분류하지 않습니다. 새로운 protocol과 기존 결과의 경계를 명시해야 합니다.

## 18. 출처와 확인 경로

### 18.1 이번 재감사 자료

- [SPAIS_reaudit 폴더](private-drive-link-redacted)
- [최종 C1 strengthening 보고서](private-drive-link-redacted): 종합 결론, 실측 수치, branch 결과, claim 범위.
- [Sufficiency 보고서](private-drive-link-redacted): 방법별 비용과 coverage, 계측 범위.
- [Sufficiency 715개 raw 기록](private-drive-link-redacted): timing/instrumentation/memory 재집계 근거.
- [Boundary matrix](private-drive-link-redacted): 조건별 방법 결과.
- [사전 예측 확인표](private-drive-link-redacted): 예측·관찰·판정 범위.
- [D1 Original 원자료](private-drive-link-redacted)
- [D1 mature-only OFF 원자료](private-drive-link-redacted)
- [Validation 원자료](private-drive-link-redacted)
- [Native shadow_utils.py snapshot](private-drive-link-redacted)
- [실험 방법 감사](private-drive-link-redacted): 과거 null의 구분, counterfactual 범위, 방법 변경의 목적.
- [문헌 감사](private-drive-link-redacted): prior overlap와 정확한 reading location.
- [보존 요구사항](private-drive-link-redacted): stage/history/union/pending 관련 해석.
- [논문 개요와 claim 문안](private-drive-link-redacted)

일부 세부 파일은 위 폴더 내 경로로 확인할 수 있습니다: boundaries/protocol.json, boundaries/freeze_manifest.json, boundaries/measurement_change_v2.json, methods/final_review.json, report/final_verification.json, delivery/verification.json. 원자료 묶음은 이 종합 문서로 대체하지 않습니다.

### 18.2 직접 관련 1차 문헌과 공식 CFP

- [Beyer, Henzinger, Théoduloz. Configurable Software Verification. CAV 2007](https://www.sosy-lab.org/research/pub/2007-CAV.Configurable_Software_Verification.pdf)
- [Wimmer, von Mutius. Verified Certification of Reachability Checking for Timed Automata. TACAS 2020](https://link.springer.com/content/pdf/10.1007/978-3-030-45190-5_24.pdf)
- [Lopes et al. Alive2: Bounded Translation Validation for LLVM. PLDI 2021](https://web.ist.utl.pt/nuno.lopes/pubs/alive2-pldi21.pdf)
- [Antichains: A New Algorithm for Checking Universality of Finite Automata. CAV 2006](https://lsv.ens-paris-saclay.fr/~doyen/papers/antichains-universality-cav06.pdf)
- [Compiler Validation via Equivalence Modulo Inputs. PLDI 2014](https://people.inf.ethz.ch/suz/publications/emi.pdf)
- [Bry and Roy. Rapidly-exploring Random Belief Trees. ICRA 2011](https://groups.csail.mit.edu/rrg/papers/abry_icra11.pdf)
- [Safe POMDP Online Planning via Shielding. ICRA 2024](https://arxiv.org/html/2309.10216v2)
- [Zhang–Fisac. RSS 2021 paper](https://www.roboticsproceedings.org/rss17/p066.pdf)
- [SPAIS 2026 공식 Call for Papers](https://spais-ws.org/cfp)

문헌의 확인 범위와 개별 claim은 재감사 source ledger 및 문헌 감사에 연결돼 있습니다. 이 문서는 추가적인 systematic literature search나 새로운 최초성 판단을 수행한 결과가 아닙니다.
