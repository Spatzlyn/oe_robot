# C1 sensor-generated 검증 결과

고정된 scene에서 생성한 full depth images를 native `DepthVisibility`와 `update_visibility`에 전달했을 때, 계속 관측과 양립하는 hidden-object witness가 worklist admission 때문에 전체 output에서 소실되는 경로를 확인했습니다. Target admission 하나만 허용한 replay에서 같은 시점의 witness position이 회복됐습니다. **CPU synthetic sensor model의 존재 반례**이며 CARLA rollout, 실제 collision, task completion, 자연 발생률의 결과는 아닙니다.

## 1. 생성한 것과 재사용한 것

`protocol_v1.md`를 첫 실행 전에 고정했습니다. Nine development conditions는 camera velocity {0, 0.5, 1} m/s와 panel gap의 세 조합입니다. 결과를 보고 고른 `v0.5_g-0.5`는 mechanism attribution을 위한 development case입니다. Held-out validation이라고 부르지 않습니다.

| 구성 | 실제 실행/가정 |
|---|---|
| Scene | 고정 opaque vertical panels: y=-5, z∈[0,4], x∈[-1,-0.75] 및 [-0.5,5.5] |
| Target road | Lane 1: x=ds, y=0, ds20→0; lane 2: x=ds-10, ds10→0 |
| Ego path | Polyline (-20,-10)→(0,-10)→(0,10); target road의 공통 endpoint에서 교차 |
| 실제 관측기간 camera | x=-4+0.5t, y=-10, z=1.7, t∈[0,4], Δt=0.5 s; camera/occluder 충돌 없음 |
| Sensor | Yaw 0/90/180/270°, pinhole FOV110°, 모든 pixel ray와 panel·ground intersection으로 axial depth 생성 |
| Native 입력 | Float depth arrays 및 camera transforms; waypoint mask를 image에 삽입하지 않음 |
| Native 처리 | Empty shadow list에서 `update_visibility`가 forward `InBound` 생성 → cross work 생성 → native prediction/update |
| Constructed boundary | `Lane`, `Network`, client/map waypoint interface는 synthetic fixture. Native CARLA map loader는 실행하지 않음 |
| Native model | v_max15, acceleration[-8,4], ds0.5, stop_length40, visibility range100; native near5m 가정·cache 유지 |
| Scope 밖 | RGB/BGRA CARLA sensor decoding, object-manager sensor fusion, native map extraction, planner execution |

Cross metadata는 지정 polyline과 target-road endpoint의 실제 교차에 대응합니다. 그러나 CARLA `RoadNetwork`가 이 fixture와 동일한 lane decomposition/metadata를 만든다는 증명은 아닙니다. 실제 ego trajectory는 4 s 동안 panel에서 떨어져 있으며 미래 route의 장애물 통과나 task completion을 요구하거나 검증하지 않았습니다. Lane의 center-point visibility를 사용하는 native 함수 범위만 검사했습니다.

## 2. 독립 witness와 sensor 입력의 양립성

Witness는 lane 1의 front ds=8, footprint [8,11], width1 m, height1.5 m, v=a=0인 stationary body입니다. 초기 native output에는 이 위치가 포함됩니다. Body와 panel은 y 방향으로 분리되어 physical overlap이 없고, ego도 witness와 겹치지 않습니다.

Sensor 위치 (x,-10,1.7)에서 body point (b_x,b_y,b_z)로 향하는 ray가 panel y=-5와 만나는 비율은 `α=5/(10+b_y)`입니다. Intersection x와 z의 extrema를 body의 interval endpoints에서 계산하면 전 관측기간 right panel 내부에 엄격하게 포함됩니다. Linear camera motion 구간에도 이 bound가 유지되며 최소 horizontal margin은 **0.6578947 m**입니다. 이는 native output을 reference로 사용하지 않은 geometry certificate입니다.

별도 slab intersection으로 body AABB를 추가했을 때 저장된 image의 depth가 바뀌는지 전 pixel을 재검산했습니다. 640×360 및 1920×1080 각각 9 frames×4 cameras에서 **변한 pixel 0**입니다. 이는 해당 body가 생성된 sensor observations 전체와 양립한다는 추가 근거입니다. 기존 C1의 서로 다른 두 visibility 조건에 대한 observation-equivalence proof를 재사용한 결과는 아닙니다.

모든 development scene에서 이 body가 4 s 내내 hidden인 것은 아닙니다. Velocity1 조건의 후기에는 certificate가 성립하지 않습니다. `analysis/run_matrix.csv`의 full-horizon feasibility와 `epoch_matrix.csv`의 per-epoch feasibility를 별도로 유지했습니다. 그 이전 prefix에서의 omission과 이후 body visibility를 혼합하지 않습니다.

## 3. 640×360에서 확인한 원인 사슬

선택 case의 `t=2`에서 다음 사건을 확인했습니다.

1. Native가 생성·prediction한 short input [ds_out,ds_in]=[1.5,2]를 처리합니다.
2. Key (lane1,1.5)가 등록됩니다.
3. 이 short job의 native primitive는 `mature=None`을 반환합니다.
4. 이후 long input [1.5,14.5]의 re-entry가 같은 key 때문에 거절됩니다.
5. 전체 output에는 다른 작은 shadows와 ego-lane shadows가 남지만 witness ds8을 포함하는 output은 없습니다. 이 판정은 forest가 empty인지 여부와 다릅니다.
6. 같은 images/poses와 동일 native prefix에서 그 **정확한 admission 1개**만 허용하면 long input이 처리되어 witness position이 회복됩니다.

순서와 full output은 `analysis/causal_chain.json`, 전체 target-epoch 사건은 `analysis/target_epoch_all_events.json`에 있습니다. Original과 single-admission은 t<2의 전체 forest 및 t=2 직전 forest가 정확히 같습니다. Intervention은 한 번 적용됐고, 원본과 다른 repair의 정의만으로 적용을 추정하지 않았습니다.

| Method | Witness position이 absent인 update | Target 적용/해석 |
|---|---|---|
| Original | 2, 3.5, 4 s | Target 원형 |
| Single exact admission | 3.5, 4 s | t=2에 1회 적용, 해당 omission 회복; 이후 recurrence는 남음 |
| Admission OFF | 없음 | 전체 sequence에 admission reduction OFF |
| Mature-only OFF | 2, 3.5, 4 s | Mature predicate 변경만으로 admission 원인 회복 안 됨 |
| Current mature guard | 없음 | 지원되는 dominance만 생략하고 나머지 처리하는 기존 보수적 수정 |

전체 sequence에 적용한 OFF/guard는 내부 history가 달라질 수 있습니다. 이 두 방법과 Original의 비교는 같은 외생 sensor sequence의 method comparison입니다. **동일 내부 prefix의 국소 인과 비교는 single-admission**입니다. Position presence는 velocity/history·전체 continuous soundness의 증명이 아닙니다.

## 4. Native default resolution에서의 범위 확인

Low-resolution pixel discretization만의 결과인지 확인하려고 geometry, motion, dynamics를 고정한 채 native constructor 기본값 1920×1080을 별도 protocol로 검사했습니다. Resolution은 실제 observation operator를 바꾸므로 logger 수정이나 동일 정보 조건이라고 부르지 않습니다. 두 resolution의 결과를 하나의 발생률로 합치지 않습니다.

| Method, 1920×1080 | Witness absent 시점 | 결과 |
|---|---|---|
| Original | 3.5 s | Admission 관련 whole-output omission 유지; 정확한 시점은 달라짐 |
| Admission OFF | 없음 | 해당 position omission 없음 |
| Single exact admission at3.5 | 없음 | 같은 prefix·동일 sensor arrays에서 1회 적용하여 해당 시점 회복 |

여기서는 key (1,1)의 앞선 short output [1,1.5]가 **살아 있습니다**. 그러나 long candidate [1,13.5]의 witness를 보존하지 못합니다. 따라서 `mature=None`은 모든 admission omission에 필요한 조건이 아닙니다. 핵심은 “key의 소유자가 존재하는가”가 아니라 “해당 작업의 필요한 coverage가 실제로 유지되는가”입니다. 이 차이는 새로운 일반 원리의 발견보다, 현재 구현에 대한 구체적인 발생 조건의 확장으로 해석합니다.

Native-resolution local replay의 t<3.5 forest와 target 직전 forest, 전 image arrays는 archived Original과 일치했습니다. Original은 t=4에 witness position을 다시 표현하므로 final-only 평가였다면 t=3.5 누락을 놓쳤을 것입니다.

## 5. 소실·재생성과 measurement의 범위

640 scene의 Original은 t=2에 witness를 잃고, t=2.5/3에는 다시 표현하며, t=3.5/4에 다시 잃습니다. Wrapper의 empty-state 재초기화는 t=0에만 발생했습니다. 재생성은 남아 있는 forward shadows가 cross work를 만들고 그 backward traversal이 long interval을 다시 만드는 경로입니다. 예를 들어 t=2.5에서 새 OutBound(1,1.5)가 [1.5,14] mature output을 만듭니다.

따라서 “일단 빠지면 반드시 영구 소실한다”는 설명은 이 native wrapper 결과에 맞지 않습니다. 반대로 나중에 재생성됐다는 사실도 앞선 update의 누락을 취소하지 않습니다. Planner가 어느 update output을 사용했는지를 별도로 연결해야 실제 downstream exposure를 판단할 수 있습니다. 이번 새 scene의 checker/실행은 측정하지 않았습니다.

## 6. 분모, 실패, parity

| 분모 | 실제 수 |
|---|---:|
| Development scene-parameter conditions | 9 |
| Completed traced method sequences | 17 = 9 development + 5 causal comparisons + 2 resolution control + 1 resolution-local |
| Uninstrumented sequence replays | 17 |
| Native sequence executions / update calls | 34 / 306 |
| Valid native sequences / invalid native sequences | 34 / 0 |
| Native execution 전 instrumentation setup 실패 | 1 |
| Native output의 semantic-unresolved epoch | 0 (이번 explicit bounded position scope) |
| Held-out scene validation | 0 |

Setup 실패는 `confirmation_v2/execution_failure.json`에 보존했습니다. Key logger의 source-string match가 공백·변수명 차이로 맞지 않아 assertion에서 종료됐고, native episode 결과는 생성되지 않았습니다. v1은 passive key event가 없었지만 input/output trace는 보존됐습니다. v3에서 logger만 보완한 뒤 chosen Original의 모든 update output이 v1과 같은지 확인했습니다. 17개 method sequences 모두 별도 uninstrumented output과 일치했습니다. Raw `native_rejects`는 OFF/guard에서는 **native predicate가 참이었을 횟수**이며 실제 rejection 수로 읽으면 안 됩니다.

## 7. 실용적 의미와 한계

확인한 것은 “수작업 shadow forest만 있어야 C1이 생긴다”는 제한을 넘는 한 경로입니다. 고정 geometry에서 생성한 sensor arrays, native initialization/prediction/update, 독립 hidden body, whole-output loss, 정확한 local admission 회복을 연결했습니다. 동시에 resolution이 발생 시점과 short-output 상태를 바꾼다는 조건도 드러났습니다.

다른 uncertainty-based safety module을 평가할 때는 각 update에서 실제로 소비되는 union을 검사하고, processing record·살아 있는 representative의 존재와 필요한 coverage를 구분해야 합니다. Final output만 비교하거나 omission과 regeneration을 합치면 해당 update의 판단 근거를 놓칠 수 있습니다.

새 복잡한 algorithm의 필요성은 추가로 입증되지 않았습니다. 기존 admission OFF와 current mature guard가 이 case의 position witness를 전 시점 보존했습니다. 새 workload의 시간·메모리·실시간 요구는 평가하지 않았으며 예전 update-only 비용 결과를 이 sensor workload의 실측 비용으로 바꾸어 쓰지 않습니다.

여전히 미확보인 것은 CARLA/실제 sensor frontend·map extraction에서의 동일 경로, natural-scene frequency, 새 scene의 fixed-checker permission, 실제 collision·completion, whole continuous soundness, 직접 RFM empirical fit입니다. 기존 C1의 18 candidate 중 14 permission 차이는 이전 checker fixture의 증거로 유지하며 이 새 scene의 수치로 옮기지 않습니다.
