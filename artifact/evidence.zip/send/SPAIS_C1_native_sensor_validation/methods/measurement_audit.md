# C1 sensor realization: 독립 measurement audit

작성일: 2026-09-24. 이 문서는 실험 담당자와 별도로, 저장된 source·geometry·depth·pose·trace만 재검산한 결과입니다. Native pipeline, simulator, GPU 실험을 새로 실행하지 않았습니다. 실행 가능한 audit와 상세 판정은 [measurement_audit.py](measurement_audit.py), [measurement_audit.json](measurement_audit.json)에 보존했습니다.

이번 v2 audit는 `native_resolution_local` 2개 실행을 추가 반영했습니다. 앞선 **32 runs/288 updates 시점**의 audit는 [measurement_audit_v1.md](measurement_audit_v1.md), 동명 `.py`·`.json`, [snapshot manifest](measurement_audit_v1_snapshot.json)에 보존했습니다. 분모 차이는 검토 시점과 포함 artifact의 차이이며 이전 결과를 삭제하거나 제외한 것이 아닙니다.

**선택된 scene에서 sensor-generated omission 및 single-admission 개입의 국소 효과를 무효화하는 measurement 불일치는 발견하지 못했습니다.** 다만 이는 custom road/client interface 위에서 실행한 geometry-generated synthetic depth 결과입니다. CARLA sensor 재현, 자연 발생률, held-out generalization, action permission 또는 전체 planner soundness를 입증한 것은 아닙니다.

## 확인 범위와 분모

| 묶음 | Traced runs | Uninstrumented parity runs | 완료 update calls | 해석 |
|---|---:|---:|---:|---|
| `development_v1` | 9 | 9 | 162 | 같은 scene family에서 사전 고정한 camera velocity 3 × gap 3 탐색입니다. |
| `confirmation_v3` | 5 | 5 | 90 | Development에서 선택한 1 scene의 mechanism 개입입니다. Held-out validation이 아닙니다. |
| `native_resolution_control` | 2 | 2 | 36 | 같은 scene의 observation resolution control입니다. 독립 scene 2개가 아닙니다. |
| `native_resolution_local` | 1 | 1 | 18 | 같은 1920 scene의 exact single-admission 개입이며 archived Original을 재사용했습니다. |
| 합계 | 17 | 17 | 306 | 34개 실행 모두 완료했으며 각 실행은 9 epochs입니다. |
| `confirmation_v2` | 0 | 0 | 0 | Instrumentation regex assertion이 native execution 전에 실패한 1회 시도입니다. 원자료를 유지합니다. |

`summary.json`의 `native_rejects`는 `native_would_reject=True`의 횟수입니다. `admission_off`, `single_admission`, `mature_guard`에서는 실제 admission rejection 횟수와 같지 않습니다. 이를 실제로 생략한 job 수로 표시해서는 안 됩니다. 이 audit의 native 실행 분모에는 offline numerical readback 자체를 더하지 않습니다.

## Sensor 입력의 독립 검산

| 점검 | 실제 범위 | 결과와 해석 |
|---|---|---|
| Pixel depth의 analytic 재구성 | 선택된 640×360 scene의 8,294,400 pixels, 1920×1080 control의 74,649,600 pixels | 저장된 static rectangles·ground·pinhole pose에서 각 ray의 first hit를 독립 식으로 계산했으며 float32 exact mismatch 0입니다. |
| Native visibility decision의 scalar 재구성 | 네 묶음의 모든 traced run, 21,582 query records | Lane center의 두 높이, camera quadrant, pixel rounding, depth comparison, 5 m shortcut을 별도 코드로 계산했습니다. Recorded verdict와 mismatch 0입니다. |
| Pose·image shape·numeric validity | 모든 12개 저장 scene instances, 9 epochs씩 | Camera path와 4 yaw pose가 설정과 일치하고 image가 지정 shape의 finite positive float32입니다. |
| Full-body occlusion certificate | 모든 저장 epoch 및 각 camera segment의 endpoint bounds | Certificate 수치 및 Boolean과 mismatch 0입니다. 선택 scene은 t∈[0,4] 전체에서 stationary body가 right panel 뒤에 남습니다. 최소 plane-intersection margin은 약 0.658 m입니다. |
| Body 삽입 시 sensor 비간섭 | 640 및 1920 scene에서 body의 projected bounds 안 모든 pixel ray와 독립 slab intersection | Body를 교차하는 rays는 각각 42,576개와 382,391개이며 저장 depth가 달라지는 pixel은 모두 0입니다. Root 분석의 모든 epoch hit/change counts와 일치합니다. |

Full-image geometry 검산은 위 표의 두 저장 scene에만 수행했습니다. 다른 scene에서 모든 pixel을 검사했다고 주장하지 않습니다. 이 독립 계산과 renderer는 같은 명시적 pinhole/opaque-panel model을 공유하므로 물리 camera의 정확성을 검증한 것도 아닙니다.

Source상 depth 생성은 native lane query를 보고 pixel 값을 채우는 방식이 아닙니다. **먼저 고정된 panels와 ground를 모든 image rays와 교차시켜 full depth images를 만들고, 그 뒤 unmodified `DepthVisibility`가 필요한 lane positions를 조회합니다.** 따라서 prescribed Boolean mask의 pixel encoding과 구별되는 synthetic sensor-generated 입력입니다. Camera forward-axis depth이며 Euclidean range가 아니라는 native contract도 일치합니다.

`manager()`는 native constructor 전체를 실행하는 대신 custom lane/network/client를 제공하고 관련 fields를 채웁니다. Road parser, 실제 CARLA map, 실제 sensor capture는 검증 범위에 없습니다. 다만 ego centerline은 target lanes의 공통 endpoint를 실제로 지나도록 구성되어 있으며, backward shadows는 외부에서 hand-construct하여 넣지 않고 empty-list native initialization 이후 forward/cross traversal에서 생성됩니다. 관측 기간의 camera path는 panel plane과 분리되어 있습니다. 명시하지 않은 ego body 전체의 collision freedom이나 미래 route feasibility를 이 사실에서 도출하지 않습니다.

5 m visibility shortcut은 모든 run에서 각각 9개 query에 적용됩니다. 이는 native behavior를 그대로 재현한 것입니다. 독립 full-body certificate를 이 shortcut이나 native two-height verdict로 대신하지 않았습니다.

## Witness와 coverage 판정

감사 코드는 실험의 `position_segments`를 import하지 않고 serialized forest를 직접 순회했습니다. 명시적인 `InOutBound`, `OutBound`, terminal `InBound`, `ShadowNode`와 finite `leaf_depth`로부터 lane-position projection을 계산했습니다. 153개 traced epochs에서 unknown tree shape나 truncated tail이 없었으며 저장된 position status와 모두 일치했습니다.

이것은 **necessary position projection**입니다. `ds=8`이 전체 forest 어디에도 없으면 해당 stationary witness의 coverage도 없다고 할 수 있지만, position이 존재한다는 사실은 velocity/history coverage나 모든 feasible trajectories의 보존을 증명하지 않습니다. 특히 native velocity-envelope discrepancy와 분리해야 합니다.

`velocity=1`의 세 development 조건은 t=3.5와 t=4에서 stationary body 전체의 right-panel occlusion certificate가 성립하지 않습니다. 이때 logged `witness_position_present`는 position 존재를 뜻할 뿐, body의 full-horizon feasibility를 뜻하지 않습니다. 이들 조건의 t=1 omission은 t≤1 observation prefix에 대해 certificate가 성립하므로 별도로 유지할 수 있습니다. 9조건 모두가 t∈[0,4] 내내 같은 hidden-body witness를 가진다고 쓰면 범위 초과입니다.

선택된 `velocity=0.5, gap=-0.5` scene은 모든 epoch와 연속 camera segments에서 strict occlusion bounds를 충족합니다. Object의 stationary velocity·acceleration은 지정 dynamics 범위 안에 있으며 body footprint가 lane segment 안에 있습니다. 이 certificate는 geometry·관측 prefix를 근거로 하며 Original/guard output을 truth로 사용하지 않습니다.

## Causal replay와 event chronology

| 확인 항목 | Raw readback 결과 |
|---|---|
| Development Original ↔ confirmation Original | Scene, 모든 depth arrays, poses, 9개 step records, visibility query sequence가 동일합니다. |
| Original ↔ single admission의 pre-intervention prefix | t<2의 모든 step records 및 t=2 update 입력 prior forest가 동일합니다. |
| 실제 intervention 적용 | Freeze에 명시한 exact shadow, exact t=2에 grant 1회만 적용됐습니다. |
| 원 실행의 chronology | Event index 266에서 short job key `[1,1.5]` 등록 → 267에서 primitive가 `mature=None`, children/visited empty 반환 → 306에서 long job에 같은 key가 존재하여 admission rejection입니다. |
| Rejected target의 실제 처리 여부 | Original에 exact long job pop이 없고, single-admission에는 event 307에서 pop이 있습니다. |
| Logger 영향 | 모든 17개 traced run과 fresh uninstrumented run의 steps·status·error·applied intervention이 같습니다. |
| 사전 고정 여부 | Confirmation measurement freeze timestamp가 실행 시작보다 앞섭니다. 선택 scene은 development에 사용됐다는 사실은 유지합니다. |

Backward key는 **primitive 실행 전에** 등록됩니다. 따라서 `primitive=None → key 등록`이라고 시간 순서를 바꾸면 안 됩니다. 직접적인 증거는 `key 등록 → no mature output → key가 남아 후속 long job 차단`입니다.

선택 scene에서 Original의 position omission은 t=2,3.5,4입니다. Single-admission은 t=2만 회복하고 t=3.5,4 omission을 유지합니다. Admission OFF와 mature guard는 관측한 9개 epoch에서 position을 보존하고, mature-only OFF는 Original의 omission times를 유지합니다. 이 조합은 t=2 target의 admission suppression에 대한 국소 원인 설명을 지지합니다. Single repair의 성공을 시스템 내 유일한 원인 식별, 모든 epoch 해결 또는 전체 soundness로 확장할 수는 없습니다.

## Resolution control의 의미

1920×1080에서는 Original omission이 t=3.5에서 확인됐고 admission OFF에서는 해당 position omission이 없었습니다. 640×360의 t=2,3.5,4와 timing이 달라졌습니다. 따라서 **이 geometry의 현상은 낮은 resolution에서만 관측된 것은 아니지만, 구체적인 발생 timing은 observation discretization에 영향을 받습니다.** Resolution 변경은 observation operator를 바꾸므로 같은 global feasible-trajectory set을 보존한 순수 instrumentation 수정이라고 분류하지 않습니다. 선택한 full-body witness는 두 resolution 모두 같은 geometric certificate를 만족합니다.

추가된 1920 exact single-admission에서는 archived Original과 images/poses/scene, t<3.5의 7개 epochs, target 직전 prior forest가 정확히 같습니다. 사전 고정한 t=3.5 long candidate에 grant가 1회 적용됐으며, Original의 `witnessed_omission`이 `witness_position_present`로 바뀌었습니다. Protocol timestamp도 실행 시작보다 앞섭니다.

이 시점의 short [1,1.5] primitive는 event 448에서 실제 mature output을 반환하며 **그 short output은 최종 forest에도 남아 있습니다.** Long [1,13.5]는 Original event 481에서 admission rejection되고, 개입 실행에서는 event 482에서 pop됩니다. 따라서 640에서 관측한 `mature=None`은 모든 admission omission의 필수조건이 아닙니다. Representative가 살아 있어도 필요한 witness를 보존하지 못하면 key 기반 생략을 정당화하지 못한다는 범위 확장입니다. 이는 같은 scene의 resolution 변경에 따른 subtype이며 독립 topology나 natural episode 발견으로 세지 않습니다.

Body 추가의 pixel 비간섭 검산은 root의 `audit_body`를 import하지 않았습니다. Camera 앞쪽 convex AABB의 projected corner bounds 밖에서는 ray가 body를 교차할 수 없다는 성질을 이용해 후보 rays를 한정한 뒤 별도 slab test를 했습니다. 모든 교차 pixel과 root의 all-image test counts가 일치했습니다. 이는 명시된 body 추가가 해당 synthetic sensor arrays를 바꾸지 않는다는 증거이며, 서로 다른 geometry 전체의 observation equivalence나 physical camera fidelity를 뜻하지 않습니다.

## 최종 판단

이번 실험은 기존 hand-specified visibility schedule의 C1 논리를, 고정 geometry에서 생성한 synthetic depth와 native visibility/update 경로에서도 확인한 존재 증거로 사용할 수 있습니다. 새로 확보된 연결은 `fixed geometry → full depth images → native visibility/init/update → key lifecycle → whole-output position omission → exact admission 개입에 따른 국소 회복`입니다.

실제 simulator sensor, natural traffic 발생률, CARLA road-network parser의 topology 유효성, held-out structural prediction, 동일 scene의 action permission, collision 및 completion은 여전히 별도 증거가 필요합니다. 독립 audit에서 이 범위를 넘어서는 주장을 정당화하는 자료는 발견하지 못했습니다.
