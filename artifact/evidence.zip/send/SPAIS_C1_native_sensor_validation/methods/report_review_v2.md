# C1 report / README 독립 사실 검토

2026-09-24, `native_resolution_local`까지 포함한 저장 원자료를 기준으로 검토했습니다. Native experiment를 재실행하지 않았습니다. 독립 audit의 이전 32-run 범위는 `measurement_audit_v1.*`로 보존하고 현재 audit를 34 runs/306 updates로 갱신했습니다.

## 판정

`c1/report.md`의 핵심 결론을 반박하는 raw/source 불일치는 발견하지 못했습니다. 주요 서술은 다음과 같이 실제 자료와 대응합니다.

| 보고서 주장 | 독립 점검 |
|---|---|
| Sensor-generated synthetic counterexample이며 CARLA/natural-frequency 결과가 아님 | Full-image renderer가 fixed panels/ground를 입력으로 사용하며 native query mask를 depth에 encode하지 않는 점을 확인했습니다. Custom road/client boundary도 명시돼 있습니다. |
| 640의 exact single admission이 t=2 position을 회복 | 동일 images/poses, t<2 prefix, target 직전 forest, exact grant 1회, 실제 target pop과 output 회복을 확인했습니다. |
| 1920의 exact single admission이 t=3.5 position을 회복 | Archived Original과 전 inputs 및 7개 pre-target epochs가 같습니다. Grant 1회와 target pop, witness 회복을 확인했습니다. |
| 1920에서는 short mature output이 살아 있음 | Native event 448의 mature output이 같은 epoch 최종 forest에 남는 점을 직접 확인했습니다. Long input의 event 481 rejection과 구별됩니다. |
| Body 추가가 sensor arrays를 변경하지 않음 | Root의 slab code와 결과를 검토하고, 별도 projected-AABB enumeration으로 교차 rays 및 changed-depth counts를 재계산했습니다. 모든 epoch counts와 일치하며 변경 pixel 0입니다. |
| 34 executions/306 updates, pre-native setup failure 1회 | 네 batch의 summary·completion·각 traced/plain raw를 대조했습니다. Invalid native run 0과 별도 instrumentation 실패 1회를 구분했습니다. |
| Natural scene와 held-out 검증이 아님 | Development-selected causal replay와 resolution control이라는 제한이 본문에 일관되게 유지됩니다. |
| 기존 14/18 permission을 새 scene의 action effect로 옮기지 않음 | 새 scene의 permission/collision/completion은 미측정으로 표시됐습니다. |

## Measurement naming 수정

처음 검토할 때 `epoch_matrix.csv`의 `implicit_tail`은 generic segment decoder가 bounded terminal `InBound`에도 True로 주는 flag였습니다. 이를 실제 truncated semantics로 읽으면 `semantic-unresolved=0`과 혼동할 수 있어 수정 요청을 전달했습니다.

최종 CSV와 `analyze_sensor.py`에서 `generic_segment_implicit_flag`와 실제 `truncated_leaf_depth`를 분리한 것을 확인했습니다. 예를 들어 640 Original t=4의 finite `leaf_depth=1.5`는 generic flag가 있어도 truncated tail이 아닙니다. 이는 측정 의미의 명료화이며 native output이나 witness status를 바꾼 수정이 아닙니다.

## README 검토와 잔여 범위

README의 현재 local Markdown links는 모두 존재합니다. CPU 범위, revision, dependency snapshot, preserved old bundle, scientific validation과 transfer verification의 구분도 적절합니다. README의 D1 숫자와 Drive upload 완전성은 이번 C1 measurement review에서 독립 재검증하지 않았습니다. C1 reproduction command block은 대표 세 실행을 제공하지만 `native_resolution_local` command 자체는 해당 start manifest에 보존돼 있습니다.

이번 결과는 body insertion 하나와 지정된 synthetic observation model의 양립성을 입증합니다. 서로 다른 전체 world의 일반적인 observation equivalence, 실제 camera fidelity, native road-parser metadata, whole-planner soundness, collision/completion 또는 RFM empirical result는 입증하지 않습니다. 보고서는 이 경계를 유지하고 있습니다.
