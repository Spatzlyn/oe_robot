# C1 sensor path의 독립 source·method 검토 — 2026-09-24

이 문서는 실제 sensor-generated 관측과 기존 prescribed mask의 차이, native initialization의 요구사항, 사용할 수 있는 geometry 경로를 source에서 검토한 기록입니다. GPU·simulator·추가 native experiment를 실행하지 않았으며 다른 process를 변경하지 않았습니다. [전달 종합 문서](../inputs/SPAIS_C1_reaudit_synthesis_and_paper_direction_2026-09-24.md)의 input reachability와 sensor realization을 별개로 확인하라는 요구를 적용했습니다. 아래 구현 후보는 완료된 재현 결과가 아닙니다.

## 1. Native interface에서 실제로 확인한 것

| Component | 실제 interface / source 동작 | 새 실험의 요구 |
|---|---|---|
| `DepthVisibility.check_visibility` | Lane의 nearest waypoint center 위 z=0.5m,1.2m 두 점 중 하나가 visible이면 lane query=True입니다. Left/right vertices는 읽지만 현재 active visibility test에는 쓰지 않습니다 | Two-point lane visibility와 전체 3D object visibility를 구분합니다 |
| Depth range / near rule | Camera0 frame 기준 distance<5m이면 depth image를 보지 않고 True입니다. 그 밖은 distance<range에서 camera 선택·depth 비교를 합니다 | Occlusion을 시험하는 lane targets를 near rule 밖에 둡니다. Native near-rule를 수정해 원하는 mask를 만들지 않습니다 |
| Camera 선택 | Reference camera0의 azimuth로 4개 camera index를 선택합니다. 순서는 yaw0,90,180,-90입니다 | Camera extrinsic order, handedness, reference frame을 기록하고 projection으로 확인합니다 |
| Pixel / depth | `T_c2img`는 camera forward x를 image depth z로 보냅니다. Projection 후 round한 pixel의 depth와 `pt_uvz[2]`를 비교합니다 | Renderer는 Euclidean range가 아닌 native consumer가 기대하는 axial depth를 내야 합니다. Ray parameter를 camera-forward component=1로 두면 hit parameter가 axial depth가 됩니다 |
| Sensor geometry | Default1920×1080, horizontal FOV110°, Camera mount x=-0.5,y0,z1.8입니다. `DepthVisibility` constructor는 width/height/FOV를 받습니다 | Resolution/FOV를 바꾸면 명시한 synthetic sensor configuration입니다. Native default 재현이라 부르지 않습니다 |
| Lane cache | `waypoint_map[ds]`의 time이 현재 time과 같으면 cached verdict를 반환합니다 | Method별 fresh network/cache를 사용하고, fresh sensor query와 cache hit 출처를 구분합니다. 다른 scene의 같은 time cache를 공유하면 안 됩니다 |
| Projection cache | Camera별 `t_list`가 현재 time보다 작을 때만 transform을 갱신합니다 | Scene/method마다 fresh checker를 두거나 정확한 reset을 합니다. Nonmonotonic time 또는 같은 time에 다른 camera pose는 별도 문제입니다 |
| `OctomapVisibility` | 같은 두 center-height ray를 static occupancy map과 bbox occlusion으로 검사합니다. Range 밖은False, map hit이 target보다0.5m 이상 가까우면 occluded입니다 | Native Octomap prediction과 depth observation은 다른 observation model입니다. 둘의 equality를 가정하지 않습니다 |
| Map loading | `OccupancyMap(filename=...)`은 파일이 없으면 empty map을 생성할 수 있습니다 | Project rule에 따라 파일 존재·hash·occupied cells를 먼저 확인하고 empty fallback을 차단합니다 |

Source: `repos/rss_occlusion/risk_analysis/visibility_checker.py`, `mapping/occupancy_map.py`, `sensing/camera_module.py`. `DepthCamera`는 CARLA raw bytes를 meter-depth로 decode하고 `get_point_cloud`는 inverse intrinsics로 depth를 사용합니다. Native comparator와 이 소비 경로를 기준으로 CPU renderer의 units를 맞춰야 합니다. 이 검토는 CARLA depth renderer 자체를 독립 검증한 것이 아닙니다.

## 2. 기존 C1 초기화와 native 초기화는 다릅니다

기존 `analysis/semantic_coverage/run_small_graph.py`는 t=0에 backward `OutBound(1,0,0)`를 직접 만들고 이후 `predict_shadow(history,t)`를 연결합니다. `manager()`에는 `risky_lane=[1,2]`가 미리 들어 있습니다. 이는 기존 bounded C1에 명시한 initial uncertainty를 주는 방식이지만 실제 sensor pipeline의 자동 initialization을 검증하지 않습니다.

Native `ShadowUtils.update_visibility`와 `update_visibility_octomap`는 `shadow_list`가 empty이면 다음을 수행합니다.

1. Ego location에서 road waypoint를 조회합니다.
2. `find_lane(road_id,section_id,lane_id)`로 ego lane을 찾습니다.
3. `ds_start = waypoint.s - lane_section.s_start - sign(lane_id)*2.5`를 계산합니다.
4. Ego lane에 forward `InBound`를 생성하고 native forward traversal을 실행합니다.
5. Forward traversal의 `lane.cross`, `merge`, `adj_oppo` 경로가 backward 위험 shadow를 생성하고 `add_risky_lane`을 호출할 수 있습니다.

따라서 fully-visible ego lane과 실제 교차하는 target lanes를 두면 native cross 처리로 C1의 backward jobs를 만드는 경로가 있습니다. **단순히 `cross=[1,2]`를 넣었다는 사실은 정상 road geometry에서 그 관계가 생성됐다는 증거가 아닙니다.** Ego lane y=-10과 target lane y=0이 모두 평행 직선이면 실제로 cross하지 않습니다. 방법을 다음처럼 구분해야 합니다.

- Synthetic lane topology를 수동으로 제공하고 native initialization 함수부터 실행: native wrapper-generated input이지만 native map-construction realism은 미검증입니다.
- Ego lane의 현재 camera motion 구간 뒤에 target junction을 실제로 가로지르는 polyline을 두고 cross 관계의 geometry를 별도 검사: geometry-consistent synthetic initialization입니다. RoadNetwork/OpenDRIVE parser까지 실행했다고는 할 수 없습니다.
- 실제 CARLA/OpenDRIVE road network와 native RoadNetwork가 cross metadata를 생성: simulator-native initialization 경로입니다. 이 경우에만 해당 map extraction까지 검증한 것입니다.

기존 C1은 lane1→lane2 transition이 중요합니다. Native `extent_outbound`는 backward 위험 shadow를 successor로 전파할 때 `in_risky_lane(successor)`를 검사합니다. 따라서 risky_lane2의 등록 provenance도 기록해야 합니다. 두 target lanes를 cross metadata에 추가하면 초기 jobs 자체가 늘 수 있으므로, 기존 fixture와 같은 initial forest가 나오리라고 가정하지 않습니다.

### Empty output의 재초기화가 중요합니다

Native wrapper는 첫 시각뿐 아니라 **어느 시각이든 shadow_list가 empty이면 재초기화**합니다. 기존 small-graph harness는 t0 이후 `predict_shadow(empty)`로 empty를 유지합니다. 따라서 새 sensor path에서 중간 omission 후 다음 epoch에 representation이 다시 생성될 수 있습니다. 이는 logger 오류가 아니라 실험 대상 pipeline의 동작 차이입니다.

Final t=4만 비교하면 이 현상을 놓칠 수 있습니다. 각 epoch의 pre-forest, `initialization_entered`, initial queue origin, post-forest, feasible witness membership, 해당 output을 checker가 소비한 시점을 기록해야 합니다. Transient omission과 persistent omission을 별도 결과로 둡니다.

## 3. Sensor-generated와 mask encoding의 경계

| 경로 | 판정 | 허용하는 claim |
|---|---|---|
| 시간별 `field(lane,ds,t)` Boolean을 직접 반환 | Prescribed observation mask | 기존 C1 model-level counterexample |
| Prescribed mask를 목표 pixel에 depth0 또는far 값으로 역삽입 | Mask encoding / interface test | Native camera projection interface를 통과함; physical sensor realization 아님 |
| Query ray마다 mask를 보고 작은 blocker를 생성 | Mask encoding을 geometry처럼 포장한 것 | Scene feasibility를 별도 증명하지 않는 한 sensor-generated claim 불가 |
| 고정 opaque panels/AABBs, fixed sensor intrinsics, 합법적인 moving camera를 정하고 **모든 pixel ray의 first hit**으로 depth를 생성 | Geometry-generated synthetic depth | 명시한 ideal geometric sensor에서의 native depth-processing 재현 |
| 같은 fixed geometry에서 full Octomap을 만들고 native map rays로 visibility 생성 | Geometry-generated map prediction | Native Octomap prediction model의 realization; actual depth camera observation과 동일하다고 가정 불가 |
| 실제 CARLA scene과 depth sensors의 동기화된 raw frames 사용 | Simulator sensor-generated observation | 해당 simulator/asset/sensor configuration에서의 실행 |

Geometry-generated CPU renderer는 CARLA sensor를 실행한 것이 아니지만 prescribed mask와는 다릅니다. 중요한 조건은 geometry가 query answer나 method output을 읽지 않고 고정돼 있고, 전체 image에 일관된 ray/occlusion 법칙을 적용하는 것입니다. Full image를 dense 저장하지 않고 lazy rendering하더라도 각 pixel 값이 동일 fixed geometry에서 유도됨을 독립 확인해야 합니다. 이 경우 lazy image와 query mask를 혼동하기 쉬우므로 첫 검증은 full image가 더 명확합니다.

Scene를 먼저 설계한 뒤 geometry parameters를 exploration한 것은 허용됩니다. 그러나 실패한 탐색 조건과 전체 분모를 보존하고, 최종 geometry를 고정한 후 검증해야 합니다. Positive outcome을 얻은 geometry만 자연 발생 sample처럼 집계해서는 안 됩니다.

## 4. Fixed panel 경로의 실행 가능성과 제한

Root가 검토 중인 좌표는 target lane y=0, fixed vertical panels y=-5, camera y=-10입니다. Camera x만 움직이고 모든 wall 높이가 target rays를 충분히 가리면 panel silhouette와 gap이 target lane을 따라 이동합니다. 두 plane이 정확히 중간에 있고 ray가 lane y=0에 도달할 때,

`x_hit = (x_camera + x_target)/2`, 따라서 `x_target = 2*x_panel − x_camera`

입니다. 즉 static panel edge/gap도 moving camera에서 translated visibility intervals를 만듭니다. Native two heights에 대해 z_hit도 camera/target height의 중간입니다. Camera height1.8m, target heights0.5/1.2m이면 panel hit heights는1.15/1.5m입니다. Panel vertical extent가 이 둘을 포함하는지 확인해야 합니다.

이 기하는 좁은 visible gap과 떨어진 hidden component를 만들 수 있으므로 C1 split/re-entry를 검토할 이유가 있습니다. 다만 기존 prescribed sequence의 여러 interval을 **정확히 모두 재현할 수 있다고 미리 말할 수 없습니다.** 같은 fixed plane의 모든 edge는 camera x에 따라 함께 이동합니다. 기존 mask에서 일부 boundary만 움직이고 다른 boundary는 고정되는 pattern은 이 단순 장면의 제한과 충돌할 수 있습니다. Primitive visibility가 조금 다른 sequence에서도 같은 admission mechanism이 생기는지 별도로 확인할 수 있으며, 이 경우 기존 observation-equivalence proposition을 재사용하지 않습니다.

Ego motion은 camera를 시각별로 임의 teleport하는 대신 고정 trajectory로 정의하는 것이 좋습니다. Linear x(t) 또는 piecewise smooth motion이면 speed/acceleration을 명시할 수 있습니다. Motion이 lane centerline과 어긋나거나 panels를 통과하면 native road execution 가능성의 claim을 줄여야 합니다. Native ego physics OFF 여부와 상관없이 geometry consistency는 확인해야 합니다.

### Witness의 독립 feasibility

Stationary witness ds8..11, v=a=0을 쓰려면 다음을 각각 확인합니다.

- Initial uncertainty가 witness를 포함하는지와 **그 initial uncertainty 자체가 native 초기화에서 생성됐는지**.
- 모든 sensing epochs의 reference observation model에서 footprint가 허용되는지.
- 지정 continuous interval [0,T] 동안 hidden이라고 주장하려면 연속 camera trajectory와 fixed panels에 대한 geometric argument가 있는지. Epoch별 ray samples만으로 사이 시각을 증명하지 않습니다.
- Physical 3D invisibility를 주장하려면 width·height를 포함한 body의 ray cone이 opaque panel에 의해 가려지는지. Native center-height tests만으로 이를 증명하지 않습니다.
- Witness가 panel·ground·lane boundary·known object와 충돌하지 않고 현재 model의 dynamics를 만족하는지.

Panel plane y=-5, object centerline y=0이라는 배치에서는 적절한 narrow footprint의 physical clearance를 쉽게 줄 수 있습니다. 특정 폭/높이를 채택했다면 body corners와 continuous ray-cone bounds를 이용한 analytic enclosure가 가능하며, sparse samples의 pass를 완전한 enclosure proof처럼 쓰지 않습니다.

## 5. 후보 경로와 권장 순서

| 경로 | 최소 입력·구현 | 장점 | 남는 제한 | 우선순위 |
|---|---|---|---|---|
| CPU fixed-panels → full axial-depth images → native DepthVisibility → native initialization/update | Geometry JSON, camera trajectory/intrinsics, lane geometry/topology, native observer cache 초기화 | GPU 없이 new sensor-information pathway를 명확히 만들 수 있습니다. Masks를 직접 주지 않습니다 | Ideal synthetic sensor; road metadata가 manually authored면 그 범위를 명시; 기존 C1 exact mask 재현 미보장 | 1 |
| 기존 D05 CARLA raw depth sequence의 native 재생 | Preserved raw frames/poses, verified root prefix, pinned map/source | 이미 확인한 actual sensor path를 재사용하여 startup 반복을 줄입니다 | Reconstructed map, implicit tails, nominal prediction과 actual observation 차이가 남습니다. Pure C1 closed fixture를 대체하지 않습니다 | 보조·재사용 우선 |
| Fixed geometry → voxel occupancy map → native OctomapVisibility | Occupancy source/voxelization rule, free/occupied/unknown semantics, file hash | 공식 prediction 경로를 직접 사용합니다 | castRay unknown 처리·0.5m tolerance·resolution에 민감; actual camera evidence와 다름 | Depth가 문제를 좁힌 뒤 조건부 |
| 실제 CARLA geometry·sensors·native RoadNetwork | Assets, synchronized images/poses/frame, GPU6, own simulator instance | 가장 직접적인 simulator-native 생성 근거입니다 | 실행비·asset geometry·ego controller·map interface가 추가 변수입니다 | CPU path에서 확인할 구체적 불확실성이 남을 때 |

현재 과제에서는 새 renderer를 사용하더라도 action checker, dynamics, reduction method를 동시에 바꾸지 않는 것이 좋습니다. Old C1 permission effect는 그대로 재사용하고, 새 scene에서 same-checker effect를 주장하려는 경우에만 추가 paired check를 수행합니다.

## 6. 실행 전에 고정할 최소 admission gates

- Geometry와 sensor source hash, lane endpoint/adjacency/cross의 일관성, camera extrinsic order, axial-depth units, image bounds.
- Independent direct ray calculation과 rendered-pixel 비교: occluder/no-occluder, beyond range, near-rule, edge gap의 interior·boundary를 포함합니다. Ray/rounding 차이는 tolerance를 사전 지정하고 기록합니다.
- Synthetic ray pipeline에 visibility mask나 method verdict가 renderer 입력으로 들어가지 않는지 dataflow를 검사합니다.
- Fresh network/checker마다 동일 raw observations가 native visibility query 결과와 초기 forest를 만드는지 parity를 확인합니다.
- Native initialization events와 risky-lane additions, queue ordering, key registration, primitive returns, generated children, admission/mature rejections, whole forest를 시점순으로 저장합니다.
- Mechanism 판정은 generic digest difference가 아니라 owner/key/long re-entry/실제 target 적용과 independent feasible-witness absence로 합니다.
- Local intervention은 같은 native prefix와 raw depth images를 입력으로 시작합니다. Counterfactual 분기 후 autonomous output이 달라질 수 있으므로 isolated target-epoch causal comparison과 sequential system behavior를 구분합니다.

예상한 C1이 발생하지 않으면 `target condition absent`, `target present without feasible omission`, `transient omission then reinitialization`, `unsupported semantics`, `invalid input`을 나눕니다. 이를 모두 C1 반증이나 sensor realization 불가능으로 묶지 않습니다.

## 7. Result accounting과 claim 수정 기준

Geometry exploration의 전체 attempts, invalid, unresolved, target 미발생, positive cases를 보존합니다. 같은 geometry의 method5개와 logger parity calls를 independent scene 수로 세지 않습니다. Diagnostic rendering queries, native updates, reference/witness checks와 actual paired intervention calls의 수를 별도 column으로 둡니다.

| 확인 결과 | 강화 가능한 claim | 유지할 한계 |
|---|---|---|
| Fixed scene depth에서 native init→same C1 lifecycle→feasible witness absence→single admission recovery | Geometry-generated synthetic sensor와 native initialization 경로에서 C1 발생 | Actual CARLA/RFM occurrence·frequency·collision은 아님 |
| Same lifecycle이 있지만 footprint가 실제 visible | Internal scheduling anomaly 관찰 | Feasible hidden-object omission claim 불가 |
| Manual topology에서만 생성, geometry cross inconsistent | Native function unit interface에서 생성 | 정상 road pipeline realization 미입증 |
| Native wrapper가 다음 epoch에 witness를 재생성 | Transient omission과 initialization의 역할 | 기존 persistent final-empty claim을 그대로 재사용할 수 없음 |
| Native init이 예상 OutBound/history를 만들지 않음 | 생성 경로의 구체적 차이를 밝힘 | Hand-seeded workaround를 native success로 바꾸지 않음 |
| 모든 exploratory scenes에서 미발견 | 명시한 geometry budget 내 미발견 | 일반 불가능성 증명 아님 |
| Geometry 두 조건 모두 C1/회복 | 두 구성의 execution evidence | 이전 mask의 observation-equivalence proof는 새 geometry에 별도 검증 필요 |

후속 protocol·code·raw results가 나오면 이 문서에 별도 readback을 추가합니다. 현재 문서는 source-grounded design review이며 결과를 예측한 부분을 실제 관찰로 세지 않습니다.
