#!/usr/bin/env python3
"""Offline independent readback. Does NOT import or execute the native pipeline.

Reconstructs geometric pixel depths, public visibility contract, and finite tree
position support from serialized inputs/outputs. No simulator, GPU, or new
experimental episode is used. Audit tolerances do not change experiment gates.
"""
import collections
import datetime
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parents[1]
C1 = BASE / 'c1'
BATCHES = ['development_v1', 'confirmation_v3', 'native_resolution_control',
           'native_resolution_local']


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def body_certificate(camera_x, gap):
    # A camera-to-body segment crosses y=-5. Every body point lies within the
    # axis-aligned box; coordinate extrema of its plane projection occur at
    # its corners because the denominator is positive on y=[-.5,.5].
    corners = []
    for x, y, z in itertools.product([8., 11.], [-.5, .5], [0., 1.5]):
        lam = 5. / (10. + y)
        corners.append([camera_x + lam * (x - camera_x),
                        1.7 + lam * (z - 1.7)])
    arr = np.asarray(corners)
    bounds = [arr[:, 0].min(), arr[:, 0].max(),
              arr[:, 1].min(), arr[:, 1].max()]
    margin = min(bounds[0] - gap, 5.5 - bounds[1], bounds[2], 4. - bounds[3])
    return dict(bounds=[float(v) for v in bounds], margin=float(margin),
                all_body_occluded=bool(margin > 0))


def forest_position(forest, scene):
    """Only finite typed paths serialized in these records are accepted.

    Positive lane-id ds decreases in travel direction. InBound is upstream,
    OutBound downstream. finite leaf_depth certifies this tree is not truncated;
    this is a necessary position projection, not a velocity/history decoder.
    """
    segments, unknown = [], []
    for index, shadow in enumerate(forest):
        if any(v is None for v in shadow['leaf_depth']):
            unknown.append([index, 'truncated_leaf_depth'])
        def walk(node, is_root):
            lid, typ = node['id'], node['type']
            if str(lid) not in scene['lanes']:
                unknown.append([index, 'unknown_lane', lid]); return
            length = max(scene['lanes'][str(lid)]['ds'])
            if typ == 'InOutBound':
                lo, hi = node['ds_out'], node['ds_in']
            elif typ == 'InBound':
                lo, hi = 0., node['ds_in']
                if node['children']:
                    unknown.append([index, 'unexpected_InBound_children'])
            elif typ == 'OutBound':
                lo, hi = node['ds_out'], length
                if not is_root:
                    unknown.append([index, 'unexpected_OutBound_interior'])
            elif typ == 'ShadowNode':
                lo, hi = 0., length
            else:
                unknown.append([index, 'unknown_type', typ]); return
            segments.append([index, lid, min(lo, hi), max(lo, hi)])
            for child in node['children']:
                walk(child, False)
        walk(shadow['root'], True)
    present = any(lid == 1 and lo <= 8 <= hi for _, lid, lo, hi in segments)
    return bool(present), unknown, segments


def expected_image(scene, pose):
    """Closed-form ray/rectangle/ground intersection, separate from renderer.

    Image depth is the ray parameter for a ray with camera forward component 1.
    It is not Euclidean distance. Uses serialized geometry and camera matrix.
    """
    cam = scene['camera']; w, h = cam['width'], cam['height']
    focal = w / (2 * np.tan(cam['h_fov'] * np.pi / 360))
    lateral = (np.arange(w)[None, :] - w / 2) / focal
    vertical = -(np.arange(h)[:, None] - h / 2) / focal
    p = np.asarray(pose)
    # Rotation in these inputs is yaw-only, checked independently below.
    dx = p[0, 0] + p[0, 1] * lateral
    dy = p[1, 0] + p[1, 1] * lateral
    dz = np.broadcast_to(vertical, (h, w))
    out = np.full((h, w), float(cam['far']))
    with np.errstate(divide='ignore', invalid='ignore'):
        for panel in scene['panels']:
            tau = (panel['y'] - p[1, 3]) / dy
            x_hit = p[0, 3] + tau * dx
            z_hit = p[2, 3] + tau * dz
            valid = ((tau > 0) & (x_hit >= panel['x'][0]) &
                     (x_hit <= panel['x'][1]) & (z_hit >= panel['z'][0]) &
                     (z_hit <= panel['z'][1]))
            out = np.minimum(out, np.where(valid, tau, np.inf))
        ground = -p[2, 3] / dz
        out = np.minimum(out, np.where(ground > 0, ground, np.inf))
    return out.astype(np.float32)


def query_visibility(q, scene, poses, frames):
    """Independent scalar implementation of documented native decision rule.

    This validates implementation/serialization consistency. It does not turn
    native two-height visibility into a continuous-body observation oracle.
    """
    ti = int(round(2 * q['t'])); cam = scene['camera']
    w, h = cam['width'], cam['height']
    focal = w / (2 * np.tan(cam['h_fov'] * np.pi / 360))
    lane = scene['lanes'][str(q['lane'])]
    index = min(range(len(lane['ds'])), key=lambda i: abs(lane['ds'][i] - q['ds']))
    pt = lane['center'][index]
    origin = np.asarray(poses[ti][0])[:3, 3]
    checks = []
    for height in [.5, 1.2]:
        delta = np.asarray([pt[0], pt[1], pt[2] + height]) - origin
        dist = float(np.linalg.norm(delta))
        if dist < 5:
            checks.append(dict(visible=True, shortcut='near_5m')); return True, checks
        if dist >= cam['range']:
            checks.append(dict(visible=False, shortcut='outside_range')); continue
        theta = math.atan2(delta[1], delta[0])
        ci = 0 if -math.pi / 4 < theta <= math.pi / 4 else (
            1 if math.pi / 4 < theta <= 3 * math.pi / 4 else (
                2 if theta > 3 * math.pi / 4 or theta <= -3 * math.pi / 4 else 3))
        rotation = np.asarray(poses[ti][ci])[:3, :3]
        local = rotation.T @ delta
        u = int(np.round(w / 2 + focal * local[1] / local[0]))
        v = int(np.round(h / 2 - focal * local[2] / local[0]))
        if not (0 <= v < h):
            visible = False
        elif not (0 <= u < w):
            raise AssertionError(('native_has_no_horizontal_guard', q, u, v))
        else:
            visible = bool(local[0] <= frames['frame_%02d' % ti][ci, v, u])
        checks.append(dict(visible=visible, camera=ci, u=u, v=v,
                           axial_depth=float(local[0])))
        if visible:
            return True, checks
    return False, checks


def box_noninterference(scene, poses, frames):
    """Enumerate all pixels capable of hitting the convex front-facing box.

    Its projected corners bound its perspective projection. Rays outside that
    rectangle cannot hit it; slab tests within the rectangle determine actual
    hits. This independently checks the root analysis's all-image AABB result.
    """
    camera = scene['camera']; w, h = camera['width'], camera['height']
    f = w / (2 * np.tan(camera['h_fov'] * np.pi / 360))
    box_min, box_max = np.asarray([8., -.5, 0.]), np.asarray([11., .5, 1.5])
    corners = np.asarray(list(itertools.product([8.,11.],[-.5,.5],[0.,1.5])))
    result = []
    for ti, camera_poses in enumerate(poses):
        hits = changes = inspected = 0
        for ci, pose in enumerate(camera_poses):
            p = np.asarray(pose); origin = p[:3,3]; rotation = p[:3,:3]
            local_corners = (corners - origin) @ rotation
            if np.all(local_corners[:,0] <= 0):
                continue
            assert np.all(local_corners[:,0] > 0), 'Box straddles camera plane: unsupported projection bound'
            pu = w/2 + f*local_corners[:,1]/local_corners[:,0]
            pv = h/2 - f*local_corners[:,2]/local_corners[:,0]
            u0, u1 = max(0, int(np.floor(min(pu)))-1), min(w-1, int(np.ceil(max(pu)))+1)
            v0, v1 = max(0, int(np.floor(min(pv)))-1), min(h-1, int(np.ceil(max(pv)))+1)
            if u0 > u1 or v0 > v1:
                continue
            u, v = np.meshgrid(np.arange(u0,u1+1), np.arange(v0,v1+1))
            local = np.stack([np.ones_like(u), (u-w/2)/f, -(v-h/2)/f], axis=-1)
            rays = np.einsum('...j,ij->...i', local, rotation)
            with np.errstate(divide='ignore', invalid='ignore'):
                ta = (box_min-origin)/rays; tb = (box_max-origin)/rays
            entering = np.max(np.minimum(ta,tb),axis=-1)
            exiting = np.min(np.maximum(ta,tb),axis=-1)
            hit = (exiting >= np.maximum(entering,0)) & (exiting > 0)
            existing = frames['frame_%02d'%ti][ci,v,u]
            inserted = np.where(hit, np.maximum(entering,0), camera['far']).astype(np.float32)
            hits += int(np.count_nonzero(hit))
            changes += int(np.count_nonzero(np.minimum(existing,inserted) != existing))
            inspected += u.size
        result.append(dict(t=ti/2, body_intersecting_pixels=hits,
            changed_depth_pixels_with_body=changes, projected_rectangle_pixels_inspected=inspected))
    return result


def main():
    report = dict(
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Offline saved-artifact readback only; no native update, simulator or GPU executed.',
        audit_source_sha256=sha(Path(__file__)), batches=[], cases=[], checks={})
    totals = collections.Counter()
    records = {}
    for batch_name in BATCHES:
        batch = C1 / batch_name
        if not (batch / 'completion.json').exists():
            continue
        summary = read(batch / 'summary.json')
        batch_result = dict(name=batch_name, completion=read(batch / 'completion.json'),
                            source_snapshot_sha256=sha(batch / 'source_executed.py'),
                            source_matches_manifest=sha(batch / 'source_executed.py') ==
                              read(batch / 'start_manifest.json')['harness_sha256'])
        report['batches'].append(batch_result)
        for case_name in sorted(set(r['case'] for r in summary)):
            case = batch / case_name
            scene, poses = read(case / 'scene.json'), read(case / 'sensor_poses.json')
            result = dict(batch=batch_name, case=case_name,
                          camera_resolution=[scene['camera']['width'], scene['camera']['height']],
                          input_sha256={f: sha(case / f) for f in ['scene.json', 'sensor_poses.json', 'depth.npz']},
                          geometry=[], runs=[])
            with np.load(case / 'depth.npz') as frames:
                assert sorted(frames.files) == ['frame_%02d' % i for i in range(9)]
                # Load each compressed frame once; scalar queries must not
                # repeatedly decompress the same image stack.
                frame_cache = {key: frames[key] for key in frames.files}
                for ti, camera_poses in enumerate(poses):
                    x = -4 + scene['config']['velocity'] * ti / 2
                    cert = body_certificate(x, scene['config']['gap'])
                    pose_errors = []
                    for ci, p in enumerate(camera_poses):
                        p = np.asarray(p); yaw = ci * np.pi / 2
                        expected = np.asarray([[math.cos(yaw), -math.sin(yaw), 0, x],
                            [math.sin(yaw), math.cos(yaw), 0, -10], [0,0,1,1.7], [0,0,0,1]])
                        pose_errors.append(float(np.max(np.abs(p - expected))))
                    frame = frame_cache['frame_%02d' % ti]
                    assert frame.shape == (4, scene['camera']['height'], scene['camera']['width'])
                    assert frame.dtype == np.float32 and np.isfinite(frame).all() and (frame > 0).all()
                    result['geometry'].append(dict(t=ti/2, body_certificate=cert,
                        pose_max_error=max(pose_errors)))
                # Full image audit for one 640 scene and one 1920 resolution
                # control. Remaining scenes have all queried visibility decisions
                # checked below; this scope is explicit, not an all-pixel claim.
                full_pixels = (case_name == 'v0.5_g-0.5' and
                               batch_name in ['development_v1', 'native_resolution_control'])
                if full_pixels:
                    count, mismatches, max_error = 0, 0, 0.
                    for ti, camera_poses in enumerate(poses):
                        frame = frame_cache['frame_%02d' % ti]
                        for ci, p in enumerate(camera_poses):
                            expected = expected_image(scene, p)
                            count += expected.size
                            mismatches += int(np.count_nonzero(expected != frame[ci]))
                            max_error = max(max_error, float(np.max(np.abs(expected - frame[ci]))))
                    result['all_pixel_geometry_audit'] = dict(pixels=count,
                        float32_exact_mismatches=mismatches, max_absolute_error=max_error)
                    result['box_insertion_independent_audit'] = box_noninterference(scene, poses, frame_cache)
                methods = [r['method'] for r in summary if r['case'] == case_name]
                for method in methods:
                    raw = read(case / (method + '.json'))
                    plain = read(case / (method + '_plain.json'))
                    records[(batch_name, case_name, method)] = raw
                    totals['traced_runs'] += 1; totals['plain_runs'] += 1
                    totals['traced_update_calls_completed'] += len(raw['steps'])
                    totals['plain_update_calls_completed'] += len(plain['steps'])
                    totals['completed_runs'] += int(raw['status'] == 'completed') + int(plain['status'] == 'completed')
                    parity = all(raw[key] == plain[key] for key in ['steps', 'status', 'intervention_applied'])
                    parity = parity and raw['error'] == plain['error']
                    mismatches, near_count = [], 0
                    for qi, q in enumerate(raw['visibility_queries']):
                        visible, details = query_visibility(q, scene, poses, frame_cache)
                        near_count += any(c.get('shortcut') == 'near_5m' for c in details)
                        if visible != q['visible']:
                            mismatches.append(dict(index=qi, query=q, reconstructed=visible, details=details))
                    totals['visibility_queries_checked'] += len(raw['visibility_queries'])
                    step_audits = []
                    for st in raw['steps']:
                        present, unknown, segments = forest_position(st['final'], scene)
                        cert = body_certificate(st['ego_x'], scene['config']['gap'])
                        expected_status = ('witness_position_present' if present else
                           'semantic_unresolved' if unknown else 'witnessed_omission'
                           if cert['all_body_occluded'] else 'witness_not_certified')
                        cert_logged = st['witness']
                        bound_logged = cert_logged['panel_intersection_x'] + cert_logged['panel_intersection_z']
                        certificate_parity = (np.allclose(cert['bounds'], bound_logged, atol=1e-12, rtol=0) and
                            cert['all_body_occluded'] == cert_logged['all_body_hidden'])
                        step_audits.append(dict(t=st['t'], position_present=present,
                            unknown=unknown, observed_status=st['witness_status'],
                            status_parity=expected_status == st['witness_status'],
                            independent_body_hidden=cert['all_body_occluded'],
                            body_certificate_parity=bool(certificate_parity),
                            body_hidden_through_prefix=all(x['body_certificate']['all_body_occluded']
                              for x in result['geometry'] if x['t'] <= st['t']),
                            wrapper_reinitialization=st['wrapper_reinitialization']))
                    result['runs'].append(dict(method=method, status=raw['status'],
                        traced_plain_parity=parity, update_count=len(raw['steps']),
                        visibility_queries=len(raw['visibility_queries']),
                        visibility_mismatches=mismatches, near_shortcut_queries=near_count,
                        intervention_applied=raw['intervention_applied'], steps=step_audits,
                        native_predicate_true_count=sum(e.get('native_would_reject', False) for e in raw['events']),
                        predicate_count_is_not_actual_rejection_count=(method != 'original')))
            result['body_hidden_entire_continuous_horizon'] = all(
                x['body_certificate']['all_body_occluded'] for x in result['geometry'])
            report['cases'].append(result)
    report['denominator'] = dict(totals)
    report['denominator']['invalid_instrumentation_attempts_before_native_execution'] = 1
    report['denominator']['instrumentation_failure_evidence'] = read(C1 / 'confirmation_v2/execution_failure.json')
    name = 'v0.5_g-0.5'
    dev = records[('development_v1', name, 'original')]
    orig = records[('confirmation_v3', name, 'original')]
    single = records[('confirmation_v3', name, 'single_admission')]
    freeze = read(C1 / 'confirmation_freeze_v3.json')
    target = freeze['target']
    dirs = [C1 / b / name for b in ['development_v1', 'confirmation_v3']]
    with np.load(dirs[0]/'depth.npz') as a, np.load(dirs[1]/'depth.npz') as b:
        depth_equal = sorted(a.files) == sorted(b.files) and all(np.array_equal(a[k], b[k]) for k in a.files)
    report['checks']['development_confirmation_parity'] = dict(
        all_original_steps=dev['steps'] == orig['steps'],
        all_original_visibility_queries=dev['visibility_queries'] == orig['visibility_queries'],
        depth_float32_arrays=depth_equal, poses=read(dirs[0]/'sensor_poses.json') == read(dirs[1]/'sensor_poses.json'),
        scene=read(dirs[0]/'scene.json') == read(dirs[1]/'scene.json'))
    report['checks']['single_admission_prefix'] = dict(
        all_steps_before_target=[s for s in orig['steps'] if s['t'] < target['t']] ==
                               [s for s in single['steps'] if s['t'] < target['t']],
        target_prior_forest=next(s['prior'] for s in orig['steps'] if s['t']==target['t']) ==
                            next(s['prior'] for s in single['steps'] if s['t']==target['t']),
        exactly_one_target_applied=single['intervention_applied'] == [target])
    events = orig['events']
    def short(s):
        n=s['root']; return n['id']==1 and n.get('ds_in')==2 and n.get('ds_out')==1.5
    key = [i for i,e in enumerate(events) if e.get('t')==2 and e['stage']=='key_registered' and short(e['shadow'])]
    none = [i for i,e in enumerate(events) if e.get('t')==2 and e['stage']=='primitive_return' and short(e['input']) and e['mature'] is None and not e['children'] and not e['visited']]
    reject = [i for i,e in enumerate(events) if e.get('t')==2 and e['stage']=='admission_observed' and e['shadow']==target['shadow'] and e['native_would_reject']]
    orig_pop = [i for i,e in enumerate(events) if e.get('t')==2 and e['stage']=='pop' and e['shadow']==target['shadow']]
    intervention_pop = [i for i,e in enumerate(single['events']) if e.get('t')==2 and e['stage']=='pop' and e['shadow']==target['shadow']]
    report['checks']['event_chronology'] = dict(
        short_key_registered_indices=key, short_primitive_none_indices=none,
        long_native_predicate_true_indices=reject,
        original_exact_target_pop_indices=orig_pop, single_exact_target_pop_indices=intervention_pop,
        key_before_none_before_rejection=bool(key and none and reject and key[0]<none[0]<reject[0]),
        scope='Original native predicate=True is actual admission rejection; intervention branch checks exact granted job and subsequent pop.')
    report['checks']['freeze_before_confirmation'] = (
        freeze['measurement_revision_utc'] < read(C1/'confirmation_v3/start_manifest.json')['utc'])
    hi_orig = records[('native_resolution_control', name, 'original')]
    hi_single = records[('native_resolution_local', name, 'single_admission')]
    hi_freeze = read(C1/'native_resolution_local_protocol.json')
    hi_target = hi_freeze['target']; tt = hi_target['t']
    hi_dirs = [C1/b/name for b in ['native_resolution_control','native_resolution_local']]
    with np.load(hi_dirs[0]/'depth.npz') as a, np.load(hi_dirs[1]/'depth.npz') as b:
        hi_depth = sorted(a.files)==sorted(b.files) and all(np.array_equal(a[k],b[k]) for k in a.files)
    hi_events = hi_orig['events']
    retained = [(i,e) for i,e in enumerate(hi_events) if e.get('t')==tt and
        e['stage']=='primitive_return' and e['input']['root'].get('ds_in')==1.5 and
        e['input']['root'].get('ds_out')==1 and e['mature'] is not None]
    retained_mature = retained[0][1]['mature'] if retained else None
    hi_orig_step = next(s for s in hi_orig['steps'] if s['t']==tt)
    hi_single_step = next(s for s in hi_single['steps'] if s['t']==tt)
    report['checks']['native_resolution_single_admission'] = dict(
        depth_arrays_equal=hi_depth,
        scene_equal=read(hi_dirs[0]/'scene.json')==read(hi_dirs[1]/'scene.json'),
        poses_equal=read(hi_dirs[0]/'sensor_poses.json')==read(hi_dirs[1]/'sensor_poses.json'),
        prefix_epochs=7,
        all_steps_before_target=[s for s in hi_orig['steps'] if s['t']<tt] ==
                               [s for s in hi_single['steps'] if s['t']<tt],
        target_prior_forest=hi_orig_step['prior']==hi_single_step['prior'],
        exactly_one_target_applied=hi_single['intervention_applied']==[hi_target],
        original_witness_status=hi_orig_step['witness_status'],
        single_witness_status=hi_single_step['witness_status'],
        short_primitive_mature_return_indices=[i for i,_ in retained],
        short_mature_retained_in_original_target_output=retained_mature in hi_orig_step['final'],
        long_native_rejection_indices=[i for i,e in enumerate(hi_events) if e.get('t')==tt and
            e['stage']=='admission_observed' and e['shadow']==hi_target['shadow'] and e['native_would_reject']],
        single_exact_target_pop_indices=[i for i,e in enumerate(hi_single['events']) if e.get('t')==tt and
            e['stage']=='pop' and e['shadow']==hi_target['shadow']],
        freeze_before_execution=hi_freeze['utc'] < read(C1/'native_resolution_local/start_manifest.json')['utc'])
    body_root = read(C1/'analysis/body_sensor_noninterference.json')['results']
    body_checks=[]
    for case in report['cases']:
        if 'box_insertion_independent_audit' not in case:
            continue
        root_group = 'confirmation_v3' if case['batch']=='development_v1' else case['batch']
        independent=case['box_insertion_independent_audit']
        recorded=body_root[root_group]
        body_checks.append(dict(audit_batch=case['batch'],root_analysis_batch=root_group,
            root_counts_match=all(a['t']==b['t'] and
              a['body_intersecting_pixels']==b['body_intersecting_pixels'] and
              a['changed_depth_pixels_with_body']==b['changed_depth_pixels_with_body']
              for a,b in zip(independent,recorded)),
            intersecting_pixels=sum(x['body_intersecting_pixels'] for x in independent),
            changed_depth_pixels=sum(x['changed_depth_pixels_with_body'] for x in independent),
            scope='640 development and confirmation inputs were independently verified equal; projected convex-box bound exhausts all potentially intersecting rays.'))
    report['checks']['independent_body_insertion']=body_checks
    report['interpretation_limits'] = [
        'Geometry-generated synthetic depth; custom road/client adapter; not CARLA sensor capture or natural frequency.',
        'Finite typed tree position projection can disprove coverage of ds=8, but presence does not establish velocity/history coverage or whole-planner soundness.',
        'All-body geometric occlusion and unchanged synthetic sensor arrays after this body insertion are checked independently. Equivalence of different whole-world geometries and a continuous-state planner guarantee are not inferred.',
        'Velocity=1 development cells lose this stationary full-body certificate late in the horizon. Early omission is assessed against its observation prefix only.',
        'Confirmation reuses a development-selected scene and is a causal replay/ablation, not held-out structural generalization.',
        'The 1920 control changes the observation operator. It is one repeated scene, not an independent environmental replicate.',
        'The renderer and independent geometry checker share the specified pinhole/opaque-panel model. They do not validate that model against a physical camera.',
        'No action checker, collision, completion, runtime budget or learned policy is evaluated by these saved C1 runs.'
    ]
    output = Path(__file__).with_suffix('.json')
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(output=str(output), denominator=report['denominator'], checks=report['checks'],
                         pixel_audits=[dict(case=x['case'],batch=x['batch'],**x['all_pixel_geometry_audit']) for x in report['cases'] if 'all_pixel_geometry_audit' in x],
                         visibility_mismatches=sum(len(r['visibility_mismatches']) for c in report['cases'] for r in c['runs']),
                         status_mismatches=sum(not s['status_parity'] for c in report['cases'] for r in c['runs'] for s in r['steps'])), indent=2))


if __name__ == '__main__':
    main()
