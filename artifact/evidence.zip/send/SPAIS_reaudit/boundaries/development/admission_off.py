def _update_shadow(self, unprocessed_shadow_queue, visibility_checker, sensor_data, sensor_pose, t):

    mature_shadow_list = []
    mature_shadow_map = {}

    def add_shadow_to_dict(shadow):
        id = shadow.root.id
        if shadow.risk_bound:
            ds = shadow.root.ds_in
        else:
            ds = shadow.root.ds_out
        if id not in mature_shadow_map:
            mature_shadow_map[id] = []

        heapq.heappush(mature_shadow_map[id], (ds, shadow))


    def check_repeate(shadow2check):
        id = shadow2check.root.id
        if id not in mature_shadow_map:
            return False
        else:
            shadow_list = mature_shadow_map[id]
            if shadow2check.risk_bound:
                return self._check_repeated_fwd_shadow(shadow2check, shadow_list)
            else:
                return self._check_repeated_bwd_shadow(shadow2check, shadow_list)



    # avoid repeating
    fwd_visited_lane = [] # only lanes searched from beginning to end is put in this list
    fwd_searched_begin = []

    bwd_visited_lane = [] # only lanes searched from beginning to end is put in this list
    bwd_searched_begin = []


    while not unprocessed_shadow_queue.empty():
        cur_shadow = unprocessed_shadow_queue.get()
        bound_lane_id = cur_shadow.root.id

        # if true, update the shadow from the inbound towards out bound
        # else, update the shadow from the out bound towards in bound 
        if cur_shadow.risk_bound:

            if bound_lane_id in fwd_visited_lane:
                continue

            if self.route.in_ego_path(cur_shadow.root.id):
                mature_shadow, new_shadow_list, visited_lanes = self._update_fwd_shadow(cur_shadow, visibility_checker, sensor_data, sensor_pose, t)
                fwd_visited_lane.extend(visited_lanes)

                fwd_searched_begin.append((cur_shadow.root.id, cur_shadow.root.ds_in))
                # if a mature shadow has been formed
                if mature_shadow is not None:
                    if not check_repeate(mature_shadow):
                        mature_shadow_list.append(mature_shadow)
                        add_shadow_to_dict(mature_shadow)
                        # if isinstance(mature_shadow.root, InOutBound):
                        #     print("find fwd io", t, mature_shadow.root.id, mature_shadow.root.ds_out, mature_shadow.root.t_out, mature_shadow.root.ds_in,  mature_shadow.root.t_in)
                        # else:
                        #     print("find fwd", t, mature_shadow.root.id, mature_shadow.root.ds_in, mature_shadow.root.t_in, mature_shadow.leaf_depth)

                for new_shadow in new_shadow_list:
                    if new_shadow.risk_bound:
                        new_shadow_begin = (new_shadow.root.id, new_shadow.root.ds_in)
                        if new_shadow_begin not in fwd_searched_begin:
                            unprocessed_shadow_queue.put(new_shadow)
                    else:
                        new_shadow_begin = (new_shadow.root.id, new_shadow.root.ds_out)
                        if True:  # targeted admission reduction disabled
                            unprocessed_shadow_queue.put(new_shadow)

        else:
            #print("start search at", cur_shadow.root.id, cur_shadow.root.ds_out)
            if bound_lane_id in bwd_visited_lane:
                #print("visited")
                continue


            # TODO:
            # discard the backward shadow if it is no longer a risk
            if self.route.in_ego_path(cur_shadow.parent_id):

                bwd_searched_begin.append((cur_shadow.root.id, cur_shadow.root.ds_out))
                mature_shadow, new_shadow_list, visited_lanes = self._update_bwd_shadow(cur_shadow, visibility_checker, sensor_data, sensor_pose, t)
                #print("finish search ", visited_lanes)
                bwd_visited_lane.extend(visited_lanes)


                if mature_shadow is not None:
                    # same shadow has already be processed, discard
                    if not check_repeate(mature_shadow):
                        # if isinstance(mature_shadow.root, InOutBound):
                        #     print("find bwd io", t, mature_shadow.root.id, mature_shadow.root.ds_out, mature_shadow.root.t_out, mature_shadow.root.ds_in,  mature_shadow.root.t_in)
                        # else:
                        #     print("find bwd", t, mature_shadow.root.id, mature_shadow.root.ds_out, mature_shadow.root.t_out, mature_shadow.leaf_depth)
                        mature_shadow_list.append(mature_shadow)
                        add_shadow_to_dict(mature_shadow)
                    #else:
                        #print("repeat", mature_shadow.root.id, mature_shadow.root.ds_out)
                # append new shadow to the queue                  
                for new_shadow in new_shadow_list:
                    new_shadow_begin = (new_shadow.root.id, new_shadow.root.ds_out)
                    if True:  # targeted admission reduction disabled
                        unprocessed_shadow_queue.put(new_shadow)

    #print(len(mature_shadow_list))                 
    return mature_shadow_map, mature_shadow_list
