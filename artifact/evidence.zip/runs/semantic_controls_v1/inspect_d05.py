#!/usr/bin/env python3
"""Freeze D05 visibility and expose same-epoch reduction inputs/outputs."""
import copy, datetime, json, pickle, sys, subprocess
from pathlib import Path
from common import ROOT, sha, compact, position_segments, instrument_update
from rss_checkpoint import restore
from rss_mechanism_diagnostics import apply_context
from audit_rss_continuations import digest

out=ROOT/'runs/semantic_coverage_d05_trace_v2';out.mkdir(exist_ok=False)
folder=ROOT/'runs/mechanism_d05_566_rejected_v2/observation_sequence'
rows=[json.loads(x) for x in (folder/'index.jsonl').read_text().splitlines()]
checkpoint=folder/rows[0]['checkpoint']['ref'];mapfile=ROOT/'assets/maps/Town01_intersection2_reconstructed.ot'
p,root=restore(checkpoint,mapfile);space=p.infoSpace;m=space.shadow_manager
from risk_analysis.shadow_utils import ShadowUtils
original,traced,records,code=instrument_update()
(out/'traced_shadow_update.py').write_text(code)
history=copy.deepcopy(root['shadow_list']);frozen={};steps=[];raw=[]
original_vis=m.vis_checker_octomap.check_visibility
try:
    ShadowUtils._update_shadow=traced
    for row in rows[1:]:
        if row['sequence']%10:continue
        progress,l,v,t,_=row['state'];pose=p.lattice.lattice_2_global(progress,l)
        loc=[pose.location.x,pose.location.y,pose.location.z+1.8]
        bbox=space.object_manager.predict_bbox(t,False)
        # Complete lane 135 field, including points skipped after an omission.
        lane=space.road_network.find_lane_id(135)
        for ds in lane.waypoint_ds:
            frozen[(t,135,float(ds))]=bool(original_vis(lane,ds,bbox,loc,t))
        def vis(lane,ds,data,pose,time):
            key=(float(time),int(lane.lanelet_id),float(ds))
            value=bool(original_vis(lane,ds,data,pose,time))
            if key in frozen:assert frozen[key]==value
            frozen[key]=value
            return value
        m.vis_checker_octomap.check_visibility=vis
        before=copy.deepcopy(history)
        maps,history=space.predict(t,history,loc,use_record=False)
        raw.append(dict(t=t,before=before,after=copy.deepcopy(history),maps=copy.deepcopy(maps)))
        steps.append(dict(t=t,shadows=[compact(x) for x in history],segments=position_segments(history,space.road_network),digest=digest(history)))
finally:
    ShadowUtils._update_shadow=original;m.vis_checker_octomap.check_visibility=original_vis
(out/'steps.json').write_text(json.dumps(steps,indent=2)+'\n')
(out/'reductions.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'states.pkl').write_bytes(pickle.dumps(raw,protocol=4))
(out/'visibility.json').write_text(json.dumps([dict(t=k[0],lane=k[1],ds=k[2],visible=v) for k,v in sorted(frozen.items())],indent=2)+'\n')
(out/'manifest.json').write_text(json.dumps(dict(command=sys.argv,seed=0,device='CPU',status='completed',termination='four fixed path updates',source={str(f.resolve().relative_to(ROOT)):sha(f) for f in [Path(__file__),Path(__file__).with_name('common.py')]},inputs={str(checkpoint.relative_to(ROOT)):sha(checkpoint),str(mapfile.relative_to(ROOT)):sha(mapfile)},commit=subprocess.check_output(['git','-C',str(ROOT/'repos/rss_occlusion'),'rev-parse','HEAD']).decode().strip(),timestamp=datetime.datetime.utcnow().isoformat()+'Z'),indent=2)+'\n')
for e in records:
    if e['t']==3 and e['shadow']['root']['id']==135:
        print(e['stage'],e.get('rejected'),e['shadow']['root'])
