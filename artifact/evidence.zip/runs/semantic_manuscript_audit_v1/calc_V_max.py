    def calc_V_max(self, in_bound, dis, t, debug = False):
        V_max_list = []
        if in_bound.ds_in_hist is None:
            ds_in_hist_list = [np.array([0])]
            t_in_hist_list = [np.array([in_bound.t_in])]
        else:
            ds_in_hist_list = [np.hstack((ds, 0)) for ds in in_bound.ds_in_hist]
            t_in_hist_list = [np.hstack((t_in_hist, in_bound.t_in)) for t_in_hist in in_bound.t_in_hist]

        for ds_in_hist, t_in_hist in zip(ds_in_hist_list, t_in_hist_list):
            delta_s = ds_in_hist+dis# distance between outbound and inbound
            delta_t = (t - t_in_hist)            
            V_in_max = (delta_s - 0.5*self.a_max_decel*delta_t**2)/delta_t
            V_in_max[delta_t == 0] = self.v_max
            V_in_max[V_in_max<0] = 0
            V_out_max = np.sqrt(V_in_max**2+2*self.a_max_accel*delta_s)
            
                
            V_out_max[V_out_max>self.v_max] = self.v_max
            if debug:
                print(V_out_max, delta_s, delta_t)
            V_max_list.append(V_out_max.min())

        return max(V_max_list)
