def translate_polygon(original: Polygon, s_trans):
    return affine_transform(original, [1,0,0,1,s_trans, 0])
