    def bwd_shadow_FRS(self, shadow: Shadow, t_sense, t_predict, n=20, oppo = False):
        # TODO
        # calculate this in a matrix form instead of nesty for loop
        delta_t = t_predict - t_sense
        # if t_sense != shadow.root.t_out:
        #     raise ValueError(t_sense, shadow.root.t_out)

        FRS_union = None
        static_obj = None
        static_length = 0
        for inbound, depth in zip(shadow.leaf_list, shadow.leaf_depth):
            if depth is None:
                v_FRS, dis_FRS = FRS_bound(0, self.v_max, delta_t, delta_t, self.a_max_accel, self.a_max_decel, 0, self.v_max)
                shell = []
                for dis, v in zip(dis_FRS, v_FRS):
                    shell.append((dis, v))
                shell.append((-200, self.v_max))
                shell.append((-200, 0))
            elif depth > 3:
                v_max_cur = self.calc_V_max(inbound, depth-3, t_sense)
                #print("last obsered at", t_sense, "with", v_max_cur)
                max_extent,_ = self._calc_S_max(v_max_cur, delta_t)
                v_FRS, dis_FRS = FRS_bound(0, v_max_cur, delta_t, delta_t, self.a_max_accel, self.a_max_decel, 0, self.v_max)

                dis_list = np.linspace(0, depth-3+max_extent, n)
                v_max_list = [self.calc_V_max(inbound, dis, t_predict) for dis in dis_list]
                #print(depth, v_max_list, inbound.t_in, inbound.t_in_hist, t_predict)
                if v_max_list[0]>0:
                    dis_list = np.hstack((0, dis_list))
                    v_max_list.insert(0, 0)
                
                # plt.plot(dis_list - depth, v_max_list, '-')
                # plt.plot(dis_FRS, v_FRS, '--')
                # plt.show()
                shell = []

                for dis, v in zip(dis_list, v_max_list):
                    shell.append((dis - depth, v))
                
                for dis, v in zip(np.flip(dis_FRS), np.flip(v_FRS)):
                    shell.append((dis, v))
            else:
                if depth> static_length:
                    static_obj = LineString([(0,0), (-depth, 0)])
                    static_length = depth
                continue
            if oppo:
                shell_oppo = []
                for s,v in shell:
                    shell_oppo.append((-s,-v))
                shell = shell_oppo
            if FRS_union is None:
                FRS_union = Polygon(shell)
            else:
                FRS_union = FRS_union.union(Polygon(shell))

        if FRS_union is None:
            FRS_union = static_obj
        return FRS_union
